import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { audio } from "./game/audio";
import { DIFFICULTIES } from "./game/difficulty";
import { SoulHunter, type EngineHooks, type Toast } from "./game/engine";
import type { GamePhase, HighScore, HudSnapshot, RunResult, UpgradeCard } from "./game/types";
import Hud from "./components/Hud";
import Shop from "./components/Shop";
import TouchControls from "./components/TouchControls";
import { loadVault, type Vault } from "./game/gear";
import { HelpScreen, LevelUpScreen, OverScreen, PauseScreen, ScoreScreen, StartScreen } from "./components/Screens";

const SCORE_KEY = "soul_hunter_records_v2";
const NAME_KEY = "soul_hunter_name";
const DIFF_KEY = "soul_hunter_rite";

const SEED: HighScore[] = [
  { name: "Mordkai", score: 91450, level: 19, wave: 12, kills: 512, combo: 58, rank: "SS", date: "2026-02-17" },
  { name: "Velesa", score: 64120, level: 16, wave: 10, kills: 388, combo: 44, rank: "S", date: "2026-02-19" },
  { name: "Nine of Crows", score: 41870, level: 13, wave: 8, kills: 264, combo: 37, rank: "A", date: "2026-02-21" },
  { name: "Ashgrave", score: 26240, level: 10, wave: 6, kills: 171, combo: 29, rank: "B", date: "2026-02-24" },
  { name: "Hesper", score: 14980, level: 7, wave: 5, kills: 96, combo: 21, rank: "C", date: "2026-02-26" },
  { name: "Tolm", score: 6320, level: 4, wave: 3, kills: 48, combo: 12, rank: "D", date: "2026-02-27" },
];

const EMPTY_HUD: HudSnapshot = {
  score: 0,
  combo: 0,
  comboPct: 0,
  bestCombo: 0,
  level: 1,
  xpPct: 0,
  xp: 0,
  xpNeed: 86,
  hp: 4,
  maxHp: 4,
  shields: 0,
  dash: 2,
  maxDash: 2,
  dashPct: 100,
  frenzy: 0,
  frenzyOn: false,
  frenzyPct: 0,
  wave: 1,
  kills: 0,
  time: 0,
  bossHp: -1,
  bossName: "",
  rage: 0,
  boons: [],
  zone: "",
  zoneSub: "",
  inCrypt: false,
  depth: 0,
  roomsCleared: 0,
  roomsTotal: 0,
  chests: 0,
  prompt: "",
  safe: true,
};

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const engineRef = useRef<SoulHunter | null>(null);
  const toastId = useRef(0);

  const [phase, setPhase] = useState<GamePhase>("attract");
  const [screen, setScreen] = useState<"none" | "help" | "scores">("none");
  const [hud, setHud] = useState<HudSnapshot>(EMPTY_HUD);
  const [choices, setChoices] = useState<UpgradeCard[]>([]);
  const [result, setResult] = useState<RunResult | null>(null);
  const [toasts, setToasts] = useState<(Toast & { key: number })[]>([]);

  const [muted, setMuted] = useState(false);
  const [music, setMusic] = useState(false);
  const [auto, setAuto] = useState(false);
  const [hasTouch, setHasTouch] = useState(false);
  const [touchOn, setTouchOn] = useState(false);
  const [radar, setRadar] = useState(true);
  const [fx, setFx] = useState(false); // true = reduced motion
  const [diff, setDiff] = useState(1);

  const [scores, setScores] = useState<HighScore[]>(SEED);
  const [name, setName] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [vault, setVault] = useState<Vault>(() => loadVault());
  const prevPhase = useRef<GamePhase>("attract");

  const scoresRef = useRef(scores);
  scoresRef.current = scores;

  /* ---------- boot ---------- */
  useEffect(() => {
    try {
      const raw = localStorage.getItem(SCORE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as HighScore[];
        if (Array.isArray(parsed) && parsed.length) setScores(parsed);
      } else {
        localStorage.setItem(SCORE_KEY, JSON.stringify(SEED));
      }
      const savedName = localStorage.getItem(NAME_KEY);
      if (savedName) setName(savedName);
      const savedDiff = Number(localStorage.getItem(DIFF_KEY));
      if (Number.isFinite(savedDiff) && savedDiff >= 0 && savedDiff <= 2) setDiff(savedDiff);
      setFx(window.matchMedia?.("(prefers-reduced-motion: reduce)").matches ?? false);
      setRadar(window.innerWidth > 680);
      const touch = "ontouchstart" in window || navigator.maxTouchPoints > 0;
      setHasTouch(touch);
      setTouchOn(touch);
    } catch {
      /* storage unavailable — keep the seed table */
    }
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const hooks: EngineHooks = {
      onHud: (h) => setHud(h),
      onLevelUp: (c) => setChoices(c),
      onVault: (v) => setVault({ ...v, owned: [...v.owned], loadout: { ...v.loadout } }),
      onPhase: (p) => {
        setPhase((cur) => {
          if (p === "shop") prevPhase.current = cur;
          return p;
        });
        if (p === "playing") setChoices([]);
      },
      onToast: (t) => {
        const key = ++toastId.current;
        setToasts((prev) => [...prev.slice(-2), { ...t, key }]);
        window.setTimeout(() => setToasts((prev) => prev.filter((x) => x.key !== key)), 2500);
      },
      onOver: (r) => {
        const best = scoresRef.current[0]?.score ?? 0;
        const record = r.score > 0 && r.score > best;
        setResult({ ...r, newRecord: record });
        setSubmitted(false);
        if (record) window.setTimeout(() => audio.record(), 620);
      },
    };

    const eng = new SoulHunter(canvas, hooks);
    engineRef.current = eng;
    eng.autoAttack = auto;
    eng.wantMusic = music;

    const ro = new ResizeObserver(() => {
      (eng as unknown as { resize: () => void }).resize();
    });
    if (canvas.parentElement) ro.observe(canvas.parentElement);

    return () => {
      ro.disconnect();
      eng.destroy();
      engineRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ---------- actions ---------- */
  const start = useCallback(() => {
    setScreen("none");
    setResult(null);
    setSubmitted(false);
    setChoices([]);
    setToasts([]);
    engineRef.current?.startRun();
  }, []);

  const quit = useCallback(() => {
    engineRef.current?.toAttract();
    setScreen("none");
    setResult(null);
  }, []);

  const toggleMute = useCallback(() => {
    setMuted((m) => {
      const next = !m;
      audio.setMuted(next);
      return next;
    });
  }, []);

  const toggleMusic = useCallback(() => {
    setMusic((m) => {
      const next = !m;
      audio.unlock();
      audio.setMuted(muted);
      if (next) audio.startMusic();
      else audio.stopMusic();
      if (engineRef.current) engineRef.current.wantMusic = next;
      return next;
    });
  }, [muted]);

  const toggleAuto = useCallback(() => {
    setAuto((a) => {
      const next = !a;
      if (engineRef.current) engineRef.current.autoAttack = next;
      return next;
    });
  }, []);

  const toggleTouch = useCallback(() => {
    setTouchOn((t) => {
      const next = !t;
      if (!next) engineRef.current?.setAxis(0, 0);
      return next;
    });
  }, []);

  const pick = useCallback((id: string) => {
    engineRef.current?.applyUpgrade(id);
    setChoices([]);
  }, []);

  const best = useMemo(() => (scores.length ? scores[0] : null), [scores]);

  const submitScore = useCallback(
    (e: React.FormEvent) => {
      e.preventDefault();
      if (!result) return;
      const entry: HighScore = {
        name: (name || "Nameless").trim().slice(0, 14),
        score: result.score,
        level: result.level,
        wave: result.wave,
        kills: result.kills,
        combo: result.bestCombo,
        rank: result.rank,
        date: new Date().toISOString().slice(0, 10),
      };
      const next = [...scoresRef.current, entry].sort((a, b) => b.score - a.score).slice(0, 12);
      setScores(next);
      try {
        localStorage.setItem(SCORE_KEY, JSON.stringify(next));
        localStorage.setItem(NAME_KEY, entry.name);
      } catch {
        /* ignore */
      }
      setSubmitted(true);
    },
    [name, result]
  );

  const clearScores = useCallback(() => {
    setScores([]);
    try {
      localStorage.setItem(SCORE_KEY, JSON.stringify([]));
    } catch {
      /* ignore */
    }
  }, []);

  /* ---------- global keys ---------- */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA")) return;
      const k = e.key.toLowerCase();
      if (phase === "shop") return;
      if (k === "enter" && (phase === "attract" || phase === "over") && screen === "none") {
        e.preventDefault();
        start();
      } else if (k === "r" && (phase === "over" || phase === "paused")) {
        start();
      } else if (k === "m") {
        toggleMute();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [phase, screen, start, toggleMute]);

  /* keep engine prefs in sync */
  useEffect(() => {
    if (engineRef.current) engineRef.current.autoAttack = auto;
  }, [auto]);
  useEffect(() => {
    if (engineRef.current) engineRef.current.wantMusic = music;
  }, [music]);
  useEffect(() => {
    if (engineRef.current) engineRef.current.showRadar = radar;
  }, [radar]);
  useEffect(() => {
    if (engineRef.current) engineRef.current.reduceFx = fx;
  }, [fx]);
  useEffect(() => {
    if (engineRef.current) engineRef.current.difficulty = diff;
    try {
      localStorage.setItem(DIFF_KEY, String(diff));
    } catch {
      /* ignore */
    }
  }, [diff]);

  const stacks = useMemo(() => Object.fromEntries(hud.boons.map((b) => [b.id, b.n])), [hud.boons]);
  const inRunPhase = (p: GamePhase) => p === "playing" || p === "paused" || p === "levelup";
  const showHud = inRunPhase(phase) || (phase === "shop" && inRunPhase(prevPhase.current));

  return (
    <div className="relative h-[100dvh] w-screen overflow-hidden bg-void-950 text-bone-100 font-ui">
      {/* live world — the game canvas doubles as the ambient backdrop for menus */}
      <canvas ref={canvasRef} className="absolute inset-0 block h-full w-full touch-none" />

      {/* texture layers */}
      <div className="pointer-events-none absolute inset-0 scanlines opacity-[0.16] mix-blend-overlay z-10" />
      <div className="pointer-events-none absolute inset-0 grain opacity-[0.06] z-10" />
      <div className="pointer-events-none absolute inset-0 shadow-[inset_0_0_180px_60px_rgba(4,2,9,0.9)] z-10" />

      {showHud && (
        <Hud
          hud={hud}
          onPause={() => engineRef.current?.pause()}
          onShop={() => engineRef.current?.openShop()}
          bank={vault.souls}
          autoAttack={auto}
          toasts={toasts}
          rite={DIFFICULTIES[diff].name}
          riteTone={DIFFICULTIES[diff].tone}
        />
      )}

      {touchOn && (phase === "playing" || phase === "paused") && (
        <TouchControls
          charges={hud.dash}
          max={hud.maxDash}
          onAxis={(x, y) => engineRef.current?.setAxis(x, y)}
          onSlashDown={() => {
            if (engineRef.current) engineRef.current.holdSlash = true;
          }}
          onSlashUp={() => {
            if (engineRef.current) engineRef.current.holdSlash = false;
          }}
          onDash={() => engineRef.current?.requestDash()}
          onShop={() => engineRef.current?.openShop()}
          skills={hud.skills}
          onSkill={(i) => engineRef.current?.castSkill(i)}
        />
      )}

      {/* ---------- shop (available from anywhere) ---------- */}
      {phase === "shop" && (
        <Shop
          vault={vault}
          liveSouls={0}
          inRun={inRunPhase(prevPhase.current)}
          onBuy={(id) => engineRef.current?.buy(id)}
          onEquip={(id, slot) => engineRef.current?.equip(id, slot)}
          onClose={() => engineRef.current?.closeShop()}
        />
      )}

      {/* ---------- overlays ---------- */}
      {screen === "help" ? (
        <HelpScreen onBack={() => setScreen("none")} onStart={start} />
      ) : screen === "scores" ? (
        <ScoreScreen scores={scores} onBack={() => setScreen("none")} onStart={start} onClear={clearScores} />
      ) : phase === "attract" ? (
        <StartScreen
          onStart={start}
          onHelp={() => setScreen("help")}
          onScores={() => setScreen("scores")}
          muted={muted}
          onToggleMute={toggleMute}
          music={music}
          onToggleMusic={toggleMusic}
          auto={auto}
          onToggleAuto={toggleAuto}
          best={best}
          hasTouch={hasTouch}
          touchOn={touchOn}
          onToggleTouch={toggleTouch}
          diff={diff}
          setDiff={setDiff}
          radar={radar}
          onToggleRadar={() => setRadar((v) => !v)}
          fx={!fx}
          onToggleFx={() => setFx((v) => !v)}
          onShop={() => engineRef.current?.openShop()}
          bank={vault.souls}
        />
      ) : phase === "paused" ? (
        <PauseScreen
          result={{ score: hud.score, level: hud.level, wave: hud.wave, kills: hud.kills, combo: hud.bestCombo }}
          onResume={() => engineRef.current?.resume()}
          onRestart={start}
          onQuit={quit}
          muted={muted}
          onToggleMute={toggleMute}
          music={music}
          onToggleMusic={toggleMusic}
          onShop={() => engineRef.current?.openShop()}
        />
      ) : phase === "levelup" ? (
        <LevelUpScreen choices={choices} stacks={stacks} level={hud.level} onPick={pick} />
      ) : phase === "over" && result ? (
        <OverScreen
          result={result}
          bestScore={best?.score ?? 0}
          name={name}
          setName={setName}
          onSubmit={submitScore}
          submitted={submitted}
          onRestart={start}
          onMenu={quit}
          onScores={() => setScreen("scores")}
          onShop={() => engineRef.current?.openShop()}
          bank={vault.souls}
        />
      ) : null}
    </div>
  );
}
