import { Crosshair, Flame, Hammer, Heart, Pause, Skull, Store, Swords, Wind, Zap } from "lucide-react";
import { BoonIcon, KeyCap, Meter, Ribbon } from "./Bits";
import { UPGRADE_POOL } from "../game/upgrades";
import type { HudSnapshot } from "../game/types";
import type { Toast } from "../game/engine";

const fmt = (n: number) => n.toLocaleString("en-US");
const clock = (s: number) => `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(Math.floor(s % 60)).padStart(2, "0")}`;

export default function Hud({
  hud,
  onPause,
  onShop,
  bank = 0,
  autoAttack,
  toasts,
  rite = "Reaper",
  riteTone = "#ffc94a",
}: {
  hud: HudSnapshot;
  onPause: () => void;
  onShop?: () => void;
  bank?: number;
  autoAttack: boolean;
  toasts: (Toast & { key: number })[];
  rite?: string;
  riteTone?: string;
}) {
  const comboMult = 1 + Math.min(hud.combo, 60) * 0.05;
  const low = hud.hp <= 1;

  return (
    <div className="absolute inset-0 pointer-events-none z-20 select-none">
      {/* ---------- top rail ---------- */}
      <div className="absolute top-0 inset-x-0 flex items-start justify-between gap-2 p-2 sm:p-3">
        {/* vitality + level */}
        <div className="flex flex-col gap-1.5">
          <div className="flex items-center gap-1.5 cut-sm bg-void-950/70 border border-void-600/60 px-2 py-1.5">
            <div className={`flex items-center gap-1 ${low ? "anim-throb" : ""}`}>
              {Array.from({ length: Math.max(hud.maxHp, 1) }).map((_, i) => (
                <span
                  key={i}
                  className={`block w-3.5 h-3.5 rotate-45 border transition-all duration-200 ${
                    i < hud.hp
                      ? "bg-gore-500 border-gore-400 shadow-[0_0_10px_rgba(226,56,47,0.75)]"
                      : "bg-void-800/60 border-void-600"
                  }`}
                  style={{ clipPath: "polygon(50% 0, 100% 50%, 50% 100%, 0 50%)" }}
                />
              ))}
            </div>
            {hud.shields > 0 && (
              <div className="flex items-center gap-0.5 pl-1.5 border-l border-void-600/70">
                {Array.from({ length: hud.shields }).map((_, i) => (
                  <Heart key={i} className="w-3.5 h-3.5 text-spectral-300 fill-spectral-400/30" />
                ))}
              </div>
            )}
            {hud.rage > 0 && (
              <div className="flex items-center gap-1 pl-1.5 border-l border-void-600/70 text-ember-400">
                <Flame className="w-3.5 h-3.5" />
                <span className="num font-head text-[10px] font-black">{hud.rage.toFixed(1)}</span>
              </div>
            )}
          </div>

          <div className="flex items-center gap-2">
            <div className="cut-sm bg-gradient-to-br from-hex-700 to-void-900 border border-hex-400/50 px-2 py-0.5 flex items-baseline gap-1">
              <span className="font-head text-[9px] tracking-[0.2em] text-hex-300">LV</span>
              <span className="num font-head text-base font-black text-bone-50 leading-none">{hud.level}</span>
            </div>
            <div className="w-28 sm:w-36">
              <Meter value={hud.xpPct} tone="hex" height="h-1.5" />
              <div className="num mt-0.5 text-[9px] font-bold tracking-wider text-bone-500">
                {hud.xp} / {hud.xpNeed} ESSENCE
              </div>
            </div>
          </div>

          {/* dash charges */}
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1">
              {Array.from({ length: Math.max(hud.maxDash, 1) }).map((_, i) => {
                const ready = i < hud.dash;
                return (
                  <span
                    key={i}
                    className={`relative block w-6 h-6 overflow-hidden border transition-all duration-150 ${
                      ready
                        ? "bg-[linear-gradient(150deg,#ffc08a,#ff6a1f)] border-ember-300/80 shadow-[0_0_12px_rgba(255,154,77,0.7)]"
                        : "bg-void-900 border-void-600"
                    }`}
                    style={{ clipPath: "polygon(50% 0,100% 25%,100% 75%,50% 100%,0 75%,0 25%)" }}
                  >
                    {!ready && (
                      <span
                        className="absolute inset-x-0 bottom-0 bg-ember-700/70"
                        style={{ height: `${hud.dashPct}%` }}
                      />
                    )}
                  </span>
                );
              })}
            </div>
            <span className="hidden sm:flex items-center gap-1 font-head text-[9px] uppercase tracking-[0.2em] text-bone-500">
              <KeyCap wide>Shift</KeyCap> veilstep
            </span>
          </div>
        </div>

        {/* score + combo */}
        <div className="flex flex-col items-center -mt-0.5">
          <div className="font-head text-[9px] uppercase tracking-[0.4em] text-bone-500">Souls Reaped</div>
          <div
            className={`num font-head font-black leading-none tracking-tight text-[clamp(28px,6vw,50px)] ${
              hud.frenzyOn
                ? "text-transparent bg-clip-text bg-[linear-gradient(180deg,#fff4d0,#ffc94a_55%,#ff6a1f)] drop-shadow-[0_0_18px_rgba(255,201,74,0.6)]"
                : "text-bone-50 drop-shadow-[0_3px_0_rgba(0,0,0,0.6)]"
            }`}
          >
            {fmt(hud.score)}
          </div>
          {hud.combo > 1 && (
            <div className="mt-1 flex flex-col items-center gap-1">
              <div className="flex items-center gap-1.5 cut-sm bg-hex-700/70 border border-hex-400/60 px-2 py-[2px]">
                <Zap className="w-3 h-3 text-gold-300" />
                <span className="num font-head text-[11px] font-black tracking-widest text-bone-50">
                  ×{comboMult.toFixed(2)}
                </span>
                <span className="font-head text-[9px] tracking-[0.2em] text-hex-300">CHAIN {hud.combo}</span>
              </div>
              <div className="w-24">
                <Meter value={hud.comboPct} tone="gold" height="h-[3px]" />
              </div>
            </div>
          )}
          {hud.bossHp >= 0 && (
            <div className="mt-2 w-[min(72vw,420px)]">
              <div className="flex items-center justify-between mb-0.5">
                <span className="font-head text-[9px] font-black uppercase tracking-[0.25em] text-gore-400 flex items-center gap-1">
                  <Skull className="w-3 h-3" /> {hud.bossName}
                </span>
                <span className="num text-[9px] font-bold text-bone-500">{Math.ceil(hud.bossHp * 100)}%</span>
              </div>
              <Meter value={hud.bossHp * 100} tone="gore" height="h-2" striped />
            </div>
          )}
        </div>

        {/* wave / timers / pause */}
        <div className="flex items-start gap-2">
          <div className="hidden sm:flex flex-col items-end gap-1 cut-sm bg-void-950/70 border border-void-600/60 px-2 py-1.5">
            <div className="flex items-baseline gap-1.5">
              <span className="font-head text-[9px] tracking-[0.2em] text-bone-500">{hud.inCrypt ? "DEPTH" : "SURFACE"}</span>
              <span className="num font-head text-lg font-black leading-none text-gold-300">{hud.inCrypt ? hud.depth : "—"}</span>
            </div>
            {hud.inCrypt && (
              <div className="flex items-center gap-1">
                {Array.from({ length: Math.max(hud.roomsTotal, 1) }).map((_, i) => (
                  <span
                    key={i}
                    className={`block w-2 h-2 rotate-45 border ${i < hud.roomsCleared ? "bg-spectral-400 border-spectral-200" : "bg-void-800 border-void-600"}`}
                  />
                ))}
                <span className="ml-1 font-head text-[8px] tracking-[0.2em] text-bone-500">CHAMBERS</span>
              </div>
            )}
            <div className="num flex items-center gap-2 text-[10px] font-bold text-bone-300">
              <span>{clock(hud.time)}</span>
              <span className="text-void-600">|</span>
              <span className="flex items-center gap-1">
                <Swords className="w-3 h-3 text-spectral-400" />
                {hud.kills}
              </span>
            </div>
            <span className="flex items-center gap-1.5">
              <span className="flex items-center gap-1 font-head text-[8px] tracking-[0.2em]" style={{ color: riteTone }}>
                <span className="w-1.5 h-1.5 rotate-45" style={{ background: riteTone }} />
                {rite} rite
              </span>
              {autoAttack && <span className="font-head text-[8px] tracking-[0.2em] text-spectral-300">auto-reap</span>}
            </span>
          </div>
          <button
            onClick={onShop}
            aria-label="Open the Soul Bazaar"
            title="Soul Bazaar (B)"
            className="pointer-events-auto cut-sm bg-void-900/85 border border-gold-400/40 hover:border-gold-300 text-gold-300 px-2 py-1.5 transition-colors cursor-pointer flex items-center gap-1.5"
          >
            <Store className="w-4 h-4" />
            <span className="hidden sm:inline num font-head text-[10px] font-black">{bank.toLocaleString("en-US")}</span>
          </button>
          <button
            onClick={onPause}
            aria-label="Pause"
            className="pointer-events-auto cut-sm bg-void-900/85 border border-void-600/70 hover:border-gold-400/70 hover:text-gold-300 text-bone-300 p-2 transition-colors cursor-pointer"
          >
            <Pause className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* ---------- skill arts (Q / F / C) ---------- */}
      {hud.skills && hud.skills.length > 0 && (
        <div className="absolute left-1/2 -translate-x-1/2 bottom-[60px] sm:bottom-[66px] flex items-end gap-2.5 pointer-events-none">
          {hud.skills.map((s) => {
            const ready = s.cd <= 0;
            const Icon = s.icon === "cyclone" ? Wind : s.icon === "lance" ? Crosshair : Hammer;
            return (
              <div key={s.id} title={s.name} className="relative flex flex-col items-center">
                <div
                  className="relative w-11 h-11 sm:w-12 sm:h-12 cut-sm border-2 bg-void-950/85 flex items-center justify-center transition-[box-shadow,border-color] duration-200"
                  style={{
                    borderColor: ready ? s.color : "#2c1e49",
                    color: ready ? s.color : "#5d5344",
                    boxShadow: ready ? `0 0 18px -4px ${s.color}` : "none",
                  }}
                >
                  <Icon className="w-5 h-5" strokeWidth={2} />
                  {!ready && (
                    <span
                      className="absolute inset-0"
                      style={{ background: `conic-gradient(rgba(6,4,12,0.82) ${(s.cd / s.max) * 360}deg, transparent 0deg)` }}
                    />
                  )}
                </div>
                <span className="absolute -top-2 -left-1.5 bg-void-950 border border-void-600 px-1 font-head text-[8px] font-black text-bone-300">
                  {s.key}
                </span>
                <span
                  className="num mt-1 font-head text-[9px] font-black tracking-wider"
                  style={{ color: ready ? s.color : "#93876e" }}
                >
                  {ready ? "READY" : `${s.cd.toFixed(1)}s`}
                </span>
              </div>
            );
          })}
        </div>
      )}

      {/* ---------- zone plate ---------- */}
      {hud.zone && (
        <div className="absolute left-2 sm:left-3 bottom-2 sm:bottom-3 flex items-center gap-2 cut-sm bg-void-950/70 border border-void-600/60 px-2.5 py-1.5">
          <span
            className="w-2 h-2 rotate-45"
            style={{
              background: hud.safe ? "#3fe6b8" : hud.zone.startsWith("MOSSGRAVE") ? "#c9d27a" : hud.zone.startsWith("THE SEWER") ? "#b8ef3f" : hud.inCrypt ? "#b46cff" : "#ff9a4d",
              boxShadow: `0 0 8px ${hud.safe ? "#3fe6b8" : hud.zone.startsWith("MOSSGRAVE") ? "#c9d27a" : hud.zone.startsWith("THE SEWER") ? "#b8ef3f" : hud.inCrypt ? "#b46cff" : "#ff9a4d"}`,
            }}
          />
          <div className="leading-none">
            <div className="font-head text-[10px] font-black uppercase tracking-[0.22em] text-bone-100">{hud.zone}</div>
            <div className="mt-0.5 font-head text-[8px] uppercase tracking-[0.18em] text-bone-500">
              {hud.safe ? "sanctuary · no hauntings" : hud.zoneSub}
            </div>
          </div>
          {hud.chests > 0 && (
            <span className="ml-2 pl-2 border-l border-void-600/70 num font-head text-[10px] font-black text-gold-300">
              {hud.chests} <span className="text-bone-500 font-normal tracking-[0.18em] text-[8px]">CHESTS</span>
            </span>
          )}
        </div>
      )}

      {/* ---------- interaction prompt ---------- */}
      {hud.prompt && (
        <div className="absolute left-1/2 -translate-x-1/2 bottom-[104px] sm:bottom-[112px] anim-pop">
          <div className="cut-sm bg-void-950/85 border border-gold-400/50 px-3 py-1.5 font-head text-[10px] sm:text-[11px] font-black uppercase tracking-[0.28em] text-gold-200 shadow-[0_0_24px_-8px_rgba(255,201,74,0.8)]">
            {hud.prompt}
          </div>
        </div>
      )}

      {/* ---------- frenzy engine ---------- */}
      <div className="absolute left-1/2 -translate-x-1/2 bottom-2 sm:bottom-3 w-[min(86vw,520px)]">
        <div className="flex items-center justify-between mb-1">
          <span
            className={`font-head text-[9px] sm:text-[10px] font-black uppercase tracking-[0.3em] ${
              hud.frenzyOn ? "text-gold-300 anim-flicker" : "text-bone-500"
            }`}
          >
            {hud.frenzyOn ? "✦ SOUL FRENZY ✦" : "soul pressure"}
          </span>
          <span className="num text-[9px] font-bold text-bone-500">
            {hud.frenzyOn ? "UNBOUND" : `${Math.floor(hud.frenzy)}%`}
          </span>
        </div>
        <Meter
          value={hud.frenzyPct}
          tone={hud.frenzyOn ? "gold" : hud.frenzy > 70 ? "gore" : "spectral"}
          height="h-2.5"
          striped={hud.frenzyOn}
        />
      </div>

      {/* acquired boons */}
      {hud.boons.length > 0 && (
        <div className="hidden md:flex absolute right-3 bottom-3 flex-col items-end gap-1.5">
          {hud.boons.slice(0, 9).map((b) => {
            const meta = UPGRADE_POOL.find((u) => u.id === b.id);
            if (!meta) return null;
            return (
              <div
                key={b.id}
                className="flex items-center gap-2 cut-sm bg-void-950/70 border border-void-600/60 px-2 py-1"
                title={meta.name}
              >
                <BoonIcon name={meta.icon} className="w-3.5 h-3.5 text-gold-300" />
                <span className="font-head text-[9px] uppercase tracking-[0.14em] text-bone-300">{meta.name}</span>
                {b.n > 1 && <span className="num text-[9px] font-black text-spectral-300">×{b.n}</span>}
              </div>
            );
          })}
        </div>
      )}

      {/* toasts */}
      <div className="absolute top-28 sm:top-24 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2">
        {toasts.map((t) => (
          <div key={t.key} className="anim-pop flex flex-col items-center gap-1">
            <Ribbon tone={t.kind === "boss" ? "gore" : t.kind === "frenzy" || t.kind === "milestone" ? "gold" : t.kind === "zone" ? "spectral" : "hex"}>
              {t.title}
            </Ribbon>
            {t.sub && (
              <div className="font-head text-[10px] uppercase tracking-[0.24em] text-bone-300/80 drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]">
                {t.sub}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
