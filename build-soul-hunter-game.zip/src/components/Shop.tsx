import { useEffect, useRef, useState } from "react";
import { Check, Coins, Lock, Sparkles, Swords, X } from "lucide-react";
import { Btn, Panel, Ribbon } from "./Bits";
import { ACCESSORIES, SCYTHES, type AccessoryDef, type AccessoryId, type ScytheDef, type ScytheId, type Slot, type Vault } from "../game/gear";
import { drawAccessoryPreview, drawScythePreview } from "../game/reaper";

const fmt = (n: number) => Math.round(n).toLocaleString("en-US");

function Preview({ kind, id, tone }: { kind: "scythe" | "acc"; id: string; tone: string }) {
  const ref = useRef<HTMLCanvasElement | null>(null);
  useEffect(() => {
    const cv = ref.current;
    if (!cv) return;
    const ctx = cv.getContext("2d")!;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const w = cv.clientWidth;
    const h = cv.clientHeight;
    cv.width = w * dpr;
    cv.height = h * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    let raf = 0;
    const loop = (now: number) => {
      const t = now / 1000;
      if (kind === "scythe") drawScythePreview(ctx, id as ScytheId, w, h, t);
      else drawAccessoryPreview(ctx, id as AccessoryId, w, h, t);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [kind, id]);
  return (
    <div className="relative h-28 sm:h-32 w-full overflow-hidden cut-sm bg-[radial-gradient(70%_80%_at_50%_60%,rgba(44,30,73,0.9),rgba(6,4,12,0.95))] border border-void-600/60">
      <div className="absolute inset-0 opacity-40" style={{ background: `radial-gradient(60% 50% at 50% 70%, ${tone}44, transparent 70%)` }} />
      <canvas ref={ref} className="absolute inset-0 w-full h-full" />
    </div>
  );
}

function StatPill({ label, v, good }: { label: string; v: string; good: boolean | null }) {
  return (
    <span
      className={`inline-flex items-center gap-1 cut-sm border px-1.5 py-[2px] font-head text-[9px] font-black uppercase tracking-[0.14em] ${
        good === null ? "border-void-600/60 text-bone-500" : good ? "border-spectral-500/50 text-spectral-300" : "border-gore-500/50 text-gore-400"
      }`}
    >
      {label} <span className="num">{v}</span>
    </span>
  );
}

function pct(m: number, invert = false) {
  const d = Math.round((m - 1) * 100) * (invert ? -1 : 1);
  return d === 0 ? "—" : `${d > 0 ? "+" : ""}${d}%`;
}

export default function Shop({
  vault,
  liveSouls,
  inRun,
  onBuy,
  onEquip,
  onClose,
}: {
  vault: Vault;
  liveSouls: number;
  inRun: boolean;
  onBuy: (id: string) => void;
  onEquip: (id: string | null, slot?: "scythe" | Slot) => void;
  onClose: () => void;
}) {
  const [tab, setTab] = useState<"scythes" | "accessories">("scythes");
  const [sel, setSel] = useState<string>(vault.loadout.scythe);
  const total = vault.souls + Math.max(0, liveSouls);
  const owned = (id: string) => vault.owned.includes(id);
  const equipped = (id: string) =>
    vault.loadout.scythe === id || vault.loadout.wings === id || vault.loadout.charm === id || vault.loadout.trinket === id;

  const selScythe = SCYTHES.find((s) => s.id === sel);
  const selAcc = ACCESSORIES.find((a) => a.id === sel);

  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center p-2 sm:p-5 bg-[radial-gradient(90%_70%_at_50%_30%,rgba(30,14,48,0.6),rgba(4,2,9,0.94))] backdrop-blur-[3px] overflow-y-auto">
      <Panel className="w-full max-w-5xl p-3 sm:p-5" glow>
        {/* header */}
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <Ribbon tone="gold">The Soul Bazaar</Ribbon>
            <h2 className="mt-1.5 font-display text-[clamp(30px,6vw,52px)] leading-none text-bone-50">
              Ferryman's <span className="text-ember-500">Wares</span>
            </h2>
            <p className="mt-1 text-[12px] text-bone-500 max-w-md">
              Trade banked souls for relic scythes and accessories. Purchases persist across every run; equip anything you own at any time.
            </p>
          </div>
          <div className="flex items-start gap-2">
            <div className="cut-sm bg-void-950/80 border border-gold-400/50 px-3 py-2 text-right">
              <div className="font-head text-[9px] uppercase tracking-[0.28em] text-bone-500 flex items-center gap-1 justify-end">
                <Coins className="w-3 h-3 text-gold-300" /> souls to spend
              </div>
              <div className="num font-head text-2xl font-black text-gold-300 leading-none">{fmt(total)}</div>
              {inRun && <div className="text-[9px] text-bone-500 font-head uppercase tracking-[0.18em]">this hunt's souls already banked</div>}
            </div>
            <button
              onClick={onClose}
              aria-label="Close"
              className="cut-sm bg-void-900 border border-void-600/80 hover:border-gold-400/60 text-bone-300 hover:text-gold-300 p-2.5 cursor-pointer transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* tabs */}
        <div className="mt-4 flex gap-1.5">
          {(["scythes", "accessories"] as const).map((k) => (
            <button
              key={k}
              onClick={() => {
                setTab(k);
                setSel(k === "scythes" ? vault.loadout.scythe : vault.loadout.wings ?? ACCESSORIES[0].id);
              }}
              className={`cut-sm px-3 py-1.5 font-head text-[10px] font-black uppercase tracking-[0.24em] border transition-colors cursor-pointer ${
                tab === k ? "bg-gold-400 text-void-950 border-gold-300" : "bg-void-950/60 text-bone-500 border-void-600/60 hover:text-bone-200"
              }`}
            >
              {k === "scythes" ? "relic scythes" : "accessories"}
            </button>
          ))}
          <div className="ml-auto hidden sm:flex items-center gap-2 font-head text-[9px] uppercase tracking-[0.22em] text-bone-700">
            <Swords className="w-3.5 h-3.5" /> equipped: <span className="text-bone-300">{SCYTHES.find((s) => s.id === vault.loadout.scythe)?.name}</span>
            {vault.loadout.wings && <span className="text-bone-300">· {ACCESSORIES.find((a) => a.id === vault.loadout.wings)?.name}</span>}
            {vault.loadout.charm && <span className="text-bone-300">· {ACCESSORIES.find((a) => a.id === vault.loadout.charm)?.name}</span>}
            {vault.loadout.trinket && <span className="text-bone-300">· {ACCESSORIES.find((a) => a.id === vault.loadout.trinket)?.name}</span>}
          </div>
        </div>

        <div className="mt-3 grid gap-3 lg:grid-cols-[1.4fr_1fr]">
          {/* catalogue */}
          <div className={`grid gap-2 ${tab === "scythes" ? "sm:grid-cols-2" : "sm:grid-cols-2 xl:grid-cols-3"} content-start`}>
            {tab === "scythes"
              ? SCYTHES.map((s) => (
                  <ItemCard key={s.id} id={s.id} name={s.name} sub={s.epithet} price={s.price} tone={s.tone} owned={owned(s.id)} equipped={equipped(s.id)} selected={sel === s.id} canAfford={total >= s.price} onClick={() => setSel(s.id)}>
                    <Preview kind="scythe" id={s.id} tone={s.tone} />
                  </ItemCard>
                ))
              : ACCESSORIES.map((a) => (
                  <ItemCard key={a.id} id={a.id} name={a.name} sub={a.slot} price={a.price} tone={a.tone} owned={owned(a.id)} equipped={equipped(a.id)} selected={sel === a.id} canAfford={total >= a.price} onClick={() => setSel(a.id)}>
                    <Preview kind="acc" id={a.id} tone={a.tone} />
                  </ItemCard>
                ))}
          </div>

          {/* detail */}
          <div className="cut bg-void-950/70 border border-void-600/60 p-4 flex flex-col gap-3 min-h-[260px]">
            {selScythe && <ScytheDetail s={selScythe} />}
            {selAcc && <AccDetail a={selAcc} />}
            <div className="mt-auto pt-2 flex flex-wrap gap-2">
              {(() => {
                const item = selScythe ?? selAcc;
                if (!item) return null;
                const isOwned = owned(item.id);
                const isEq = equipped(item.id);
                if (!isOwned)
                  return (
                    <Btn variant={total >= item.price ? "primary" : "ghost"} size="md" disabled={total < item.price} onClick={() => onBuy(item.id)} icon={total >= item.price ? <Sparkles className="w-4 h-4" /> : <Lock className="w-4 h-4" />}>
                      {total >= item.price ? `Claim for ${fmt(item.price)}` : `Need ${fmt(item.price - total)} more`}
                    </Btn>
                  );
                if (selScythe)
                  return (
                    <Btn variant={isEq ? "ghost" : "primary"} size="md" disabled={isEq} onClick={() => onEquip(item.id)} icon={<Check className="w-4 h-4" />}>
                      {isEq ? "Wielded" : "Wield"}
                    </Btn>
                  );
                return (
                  <>
                    <Btn variant={isEq ? "ghost" : "primary"} size="md" disabled={isEq} onClick={() => onEquip(item.id)} icon={<Check className="w-4 h-4" />}>
                      {isEq ? "Equipped" : `Equip (${selAcc!.slot})`}
                    </Btn>
                    {isEq && (
                      <Btn size="md" onClick={() => onEquip(null, selAcc!.slot)}>
                        Unequip
                      </Btn>
                    )}
                  </>
                );
              })()}
            </div>
          </div>
        </div>

        <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-[10px] font-head uppercase tracking-[0.22em] text-bone-700">
          <span>press B or Tab anywhere to open the bazaar · Esc closes</span>
          <span>souls earned in a hunt are banked when you die or shop</span>
        </div>
      </Panel>
    </div>
  );
}

function ItemCard({
  name,
  sub,
  price,
  tone,
  owned,
  equipped,
  selected,
  canAfford,
  onClick,
  children,
}: {
  id: string;
  name: string;
  sub: string;
  price: number;
  tone: string;
  owned: boolean;
  equipped: boolean;
  selected: boolean;
  canAfford: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`group relative text-left cut bg-[linear-gradient(170deg,rgba(29,18,48,0.9),rgba(9,5,18,0.95))] border-2 p-2.5 transition-all cursor-pointer hover:-translate-y-1 ${
        selected ? "border-gold-400/80 shadow-[0_0_30px_-10px_rgba(255,201,74,0.8)]" : equipped ? "border-spectral-400/60" : "border-void-600/70 hover:border-void-600"
      }`}
    >
      {children}
      <div className="mt-2 flex items-start justify-between gap-2">
        <div className="min-w-0">
          <div className="font-head text-[12px] font-black uppercase tracking-[0.08em] text-bone-50 truncate">{name}</div>
          <div className="font-head text-[9px] uppercase tracking-[0.2em]" style={{ color: tone }}>
            {sub}
          </div>
        </div>
        <div className="shrink-0 text-right">
          {equipped ? (
            <span className="inline-flex items-center gap-1 cut-sm bg-spectral-400 text-void-950 px-1.5 py-[2px] font-head text-[8px] font-black uppercase tracking-[0.2em]">
              <Check className="w-3 h-3" /> on
            </span>
          ) : owned ? (
            <span className="font-head text-[9px] uppercase tracking-[0.2em] text-bone-500">owned</span>
          ) : (
            <span className={`num font-head text-[11px] font-black ${canAfford ? "text-gold-300" : "text-bone-700"}`}>{price === 0 ? "free" : fmt(price)}</span>
          )}
        </div>
      </div>
    </button>
  );
}

function ScytheDetail({ s }: { s: ScytheDef }) {
  return (
    <>
      <div>
        <div className="font-head text-[9px] uppercase tracking-[0.3em]" style={{ color: s.tone }}>
          {s.epithet}
        </div>
        <div className="font-display text-3xl leading-none text-bone-50">{s.name}</div>
      </div>
      <p className="text-[12px] leading-relaxed text-bone-300">{s.blurb}</p>
      <div className="flex flex-wrap gap-1.5">
        <StatPill label="dmg" v={pct(s.dmg)} good={s.dmg === 1 ? null : s.dmg > 1} />
        <StatPill label="reach" v={pct(s.reach)} good={s.reach === 1 ? null : s.reach > 1} />
        <StatPill label="arc" v={pct(s.arc)} good={s.arc === 1 ? null : s.arc > 1} />
        <StatPill label="speed" v={pct(s.cd, true)} good={s.cd === 1 ? null : s.cd < 1} />
        <StatPill label="crit" v={s.crit ? `+${Math.round(s.crit * 100)}%` : "—"} good={s.crit ? true : null} />
      </div>
      <div className="cut-sm bg-void-900/80 border-l-2 px-3 py-2" style={{ borderColor: s.tone }}>
        <div className="font-head text-[9px] uppercase tracking-[0.26em] text-bone-500">passive</div>
        <div className="text-[12px] text-bone-100">{s.passive}</div>
      </div>
    </>
  );
}

function AccDetail({ a }: { a: AccessoryDef }) {
  return (
    <>
      <div>
        <div className="font-head text-[9px] uppercase tracking-[0.3em]" style={{ color: a.tone }}>
          {a.slot} slot
        </div>
        <div className="font-display text-3xl leading-none text-bone-50">{a.name}</div>
      </div>
      <p className="text-[12px] leading-relaxed text-bone-300">{a.blurb}</p>
      <ul className="grid gap-1">
        {a.apply.map((line) => (
          <li key={line} className="flex items-center gap-2 text-[12px] text-bone-100">
            <span className="w-1.5 h-1.5 rotate-45" style={{ background: a.tone }} />
            {line}
          </li>
        ))}
      </ul>
      <div className="text-[10px] font-head uppercase tracking-[0.2em] text-bone-700">one item per slot · bonuses apply at the start of a hunt, speed & dash immediately</div>
    </>
  );
}
