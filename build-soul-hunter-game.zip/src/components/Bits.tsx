import React from "react";
import {
  Activity,
  BookOpen,
  CircleDot,
  Coins,
  Flame,
  Ghost,
  Heart,
  Hourglass,
  Magnet,
  Orbit,
  Radar,
  Shield,
  Skull,
  Sparkles,
  Swords,
  Target,
  Waves,
  Wind,
  Zap,
} from "lucide-react";
import type { IconKey } from "../game/types";

const ICONS: Record<IconKey, React.ComponentType<{ className?: string; strokeWidth?: number }>> = {
  arc: Radar,
  blade: Swords,
  magnet: Magnet,
  wind: Wind,
  sparkle: Sparkles,
  void: CircleDot,
  flame: Flame,
  heart: Heart,
  hourglass: Hourglass,
  bolt: Zap,
  shield: Shield,
  ring: Orbit,
  echo: Waves,
  shock: Target,
  thorn: Activity,
  skull: Skull,
  coin: Coins,
  book: BookOpen,
  ghost: Ghost,
};

export function BoonIcon({ name, className = "w-5 h-5" }: { name: IconKey; className?: string }) {
  const C = ICONS[name] ?? Sparkles;
  return <C className={className} strokeWidth={1.9} />;
}

/* Angled gothic panel with corner brackets */
export function Panel({
  children,
  className = "",
  glow = false,
}: {
  children: React.ReactNode;
  className?: string;
  glow?: boolean;
}) {
  return (
    <div
      className={`relative cut bg-void-900/88 backdrop-blur-[3px] border border-void-600/70 frame ${
        glow ? "shadow-[0_0_60px_-18px_rgba(180,108,255,0.55)]" : "shadow-[0_18px_50px_-24px_rgba(0,0,0,0.9)]"
      } ${className}`}
    >
      {children}
    </div>
  );
}

export function Ribbon({ children, tone = "gold" }: { children: React.ReactNode; tone?: "gold" | "hex" | "gore" | "spectral" }) {
  const tones: Record<string, string> = {
    gold: "bg-gold-400 text-void-950",
    hex: "bg-hex-500 text-white",
    gore: "bg-gore-500 text-white",
    spectral: "bg-spectral-400 text-void-950",
  };
  return (
    <span
      className={`inline-block cut-sm px-3 py-[3px] font-head text-[10px] sm:text-[11px] font-black uppercase tracking-[0.28em] ${tones[tone]}`}
    >
      {children}
    </span>
  );
}

type BtnProps = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "ghost" | "danger" | "flat";
  size?: "md" | "lg" | "sm";
  icon?: React.ReactNode;
};

export function Btn({ variant = "ghost", size = "md", icon, children, className = "", ...rest }: BtnProps) {
  const base =
    "relative overflow-hidden cut-sm inline-flex items-center justify-center gap-2.5 font-head font-black uppercase tracking-[0.18em] transition-all duration-150 active:translate-y-[1px] disabled:opacity-40 disabled:pointer-events-none sheen";
  const sizes: Record<string, string> = {
    sm: "px-3 py-2 text-[10px]",
    md: "px-5 py-3 text-xs",
    lg: "px-7 py-4 text-sm sm:text-base",
  };
  const variants: Record<string, string> = {
    primary:
      "text-void-950 bg-[linear-gradient(160deg,#ffd47a,#ffc94a_38%,#ff8a3d)] hover:brightness-110 shadow-[0_10px_34px_-12px_rgba(255,201,74,0.85)]",
    danger:
      "text-bone-50 bg-[linear-gradient(160deg,#ff6a5c,#c01f22)] hover:brightness-110 shadow-[0_10px_34px_-12px_rgba(226,56,47,0.8)]",
    ghost:
      "text-bone-100 bg-void-800/80 hover:bg-void-700/90 border border-void-600/80 hover:border-hex-400/60",
    flat: "text-bone-300 hover:text-gold-300",
  };
  return (
    <button className={`${base} ${sizes[size]} ${variants[variant]} cursor-pointer ${className}`} {...rest}>
      {icon}
      {children}
    </button>
  );
}

export function KeyCap({ children, wide = false }: { children: React.ReactNode; wide?: boolean }) {
  return (
    <kbd
      className={`inline-flex items-center justify-center h-6 min-w-6 px-1.5 rounded-[3px] bg-void-800 border border-void-600 border-b-void-700 text-[10px] font-bold text-bone-100 shadow-[0_2px_0_rgba(0,0,0,0.6)] ${
        wide ? "min-w-16" : ""
      }`}
    >
      {children}
    </kbd>
  );
}

export function Meter({
  value,
  tone = "spectral",
  height = "h-2",
  striped = false,
  className = "",
}: {
  value: number;
  tone?: "spectral" | "gold" | "hex" | "gore" | "bone";
  height?: string;
  striped?: boolean;
  className?: string;
}) {
  const tones: Record<string, string> = {
    spectral: "from-spectral-700 via-spectral-400 to-spectral-200",
    gold: "from-ember-700 via-gold-400 to-gold-200",
    hex: "from-hex-700 via-hex-500 to-hex-300",
    gore: "from-gore-700 via-gore-500 to-ember-400",
    bone: "from-bone-700 via-bone-500 to-bone-300",
  };
  return (
    <div className={`relative w-full ${height} bg-void-950/90 border border-void-600/70 overflow-hidden ${className}`}>
      <div
        className={`absolute inset-y-0 left-0 bg-gradient-to-r ${tones[tone]} ${striped ? "striped" : ""} transition-[width] duration-200 ease-out`}
        style={{ width: `${Math.max(0, Math.min(100, value))}%` }}
      />
      <div className="absolute inset-0 scanlines opacity-25 pointer-events-none" />
    </div>
  );
}

export function Stat({
  label,
  value,
  tone = "bone",
  small = false,
}: {
  label: string;
  value: React.ReactNode;
  tone?: "bone" | "gold" | "spectral" | "hex" | "gore";
  small?: boolean;
}) {
  const tones: Record<string, string> = {
    bone: "text-bone-100",
    gold: "text-gold-300",
    spectral: "text-spectral-300",
    hex: "text-hex-300",
    gore: "text-gore-400",
  };
  return (
    <div className="flex flex-col gap-0.5">
      <span className="font-head text-[9px] uppercase tracking-[0.22em] text-bone-500">{label}</span>
      <span className={`num font-head font-black leading-none ${small ? "text-base" : "text-xl"} ${tones[tone]}`}>
        {value}
      </span>
    </div>
  );
}

/* Wax-seal style rank stamp */
export function RankStamp({ rank, size = 132 }: { rank: string; size?: number }) {
  const hot = rank === "SS" || rank === "S";
  const good = rank === "A" || rank === "B";
  const color = hot ? "#ffc94a" : good ? "#3fe6b8" : "#cdc0a4";
  return (
    <div className="relative anim-stamp" style={{ width: size, height: size }}>
      <svg viewBox="0 0 120 120" className="w-full h-full">
        <defs>
          <radialGradient id="seal" cx="50%" cy="42%" r="62%">
            <stop offset="0%" stopColor={hot ? "#4d1f06" : "#241436"} />
            <stop offset="100%" stopColor="#0b0716" />
          </radialGradient>
        </defs>
        <path
          d="M60 4 L74 12 L90 10 L97 25 L111 33 L108 49 L118 60 L108 71 L111 87 L97 95 L90 110 L74 108 L60 116 L46 108 L30 110 L23 95 L9 87 L12 71 L2 60 L12 49 L9 33 L23 25 L30 10 L46 12 Z"
          fill="url(#seal)"
          stroke={color}
          strokeWidth="2.2"
        />
        <circle cx="60" cy="60" r="42" fill="none" stroke={color} strokeOpacity="0.4" strokeWidth="1" strokeDasharray="4 6" />
        <text
          x="60"
          y="78"
          textAnchor="middle"
          fill={color}
          style={{ font: `900 60px "Pirata One", serif`, letterSpacing: "-2px" }}
        >
          {rank}
        </text>
        <text
          x="60"
          y="98"
          textAnchor="middle"
          fill={color}
          fillOpacity="0.75"
          style={{ font: '700 8px "Cinzel", serif', letterSpacing: "3px" }}
        >
          VERDICT
        </text>
      </svg>
      <div
        className="absolute inset-0 -z-10 blur-2xl opacity-60"
        style={{ background: `radial-gradient(circle at 50% 45%, ${color}66, transparent 66%)` }}
      />
    </div>
  );
}
