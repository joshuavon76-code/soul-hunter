import { useEffect, useRef } from "react";
import {
  Chart,
  LineController,
  LineElement,
  PointElement,
  LinearScale,
  CategoryScale,
  Filler,
  Tooltip,
  type ChartConfiguration,
} from "chart.js";
import type { TimelinePoint } from "../game/types";

Chart.register(LineController, LineElement, PointElement, LinearScale, CategoryScale, Filler, Tooltip);

const clockish = (s: number) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, "0")}`;

/* Run history: souls banked vs. chain multiplier, sampled twice a second. */
export default function RunChart({ points }: { points: TimelinePoint[] }) {
  const cvs = useRef<HTMLCanvasElement | null>(null);
  const chart = useRef<Chart | null>(null);

  useEffect(() => {
    const el = cvs.current;
    if (!el || points.length < 3) return;

    const cfg: ChartConfiguration = {
      type: "line",
      data: {
        labels: points.map((p) => clockish(p.t)),
        datasets: [
          {
            label: "Souls",
            data: points.map((p) => p.score),
            borderColor: "#ffc94a",
            backgroundColor: "rgba(255,201,74,0.14)",
            borderWidth: 2,
            fill: "origin",
            tension: 0.32,
            pointRadius: 0,
            pointHoverRadius: 4,
            pointHoverBackgroundColor: "#ffeeb2",
            yAxisID: "y",
          },
          {
            label: "Chain",
            data: points.map((p) => p.combo),
            borderColor: "#3fe6b8",
            backgroundColor: "rgba(63,230,184,0.1)",
            borderWidth: 1.6,
            borderDash: [4, 3],
            fill: false,
            tension: 0.3,
            pointRadius: 0,
            pointHoverRadius: 4,
            pointHoverBackgroundColor: "#8ef6da",
            yAxisID: "y1",
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: false,
        normalized: true,
        interaction: { mode: "index", intersect: false },
        layout: { padding: { top: 6, right: 2, bottom: 0, left: 0 } },
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: "rgba(11,7,22,0.95)",
            borderColor: "rgba(180,108,255,0.45)",
            borderWidth: 1,
            padding: 8,
            titleFont: { family: "'Chakra Petch', sans-serif", size: 10, weight: 700 },
            bodyFont: { family: "'Chakra Petch', sans-serif", size: 11 },
            titleColor: "#cdc0a4",
            bodyColor: "#f1ead9",
            displayColors: true,
            boxWidth: 8,
            callbacks: {
              label: (ctx) => {
                const v = Number(ctx.parsed.y ?? 0);
                return ctx.datasetIndex === 0
                  ? ` ${Math.round(v).toLocaleString("en-US")} souls`
                  : ` ×${Math.round(v)} chain`;
              },
            },
          },
        },
        scales: {
          x: {
            grid: { color: "rgba(205,192,164,0.06)" },
            border: { color: "rgba(205,192,164,0.18)" },
            ticks: {
              color: "rgba(205,192,164,0.55)",
              font: { family: "'Chakra Petch', sans-serif", size: 9 },
              maxTicksLimit: 6,
              maxRotation: 0,
            },
          },
          y: {
            position: "left",
            beginAtZero: true,
            grid: { color: "rgba(205,192,164,0.06)" },
            border: { display: false },
            ticks: {
              color: "rgba(255,201,74,0.7)",
              font: { family: "'Chakra Petch', sans-serif", size: 9 },
              maxTicksLimit: 4,
              callback: (v) => (Number(v) >= 1000 ? `${Math.round(Number(v) / 1000)}k` : v),
            },
          },
          y1: {
            position: "right",
            beginAtZero: true,
            grid: { drawOnChartArea: false },
            border: { display: false },
            ticks: {
              color: "rgba(63,230,184,0.7)",
              font: { family: "'Chakra Petch', sans-serif", size: 9 },
              maxTicksLimit: 4,
            },
          },
        },
      },
    };

    const c = new Chart(el, cfg);
    chart.current = c;
    return () => {
      c.destroy();
      chart.current = null;
    };
  }, [points]);

  if (points.length < 3) {
    return (
      <div className="h-[104px] grid place-items-center text-[11px] font-head uppercase tracking-[0.25em] text-bone-700">
        reap longer to chart your run
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center gap-3 mb-1.5">
        <span className="flex items-center gap-1.5 font-head text-[9px] uppercase tracking-[0.2em] text-bone-500">
          <span className="w-3 h-[2px] bg-gold-400" /> souls banked
        </span>
        <span className="flex items-center gap-1.5 font-head text-[9px] uppercase tracking-[0.2em] text-bone-500">
          <span className="w-3 h-[2px] bg-spectral-400 [background:repeating-linear-gradient(90deg,#3fe6b8_0_3px,transparent_3px_5px)]" />
          chain
        </span>
      </div>
      <div className="h-[104px]">
        <canvas ref={cvs} />
      </div>
    </div>
  );
}
