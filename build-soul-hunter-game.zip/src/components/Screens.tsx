import React from "react";
import {
  ArrowUpRight,
  Award,
  ChevronRight,
  Flame,
  Gamepad,
  Gauge,
  Info,
  Keyboard,
  MousePointer2,
  Play,
  Radar,
  RotateCcw,
  Skull,
  Sparkles,
  Store,
  Swords,
  Trash2,
  TrendingUp,
  Trophy,
  Volume2,
  VolumeX,
  Waves,
  Zap,
} from "lucide-react";
import { Btn, KeyCap, Meter, Panel, RankStamp, Ribbon, Stat } from "./Bits";
import { BoonIcon } from "./Bits";
import { UPGRADE_POOL } from "../game/upgrades";
import { DIFFICULTIES } from "../game/difficulty";
import RunChart from "./RunChart";
import type { HighScore, RunResult, UpgradeCard } from "../game/types";

const fmt = (n: number) => Math.round(n).toLocaleString("en-US");

const KILL_ORDER: [string, string, string][] = [
  ["phantom", "Phantoms", "#ff5b4d"],
  ["wisp", "Wisps", "#3fe6b8"],
  ["stalker", "Stalkers", "#b46cff"],
  ["revenant", "Revenants", "#ffc94a"],
  ["charger", "Chargers", "#ff9a4d"],
  ["warden", "Wardens", "#e2382f"],
];

const TICKER = [
  "phantoms · relentless hunters",
  "wisps · fast & brittle",
  "stalkers · split when slain",
  "revenants · fire soul bolts",
  "chargers · telegraphed lunge",
  "the warden · guards every 3rd depth of the crypt",
  "ashvale is a sanctuary · the woods are not",
  "gilded chests grant a boon on the spot",
  "graze a foe mid-dash for bonus score",
  "chain 15 harvests for a soul shower",
];

/* ============================ title ============================ */
export function StartScreen({
  onStart,
  onHelp,
  onScores,
  muted,
  onToggleMute,
  music,
  onToggleMusic,
  auto,
  onToggleAuto,
  best,
  hasTouch,
  touchOn,
  onToggleTouch,
  diff,
  setDiff,
  radar,
  onToggleRadar,
  fx,
  onToggleFx,
  onShop,
  bank,
}: {
  onShop: () => void;
  bank: number;
  diff: number;
  setDiff: (n: number) => void;
  radar: boolean;
  onToggleRadar: () => void;
  fx: boolean;
  onToggleFx: () => void;
  onStart: () => void;
  onHelp: () => void;
  onScores: () => void;
  muted: boolean;
  onToggleMute: () => void;
  music: boolean;
  onToggleMusic: () => void;
  auto: boolean;
  onToggleAuto: () => void;
  best: HighScore | null;
  hasTouch: boolean;
  touchOn: boolean;
  onToggleTouch: () => void;
}) {
  return (
    <div className="absolute inset-0 z-30 overflow-y-auto">
      {/* hero concept art — falls back to the gradient below if it can't load */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden bg-[radial-gradient(115%_85%_at_72%_28%,rgba(60,28,86,0.55),rgba(6,4,12,0.2)_46%,transparent_70%)]">
        <img
          src="images/reaper-hero.png"
          alt=""
          onError={(e) => ((e.currentTarget as HTMLImageElement).style.display = "none")}
          className="absolute right-0 top-0 h-full w-[min(74vw,900px)] object-cover object-[58%_18%] opacity-[0.88] [mask-image:linear-gradient(to_right,transparent,black_30%,black_84%,transparent)]"
        />
        <div className="absolute inset-0 bg-[linear-gradient(100deg,#06040c_16%,rgba(6,4,12,0.72)_42%,rgba(6,4,12,0.18)_66%,rgba(6,4,12,0.72))]" />
        <div className="absolute inset-0 bg-[radial-gradient(120%_90%_at_18%_10%,rgba(6,4,12,0.55),rgba(6,4,12,0.92)_60%,rgba(4,2,9,0.97))]" />
        <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-void-950 to-transparent" />
      </div>
      <div className="relative flex min-h-full w-full flex-col">
        <div className="grid flex-1 gap-6 p-4 sm:p-7 lg:p-10 lg:grid-cols-[1.1fr_0.9fr] xl:grid-cols-[1.2fr_0.8fr] items-end">
        {/* ---- left: identity ---- */}
        <div className="flex flex-col justify-end gap-5 pb-2 lg:pb-8">
          <div className="flex items-center gap-3">
            <Ribbon tone="hex">Chapter I · The Hollow Gate</Ribbon>
            <span className="hidden sm:flex items-center gap-1.5 font-head text-[10px] uppercase tracking-[0.3em] text-bone-500">
              <Skull className="w-3.5 h-3.5" /> open world · procedural crypt · 60fps
            </span>
          </div>

          <h1 className="leading-[0.78] select-none">
            <span className="block font-display text-[clamp(62px,13vw,168px)] text-bone-50 ink-stroke drop-shadow-[0_10px_30px_rgba(0,0,0,0.9)]">
              Soul
            </span>
            <span className="relative -mt-[0.12em] block">
              <span className="anim-flicker block font-display text-[clamp(62px,13vw,168px)] text-ember-500 ink-stroke [text-shadow:0_0_38px_rgba(255,106,31,0.45)]">
                Hunter
              </span>
              <span className="pointer-events-none absolute right-2 bottom-4 hidden sm:block font-head text-[10px] tracking-[0.5em] text-bone-500 -rotate-2">
                HARVEST THE DAMNED
              </span>
            </span>
          </h1>

          <p className="max-w-lg text-sm sm:text-base leading-relaxed text-bone-300">
            You are the last reaper of the Hollow Gate. Phantoms, wisps and wardens bleed soul-light when
            they fall — <span className="text-spectral-300 font-semibold">reap, harvest, chain the combo</span> and
            descend the <span className="text-hex-300 font-semibold">Hollow Crypt</span> beneath the ruins north of Ashvale. Loot the
            woods, cleanse each sealed chamber, and drown the dark in{" "}
            <span className="text-gold-300 font-semibold">Soul Frenzy</span> before the veil takes you.
          </p>

          {/* the character */}
          <div className="flex items-center gap-3 max-w-lg cut bg-void-900/78 border border-void-600/60 p-2.5 backdrop-blur-[2px]">
            <span
              className="relative shrink-0 w-14 h-14 overflow-hidden bg-[linear-gradient(150deg,#2c1e49,#0b0716)] shadow-[0_0_18px_-6px_rgba(255,201,74,0.6)]"
              style={{ clipPath: "polygon(50% 0,100% 25%,100% 75%,50% 100%,0 75%,0 25%)" }}
            >
              <img
                src="images/reaper-bust.png"
                alt="Vael, the last reaper"
                onError={(e) => ((e.currentTarget as HTMLImageElement).style.display = "none")}
                className="w-full h-full object-cover object-[50%_22%]"
              />
              <span className="absolute inset-0 ring-1 ring-inset ring-gold-400/40" />
            </span>
            <div className="min-w-0">
              <div className="font-head text-[11px] font-black uppercase tracking-[0.26em] text-gold-300">
                Vael · the last reaper
              </div>
              <p className="mt-0.5 text-[11px] leading-snug text-bone-500">
                Sentinel of the Hollow Gate, bonded to the crescent scythe{" "}
                <em className="text-bone-300 not-italic">Mournsong</em>. Every soul she reaps is one more year the gate
                holds.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <Btn variant="primary" size="lg" onClick={onStart} icon={<Play className="w-4 h-4 fill-current" />}>
              Enter the void
            </Btn>
            <Btn size="md" onClick={onShop} icon={<Store className="w-4 h-4 text-gold-300" />}>
              Bazaar <span className="num text-gold-300 ml-1">{bank.toLocaleString("en-US")}</span>
            </Btn>
            <Btn size="md" onClick={onHelp} icon={<Info className="w-4 h-4" />}>
              Codex
            </Btn>
            <Btn size="md" onClick={onScores} icon={<Trophy className="w-4 h-4" />}>
              Most feared
            </Btn>
          </div>

          <div className="flex items-center gap-2 text-[10px] font-head uppercase tracking-[0.22em] text-bone-500">
            <Keyboard className="w-3.5 h-3.5" />
            <KeyCap>W</KeyCap>
            <KeyCap>A</KeyCap>
            <KeyCap>S</KeyCap>
            <KeyCap>D</KeyCap>
            <span className="opacity-60">move</span>
            <KeyCap wide>Space</KeyCap>
            <span className="opacity-60">reap</span>
            <KeyCap>Shift</KeyCap>
            <span className="opacity-60">dash</span>
            {hasTouch && (
              <>
                <MousePointer2 className="w-3.5 h-3.5 ml-1" />
                <span className="opacity-60">touch pads enabled</span>
              </>
            )}
          </div>
        </div>

        {/* ---- right: dossier ---- */}
        <div className="flex flex-col gap-3 lg:items-stretch">
          <Panel className="p-4 sm:p-5">
            <div className="flex items-center justify-between">
              <span className="font-head text-[10px] font-black uppercase tracking-[0.3em] text-bone-300">
                Choose the rite
              </span>
              <Skull className="w-4 h-4 text-bone-700" />
            </div>
            <div className="mt-3 grid gap-1.5">
              {DIFFICULTIES.map((d) => {
                const on = d.id === diff;
                return (
                  <button
                    key={d.id}
                    onClick={() => setDiff(d.id)}
                    className={`group flex items-center gap-3 cut-sm border px-3 py-2 text-left transition-all cursor-pointer ${
                      on
                        ? "bg-void-800/90 border-transparent"
                        : "bg-void-950/50 border-void-600/50 hover:border-void-600 hover:bg-void-900/70"
                    }`}
                    style={on ? { borderColor: `${d.tone}88`, boxShadow: `inset 3px 0 0 ${d.tone}` } : undefined}
                  >
                    <span
                      className={`w-2.5 h-2.5 rotate-45 shrink-0 transition-all ${on ? "" : "opacity-30"}`}
                      style={{ background: d.tone, boxShadow: on ? `0 0 10px ${d.tone}` : "none" }}
                    />
                    <span className="min-w-0 flex-1">
                      <span className="flex items-baseline gap-2">
                        <span
                          className="font-head text-[13px] font-black uppercase tracking-[0.14em]"
                          style={{ color: on ? d.tone : "#cdc0a4" }}
                        >
                          {d.name}
                        </span>
                        <span className="font-head text-[9px] uppercase tracking-[0.18em] text-bone-700">
                          {d.kicker}
                        </span>
                      </span>
                      <span className="mt-0.5 block text-[11px] leading-snug text-bone-500 group-hover:text-bone-300">
                        {d.blurb}
                      </span>
                    </span>
                    {d.score !== 1 && (
                      <span className="num shrink-0 font-head text-[10px] font-black text-gold-300">
                        ×{d.score.toFixed(2)}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </Panel>

          <Panel className="p-4 sm:p-5" glow>
            <div className="flex items-center justify-between">
              <span className="font-head text-[10px] font-black uppercase tracking-[0.3em] text-gold-300">
                Rite tuning
              </span>
              <Sparkles className="w-4 h-4 text-hex-300" />
            </div>
            <div className="mt-3 grid gap-2">
              <ToggleRow
                label="Procedural SFX"
                hint="synthesised live — no audio files"
                on={!muted}
                icon={muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                onClick={onToggleMute}
              />
              <ToggleRow
                label="Synthwave dirge"
                hint="tempo rises with the waves"
                on={music}
                icon={<Waves className="w-4 h-4" />}
                onClick={onToggleMusic}
              />
              <ToggleRow
                label="Auto-reap"
                hint={hasTouch ? "recommended on touch" : "swing when a foe is in reach"}
                on={auto}
                icon={<Swords className="w-4 h-4" />}
                onClick={onToggleAuto}
              />
              <ToggleRow
                label="Touch rig"
                hint={hasTouch ? "detected — joystick + sigils" : "on-screen pads for any device"}
                on={touchOn}
                icon={<Gamepad className="w-4 h-4" />}
                onClick={onToggleTouch}
              />
              <ToggleRow
                label="Proximity radar"
                hint="off-screen foes, souls and the warden"
                on={radar}
                icon={<Radar className="w-4 h-4" />}
                onClick={onToggleRadar}
              />
              <ToggleRow
                label="Full spectacle"
                hint={fx ? "shake, flashes and dense embers" : "reduced motion — calmer screen"}
                on={fx}
                icon={<Sparkles className="w-4 h-4" />}
                onClick={onToggleFx}
              />
            </div>
          </Panel>

          <Panel className="p-4 sm:p-5">
            <div className="flex items-center justify-between">
              <span className="font-head text-[10px] font-black uppercase tracking-[0.3em] text-bone-300">
                Hall of records
              </span>
              <button onClick={onScores} className="flex items-center gap-1 text-[10px] font-head uppercase tracking-[0.2em] text-spectral-300 hover:text-gold-300 cursor-pointer">
                full table <ChevronRight className="w-3 h-3" />
              </button>
            </div>
            {best ? (
              <div className="mt-3 flex items-end justify-between gap-3">
                <div>
                  <div className="font-display text-4xl text-bone-50 leading-none">{best.name}</div>
                  <div className="num mt-1 text-[11px] font-bold text-bone-500">
                    depth {best.wave} · lv {best.level} · {best.kills} reaped
                  </div>
                </div>
                <div className="text-right">
                  <div className="num font-head text-3xl font-black text-gold-300 leading-none">{fmt(best.score)}</div>
                  <div className="font-head text-[9px] tracking-[0.3em] text-bone-500">rank {best.rank}</div>
                </div>
              </div>
            ) : (
              <div className="mt-3 text-xs text-bone-500">No records. The gate is unwritten.</div>
            )}
          </Panel>

          <div className="hidden lg:flex items-center gap-3 px-1 text-[10px] font-head uppercase tracking-[0.24em] text-bone-500">
            <Gauge className="w-3.5 h-3.5 text-spectral-400" />
            press <KeyCap wide>Enter</KeyCap> to begin
          </div>
        </div>
      </div>

      {/* threat ticker */}
      <div className="relative border-t border-void-700/70 bg-void-950/70 overflow-hidden">
        <div className="flex w-max anim-marquee gap-9 whitespace-nowrap py-2 pl-4 font-head text-[10px] uppercase tracking-[0.35em] text-bone-500/80">
          {[...TICKER, ...TICKER].map((t, i) => (
            <span key={i} className="flex items-center gap-2">
              <Flame className="w-3 h-3 text-ember-500/80" />
              {t}
            </span>
          ))}
        </div>
        <div className="pointer-events-none absolute inset-y-0 left-0 w-16 bg-gradient-to-r from-void-950 to-transparent" />
        <div className="pointer-events-none absolute inset-y-0 right-0 w-16 bg-gradient-to-l from-void-950 to-transparent" />
      </div>
      </div>
    </div>
  );
}

function ToggleRow({
  label,
  hint,
  on,
  icon,
  onClick,
}: {
  label: string;
  hint: string;
  on: boolean;
  icon: React.ReactNode;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`group flex items-center justify-between gap-3 cut-sm border px-3 py-2 text-left transition-all cursor-pointer ${
        on
          ? "bg-spectral-500/12 border-spectral-400/50 text-bone-50"
          : "bg-void-950/60 border-void-600/60 text-bone-500 hover:border-void-600 hover:text-bone-300"
      }`}
    >
      <span className="flex items-center gap-2.5">
        <span className={on ? "text-spectral-300" : "text-bone-700 group-hover:text-bone-500"}>{icon}</span>
        <span>
          <span className="block font-head text-[11px] font-bold uppercase tracking-[0.14em]">{label}</span>
          <span className="block text-[10px] text-bone-500">{hint}</span>
        </span>
      </span>
      <span
        className={`relative w-9 h-4 shrink-0 border transition-colors ${
          on ? "bg-spectral-500/40 border-spectral-300/70" : "bg-void-800 border-void-600"
        }`}
      >
        <span
          className={`absolute top-[1px] h-3 w-3 transition-all duration-200 ${
            on ? "left-[19px] bg-spectral-200" : "left-[2px] bg-bone-700"
          }`}
        />
      </span>
    </button>
  );
}

/* ============================ codex ============================ */
const BESTIARY = [
  { n: "Phantom", c: "#ff5b4d", d: "Homes in relentlessly. Easy meat, steady souls.", g: "hood" },
  { n: "Wisp", c: "#3fe6b8", d: "Fast, erratic, fragile. Chain-reap them for combos.", g: "diamond" },
  { n: "Stalker", c: "#b46cff", d: "Armoured hexagon. Bursts into two phantoms.", g: "hex" },
  { n: "Revenant", c: "#ffc94a", d: "Keeps distance and fires spreads of soul bolts.", g: "spindle" },
  { n: "Charger", c: "#ff9a4d", d: "Locks on, telegraphs a red line, then lunges.", g: "arrow" },
  { n: "Warden", c: "#e2382f", d: "Vault boss on every 3rd depth: bursts, charges, summons. Unseals the stairs.", g: "boss" },
];

export function HelpScreen({ onBack, onStart }: { onBack: () => void; onStart: () => void }) {
  return (
    <div className="absolute inset-0 z-30 overflow-y-auto bg-void-950/88 backdrop-blur-[2px] p-4 sm:p-6">
      <div className="mx-auto max-w-4xl w-full">
        <div className="flex items-center justify-between gap-4">
          <h2 className="font-display text-4xl sm:text-5xl text-bone-50">
            The <span className="text-ember-500">Codex</span>
          </h2>
          <Btn size="sm" onClick={onBack}>
            Back
          </Btn>
        </div>
        <div className="mt-1 font-head text-[10px] uppercase tracking-[0.35em] text-bone-500">
          rites of the harvest · read once, reap forever
        </div>

        {/* character dossier */}
        <Panel className="mt-4 overflow-hidden">
          <div className="relative h-32 sm:h-40">
            <img
              src="images/reaper-hero.png"
              alt="Vael, the last reaper of the Hollow Gate"
              onError={(e) => ((e.currentTarget as HTMLImageElement).style.display = "none")}
              className="absolute inset-0 h-full w-full object-cover object-[52%_16%]"
            />
            <div className="absolute inset-0 bg-[linear-gradient(92deg,rgba(6,4,12,0.96),rgba(6,4,12,0.42)_58%,rgba(6,4,12,0.86))]" />
            <div className="relative flex h-full flex-col justify-center px-4 sm:px-6">
              <div className="font-head text-[9px] uppercase tracking-[0.32em] text-gold-300">the protagonist</div>
              <div className="font-display text-3xl sm:text-4xl leading-none text-bone-50">
                Vael <span className="text-ember-500">of the Hollow Gate</span>
              </div>
              <p className="mt-1.5 max-w-md text-[11px] leading-relaxed text-bone-300">
                Bound to the crescent scythe <em className="not-italic text-bone-100">Mournsong</em>, she walks the
                necropolis with no face of her own — only the two cold lights where her eyes were. Her cloak carries the
                names of every soul she has carried back through the gate.
              </p>
            </div>
          </div>
        </Panel>

        <div className="mt-5 grid gap-3 md:grid-cols-2">
          <Panel className="p-4 sm:p-5">
            <div className="flex items-center gap-2 font-head text-[11px] font-black uppercase tracking-[0.28em] text-spectral-300">
              <Keyboard className="w-4 h-4" /> keyboard & mouse
            </div>
            <ul className="mt-3 grid gap-2 text-sm text-bone-300">
              {[
                [["W", "A", "S", "D"], "or arrows to glide the reaper"],
                [["Space"], "reap sweep — hold to keep swinging"],
                [["Shift"], "dash — invulnerable, grazes foes"],
                [["Q", "F", "C"], "arts — cyclone · lance · grave slam"],
                [["Right click"], "dash"],
                [["Mouse"], "aims the scythe; otherwise auto-aims"],
                [["P", "Esc"], "pause · R to restart"],
              ].map(([keys, txt], i) => (
                <li key={i} className="flex items-center gap-2.5">
                  <span className="flex gap-1 shrink-0">
                    {(keys as string[]).map((k) => (
                      <KeyCap key={k} wide={k.length > 3}>
                        {k}
                      </KeyCap>
                    ))}
                  </span>
                  <span className="text-[13px]">{txt as string}</span>
                </li>
              ))}
            </ul>
            <div className="mt-4 flex items-center gap-2 font-head text-[11px] font-black uppercase tracking-[0.28em] text-hex-300">
              <MousePointer2 className="w-4 h-4" /> touch
            </div>
            <p className="mt-2 text-[13px] text-bone-300">
              Left pad steers. Right pad: <span className="text-spectral-300">big sigil = reap</span>,{" "}
              <span className="text-ember-400">small sigil = dash</span>. Tap the right half of the arena for a quick
              sweep. Enable <em className="text-bone-100 not-italic">Auto-reap</em> to focus on movement.
            </p>
          </Panel>

          <Panel className="p-4 sm:p-5">
            <div className="flex items-center gap-2 font-head text-[11px] font-black uppercase tracking-[0.28em] text-gold-300">
              <Zap className="w-4 h-4" /> the loop
            </div>
            <ol className="mt-3 grid gap-2.5 text-[13px] text-bone-300 list-decimal pl-4 marker:text-gold-400 marker:font-bold">
              <li>
                <b className="text-bone-50">Reap</b> phantoms with your scythe arc — crits and executions print golden
                numbers.
              </li>
              <li>
                <b className="text-bone-50">Harvest</b> the soul-light they drop. Each pickup raises your chain
                multiplier (up to ×4).
              </li>
              <li>
                Chains fill <b className="text-gold-300">soul pressure</b>. At 100% you enter{" "}
                <b className="text-gold-300">SOUL FRENZY</b>: double damage, faster swings, arena-wide magnet, ×2 score.
              </li>
              <li>
                Essence levels you up — pick one of three <b className="text-hex-300">boons</b>. Stacking them mutates
                your build.
              </li>
              <li>
                <b className="text-spectral-300">Graze</b>: dash through an enemy at the last moment for bonus score,
                pressure and a slow-motion flourish.
              </li>
              <li>
                <b className="text-ember-400">The world:</b> Ashvale is safe ground. Thornwood and the Ember Glade hide
                chests and hauntings. The <b className="text-bone-50">Hollow Gate</b> in the northern ruins leads down.
              </li>
              <li>
                <b className="text-hex-300">The crypt:</b> each depth is a new maze. Entering a chamber seals its doors
                until it is cleansed. Find the stairs to descend — every 3rd depth the{" "}
                <b className="text-gore-400">Warden</b> guards them. Deeper means tougher foes and richer souls.
              </li>
              <li>
                <b className="text-bone-50">Three biomes cycle</b> as you descend: the violet{" "}
                <b className="text-hex-300">Hollow Crypt</b>, the olive-cobble{" "}
                <b className="text-[#c9d27a]">Mossgrave Barracks</b> (plank mess halls, cots, torches, an armoured
                garrison), and the lavender-stone <b className="text-[#b8ef3f]">Sewer Vault</b> — acid-green slime
                slows and burns you, rune chambers hum, revenants rain bolts.
              </li>
            </ol>
            <div className="mt-4 flex items-center gap-2 font-head text-[11px] font-black uppercase tracking-[0.28em] text-gold-300">
              <Radar className="w-4 h-4" /> awareness
            </div>
            <p className="mt-2 text-[13px] leading-relaxed text-bone-300">
              The necropolis is wider than your screen. The <b className="text-bone-50">proximity radar</b> on the right
              edge plots every soul, phantom and the warden, while <b className="text-bone-50">edge chevrons</b> point at
              threats just off-view — a red one means a charger is winding up its lunge. Turn the radar off in the rite
              tuning if you prefer the blind hunt.
            </p>

            <div className="mt-4 grid grid-cols-3 gap-2 text-center">
              {[
                ["pure soul", "#3fe6b8"],
                ["golden soul", "#ffc94a"],
                ["heart", "#8ef6da"],
              ].map(([t, c]) => (
                <div key={t} className="cut-sm bg-void-950/70 border border-void-600/60 py-2">
                  <span className="mx-auto block w-3 h-3 rotate-45" style={{ background: c as string, boxShadow: `0 0 12px ${c}` }} />
                  <span className="mt-1.5 block font-head text-[9px] uppercase tracking-[0.18em] text-bone-500">{t}</span>
                </div>
              ))}
            </div>
          </Panel>
        </div>

        <Panel className="mt-3 p-4 sm:p-5">
          <div className="flex items-center gap-2 font-head text-[11px] font-black uppercase tracking-[0.28em] text-gore-400">
            <Skull className="w-4 h-4" /> bestiary
          </div>
          <div className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {BESTIARY.map((b) => (
              <div key={b.n} className="flex items-start gap-3 cut-sm bg-void-950/60 border border-void-600/50 p-3">
                <svg viewBox="0 0 40 40" className="w-8 h-8 shrink-0">
                  {glyphOf(b)}
                </svg>
                <div>
                  <div className="font-head text-[12px] font-black tracking-[0.1em]" style={{ color: b.c }}>
                    {b.n.toUpperCase()}
                  </div>
                  <div className="text-[11px] leading-snug text-bone-500">{b.d}</div>
                </div>
              </div>
            ))}
          </div>
        </Panel>

        <div className="mt-4 mb-2 flex justify-center">
          <Btn variant="primary" size="lg" onClick={onStart} icon={<Play className="w-4 h-4 fill-current" />}>
            Begin the harvest
          </Btn>
        </div>
      </div>
    </div>
  );
}

function glyphOf(b: (typeof BESTIARY)[number]) {
  const c = b.c;
  switch (b.g) {
    case "diamond":
      return <polygon points="34,20 20,10 6,20 20,30" fill="#100a1c" stroke={c} strokeWidth="2" />;
    case "hex":
      return <polygon points="20,4 34,12 34,28 20,36 6,28 6,12" fill="#100a1c" stroke={c} strokeWidth="2" />;
    case "spindle":
      return <ellipse cx="20" cy="20" rx="9" ry="15" fill="#100a1c" stroke={c} strokeWidth="2" />;
    case "arrow":
      return <polygon points="36,20 8,8 14,20 8,32" fill="#100a1c" stroke={c} strokeWidth="2" />;
    case "boss":
      return (
        <>
          <circle cx="20" cy="20" r="12" fill="#100a1c" stroke={c} strokeWidth="2" />
          <circle cx="20" cy="20" r="17" fill="none" stroke={c} strokeOpacity="0.5" strokeDasharray="5 4" strokeWidth="1.5" />
        </>
      );
    default:
      return (
        <path
          d="M20 4 C28 10 30 20 28 32 C24 28 16 28 12 32 C10 20 12 10 20 4 Z"
          fill="#100a1c"
          stroke={c}
          strokeWidth="2"
        />
      );
  }
}

/* ============================ level up ============================ */
export function LevelUpScreen({
  choices,
  stacks,
  level,
  onPick,
}: {
  choices: UpgradeCard[];
  stacks: Record<string, number>;
  level: number;
  onPick: (id: string) => void;
}) {
  const tilt = ["lg:-rotate-2 lg:translate-y-3", "lg:rotate-0 lg:-translate-y-2", "lg:rotate-2 lg:translate-y-3", "lg:rotate-1"];
  return (
    <div className="absolute inset-0 z-30 flex flex-col items-center justify-center p-3 sm:p-6 bg-[radial-gradient(90%_70%_at_50%_40%,rgba(20,10,38,0.55),rgba(4,2,9,0.93))] backdrop-blur-[2px] overflow-y-auto">
      <div className="flex items-center gap-3 anim-pop">
        <Sparkles className="w-5 h-5 text-gold-300" />
        <span className="font-head text-[11px] font-black uppercase tracking-[0.35em] text-gold-300">
          Ascension · level {level}
        </span>
        <Sparkles className="w-5 h-5 text-gold-300" />
      </div>
      <h2 className="mt-1 font-display text-[clamp(34px,7vw,64px)] leading-none text-bone-50 ink-stroke">
        Choose your <span className="text-ember-500">boon</span>
      </h2>

      <div className={`mt-5 sm:mt-7 grid gap-3 sm:gap-4 w-full max-w-5xl ${choices.length > 3 ? "sm:grid-cols-2 lg:grid-cols-4" : "sm:grid-cols-3"}`}>
        {choices.map((c, i) => {
          const n = stacks[c.id] ?? 0;
          const tone =
            c.tier === "Forbidden"
              ? "border-gold-400/70 shadow-[0_0_40px_-14px_rgba(255,201,74,0.9)]"
              : c.tier === "Epic"
              ? "border-hex-400/60 shadow-[0_0_36px_-16px_rgba(180,108,255,0.8)]"
              : c.tier === "Rare"
              ? "border-spectral-400/50"
              : "border-void-600/80";
          return (
            <button
              key={c.id}
              onClick={() => onPick(c.id)}
              style={{ animationDelay: `${i * 70}ms` }}
              className={`group anim-pop relative text-left cut bg-[linear-gradient(170deg,rgba(29,18,48,0.96),rgba(9,5,18,0.97))] border-2 ${tone} p-4 sm:p-5 transition-all duration-200 hover:-translate-y-2 hover:rotate-0 cursor-pointer ${tilt[i % tilt.length]}`}
            >
              <span className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity bg-[radial-gradient(80%_60%_at_50%_0%,rgba(255,201,74,0.16),transparent_70%)] pointer-events-none" />
              <div className="flex items-start justify-between">
                <span className="inline-flex items-center justify-center w-11 h-11 cut-sm bg-void-950/80 border border-void-600/70 text-gold-300 group-hover:text-gold-200">
                  <BoonIcon name={c.icon} className="w-6 h-6" />
                </span>
                <span className="font-head text-[8px] font-black uppercase tracking-[0.24em] text-bone-500 group-hover:text-bone-300">
                  {c.tier}
                </span>
              </div>
              <div className="mt-3 font-head text-[15px] font-black uppercase tracking-[0.06em] text-bone-50">
                {c.name}
              </div>
              <p className="mt-1.5 text-[12px] leading-snug text-bone-300/90">{c.blurb}</p>
              <div className="mt-3.5 flex items-center justify-between">
                <span className="flex gap-1">
                  {Array.from({ length: c.max }).map((_, k) => (
                    <span
                      key={k}
                      className={`block w-2.5 h-2.5 rotate-45 border ${
                        k < n ? "bg-gold-400 border-gold-200" : "bg-void-800 border-void-600"
                      }`}
                    />
                  ))}
                </span>
                <span className="flex items-center gap-1 font-head text-[9px] uppercase tracking-[0.2em] text-spectral-300 opacity-0 group-hover:opacity-100 transition-opacity">
                  claim <ArrowUpRight className="w-3 h-3" />
                </span>
              </div>
            </button>
          );
        })}
      </div>
      <div className="mt-4 font-head text-[9px] uppercase tracking-[0.3em] text-bone-700">
        time is suspended while you choose
      </div>
    </div>
  );
}

/* ============================ pause ============================ */
export function PauseScreen({
  result,
  onResume,
  onRestart,
  onQuit,
  muted,
  onToggleMute,
  music,
  onToggleMusic,
  onShop,
}: {
  result: { score: number; level: number; wave: number; kills: number; combo: number };
  onResume: () => void;
  onRestart: () => void;
  onQuit: () => void;
  muted: boolean;
  onToggleMute: () => void;
  music: boolean;
  onToggleMusic: () => void;
  onShop?: () => void;
}) {
  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center p-4 bg-void-950/80 backdrop-blur-[3px]">
      <Panel className="w-full max-w-2xl p-5 sm:p-7" glow>
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <Ribbon tone="spectral">Veil suspended</Ribbon>
            <h2 className="mt-2 font-display text-[clamp(38px,8vw,70px)] leading-none text-bone-50">
              P<span className="text-ember-500">a</span>used
            </h2>
          </div>
          <div className="flex gap-2">
            <Btn size="sm" onClick={onToggleMute} icon={muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}>
              {muted ? "sfx off" : "sfx on"}
            </Btn>
            <Btn size="sm" onClick={onToggleMusic} icon={<Waves className="w-4 h-4" />}>
              {music ? "dirge on" : "dirge off"}
            </Btn>
          </div>
        </div>

        <div className="mt-5 grid grid-cols-2 sm:grid-cols-4 gap-2">
          <StatBox label="souls" value={fmt(result.score)} tone="gold" />
          <StatBox label="level" value={result.level} tone="hex" />
          <StatBox label="depth reached" value={result.wave} tone="spectral" />
          <StatBox label="best chain" value={`×${result.combo}`} tone="bone" />
        </div>

        <div className="mt-5 flex flex-wrap gap-2.5">
          <Btn variant="primary" size="lg" onClick={onResume} icon={<Play className="w-4 h-4 fill-current" />}>
            Resume reaping
          </Btn>
          <Btn variant="danger" size="md" onClick={onRestart} icon={<RotateCcw className="w-4 h-4" />}>
            Restart
          </Btn>
          {onShop && (
            <Btn size="md" onClick={onShop} icon={<Store className="w-4 h-4 text-gold-300" />}>
              Bazaar
            </Btn>
          )}
          <Btn size="md" onClick={onQuit}>
            Abandon run
          </Btn>
        </div>
        <div className="mt-3 flex items-center gap-2 text-[10px] font-head uppercase tracking-[0.22em] text-bone-500">
          <KeyCap>P</KeyCap> or <KeyCap>Esc</KeyCap> resume · <KeyCap>R</KeyCap> restart
        </div>
      </Panel>
    </div>
  );
}

function StatBox({ label, value, tone }: { label: string; value: React.ReactNode; tone: "gold" | "hex" | "spectral" | "bone" }) {
  return (
    <div className="cut-sm bg-void-950/70 border border-void-600/60 px-3 py-2.5">
      <Stat label={label} value={value} tone={tone} small />
    </div>
  );
}

/* ============================ game over ============================ */
export function OverScreen({
  result,
  bestScore,
  name,
  setName,
  onSubmit,
  submitted,
  onRestart,
  onMenu,
  onScores,
  onShop,
  bank = 0,
}: {
  onShop?: () => void;
  bank?: number;
  result: RunResult;
  bestScore: number;
  name: string;
  setName: (s: string) => void;
  onSubmit: (e: React.FormEvent) => void;
  submitted: boolean;
  onRestart: () => void;
  onMenu: () => void;
  onScores: () => void;
}) {
  const mins = Math.floor(result.time / 60);
  const secs = Math.floor(result.time % 60);
  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center p-3 sm:p-6 bg-[radial-gradient(100%_80%_at_50%_45%,rgba(60,8,12,0.4),rgba(4,2,9,0.95))] backdrop-blur-[2px] overflow-y-auto">
      <div className="w-full max-w-3xl">
        <div className="flex items-start justify-between gap-4">
          <div>
            <Ribbon tone="gore">The veil claims you</Ribbon>
            <h2 className="mt-2 font-display text-[clamp(44px,10vw,92px)] leading-[0.85] text-bone-50 ink-stroke">
              Soul <span className="text-gore-500">Reaped</span>
            </h2>
            <p className="mt-1.5 text-[13px] text-bone-500">
              Vael held the gate for{" "}
              <b className="text-bone-100 num">
                {mins}m {String(secs).padStart(2, "0")}s
              </b>{" "}
              and reached <b className="text-bone-100 num">depth {result.wave}</b> of the Hollow Crypt — the necropolis
              remembers her name.
            </p>
          </div>
          <div className="flex items-end gap-2 sm:gap-3 shrink-0">
            <div className="relative hidden sm:block w-16 h-16 lg:w-[74px] lg:h-[74px] overflow-hidden bg-[linear-gradient(150deg,#2c1e49,#0b0716)] border border-void-600/70">
              <img
                src="images/reaper-bust.png"
                alt="Vael"
                onError={(e) => ((e.currentTarget as HTMLImageElement).style.display = "none")}
                className="w-full h-full object-cover object-[50%_22%] grayscale-[35%]"
              />
              <span className="absolute inset-0 shadow-[inset_0_-14px_18px_-8px_rgba(4,2,9,0.9)]" />
              <span className="absolute inset-x-0 bottom-0 py-0.5 text-center font-head text-[7px] font-black uppercase tracking-[0.22em] text-gold-300/90 bg-void-950/85">
                Vael
              </span>
            </div>
            <RankStamp rank={result.rank} />
          </div>
        </div>

        <div className="mt-3 flex items-center gap-2 cut-sm bg-void-950/70 border-l-2 border-gold-400/70 px-3 py-2">
          <Store className="w-4 h-4 text-gold-300" />
          <span className="font-head text-[10px] uppercase tracking-[0.24em] text-bone-300">
            <b className="num text-gold-300">{fmt(result.score)}</b> souls banked for the bazaar · vault now holds{" "}
            <b className="num text-gold-200">{fmt(bank)}</b>
          </span>
        </div>

        {result.newRecord && (
          <div className="mt-3 anim-pop flex items-center gap-2 cut-sm bg-[linear-gradient(100deg,rgba(255,201,74,0.22),transparent)] border-l-2 border-gold-400 px-3 py-2">
            <Trophy className="w-4 h-4 text-gold-300" />
            <span className="font-head text-[11px] font-black uppercase tracking-[0.28em] text-gold-200">
              new personal record — best was {fmt(bestScore)}
            </span>
          </div>
        )}

        <Panel className="mt-4 p-4 sm:p-5">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <StatBox label="final souls" value={fmt(result.score)} tone="gold" />
            <StatBox label="level" value={result.level} tone="hex" />
            <StatBox label="phantoms reaped" value={result.kills} tone="spectral" />
            <StatBox label="harvested" value={result.harvest} tone="bone" />
          </div>
          <div className="mt-4 flex items-center gap-3">
            <span className="font-head text-[9px] uppercase tracking-[0.25em] text-bone-500 shrink-0">best chain</span>
            <div className="flex-1">
              <Meter value={Math.min(100, (result.bestCombo / 60) * 100)} tone="gold" height="h-1.5" />
            </div>
            <span className="num font-head text-lg font-black text-gold-300 leading-none">×{result.bestCombo}</span>
          </div>
          {result.boons.length > 0 && (
            <div className="mt-4">
              <span className="font-head text-[9px] uppercase tracking-[0.25em] text-bone-500">
                boons carried
              </span>
              <div className="mt-2 flex flex-wrap gap-1.5">
                {result.boons.map((b) => {
                  const meta = UPGRADE_POOL.find((u) => u.id === b.id);
                  return (
                    <span
                      key={b.id}
                      className="flex items-center gap-1.5 cut-sm bg-void-950/70 border border-void-600/60 px-2 py-1 transition-colors hover:border-gold-400/50"
                      title={meta?.blurb}
                    >
                      <BoonIcon name={meta?.icon ?? "sparkle"} className="w-3.5 h-3.5 text-gold-300" />
                      <span className="font-head text-[10px] uppercase tracking-[0.1em] text-bone-300">
                        {meta?.name ?? b.id}
                      </span>
                      <span className="num text-[10px] font-black text-spectral-300">×{b.n}</span>
                    </span>
                  );
                })}
              </div>
            </div>
          )}
        </Panel>

        <Panel className="mt-3 p-4 sm:p-5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="flex items-center gap-2 font-head text-[10px] font-black uppercase tracking-[0.28em] text-bone-300">
              <TrendingUp className="w-3.5 h-3.5 text-gold-300" /> run tempo
            </span>
            <span
              className="cut-sm px-2 py-0.5 font-head text-[9px] font-black uppercase tracking-[0.22em] border"
              style={{
                color: DIFFICULTIES[result.difficulty]?.tone,
                borderColor: `${DIFFICULTIES[result.difficulty]?.tone}66`,
                background: "rgba(6,4,12,0.6)",
              }}
            >
              {DIFFICULTIES[result.difficulty]?.name} rite
            </span>
          </div>

          <div className="mt-3">
            <RunChart points={result.timeline} />
          </div>

          <div className="mt-4 grid gap-x-5 gap-y-1.5 sm:grid-cols-2">
            {KILL_ORDER.map(([key, label, color]) => {
              const n = result.killsByKind[key] ?? 0;
              const max = Math.max(1, ...Object.values(result.killsByKind));
              return (
                <div key={key} className="flex items-center gap-2">
                  <span className="w-[86px] shrink-0 font-head text-[9px] uppercase tracking-[0.16em] text-bone-500">
                    {label}
                  </span>
                  <span className="flex-1 h-1.5 bg-void-950/80 border border-void-600/50 overflow-hidden">
                    <span
                      className="block h-full transition-[width] duration-500"
                      style={{ width: `${(n / max) * 100}%`, background: color, boxShadow: `0 0 8px ${color}` }}
                    />
                  </span>
                  <span className="num w-7 text-right text-[11px] font-black text-bone-100">{n}</span>
                </div>
              );
            })}
          </div>

          <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-[10px] font-head uppercase tracking-[0.18em] text-bone-500">
            <span>
              graze bonuses <b className="num text-spectral-300">{result.grazes}</b>
            </span>
            <span className="text-void-600">/</span>
            <span>
              essence harvested <b className="num text-hex-300">{result.harvest}</b>
            </span>
          </div>
        </Panel>

        <div className="mt-4 grid gap-3 sm:grid-cols-[1fr_auto] items-stretch">
          {submitted ? (
            <Panel className="p-3.5 flex items-center gap-3">
              <Award className="w-6 h-6 text-gold-300 shrink-0" />
              <div>
                <div className="font-head text-[11px] font-black uppercase tracking-[0.24em] text-gold-300">
                  Record inscribed
                </div>
                <div className="text-[12px] text-bone-500">The hall of records remembers {name || "the nameless"}.</div>
              </div>
            </Panel>
          ) : (
            <form onSubmit={onSubmit} className="flex gap-2">
              <input
                value={name}
                onChange={(e) => setName(e.target.value.slice(0, 14))}
                placeholder="Inscribe your name…"
                className="flex-1 min-w-0 cut-sm bg-void-900/90 border border-void-600/80 focus:border-gold-400/70 outline-none px-3 py-2 font-head text-sm tracking-[0.1em] text-bone-50 placeholder:text-bone-700"
              />
              <Btn variant="ghost" size="md" type="submit" icon={<ChevronRight className="w-4 h-4" />}>
                Submit
              </Btn>
            </form>
          )}
          <div className="flex flex-wrap gap-2">
            {onShop && (
              <Btn size="md" onClick={onShop} icon={<Store className="w-4 h-4 text-gold-300" />}>
                Bazaar <span className="num text-gold-300 ml-1">{bank.toLocaleString("en-US")}</span>
              </Btn>
            )}
            <Btn size="md" onClick={onScores} icon={<Trophy className="w-4 h-4" />}>
              Table
            </Btn>
            <Btn variant="primary" size="lg" onClick={onRestart} icon={<RotateCcw className="w-4 h-4" />}>
              Reap again
            </Btn>
          </div>
        </div>
        <div className="mt-3 flex flex-wrap items-center gap-2 text-[10px] font-head uppercase tracking-[0.22em] text-bone-500">
          <KeyCap wide>Enter</KeyCap> instant restart · <button onClick={onMenu} className="text-spectral-300 hover:text-gold-300 cursor-pointer underline decoration-dotted">
            return to the gate
          </button>
        </div>
      </div>
    </div>
  );
}

/* ============================ scores ============================ */
export function ScoreScreen({
  scores,
  onBack,
  onStart,
  onClear,
}: {
  scores: HighScore[];
  onBack: () => void;
  onStart: () => void;
  onClear: () => void;
}) {
  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center p-3 sm:p-6 bg-void-950/90 backdrop-blur-[3px] overflow-y-auto">
      <Panel className="w-full max-w-2xl p-4 sm:p-6" glow>
        <div className="flex items-start justify-between gap-3">
          <div>
            <Ribbon tone="gold">Local chronicle</Ribbon>
            <h2 className="mt-2 font-display text-[clamp(34px,7vw,58px)] leading-none text-bone-50">
              Hall of <span className="text-gold-400">Records</span>
            </h2>
          </div>
          <div className="flex gap-2">
            <Btn size="sm" onClick={onClear} icon={<Trash2 className="w-3.5 h-3.5" />}>
              clear
            </Btn>
            <Btn size="sm" onClick={onBack}>
              Back
            </Btn>
          </div>
        </div>

        <div className="mt-4 grid gap-1.5 max-h-[52vh] overflow-y-auto scroll-thin pr-1">
          {scores.length === 0 && <div className="py-10 text-center text-sm text-bone-500">The chronicle is empty.</div>}
          {scores.map((s, i) => (
            <div
              key={`${s.name}-${i}`}
              className={`flex items-center gap-3 cut-sm border px-3 py-2.5 transition-colors ${
                i === 0
                  ? "bg-[linear-gradient(100deg,rgba(255,201,74,0.16),rgba(9,5,18,0.6))] border-gold-400/50"
                  : i < 3
                  ? "bg-void-900/80 border-hex-400/30"
                  : "bg-void-950/60 border-void-600/50"
              }`}
            >
              <span
                className={`num shrink-0 w-8 h-8 flex items-center justify-center font-head text-sm font-black ${
                  i === 0
                    ? "bg-gold-400 text-void-950"
                    : i === 1
                    ? "bg-bone-300 text-void-950"
                    : i === 2
                    ? "bg-ember-700 text-bone-50"
                    : "bg-void-800 text-bone-500"
                }`}
                style={{ clipPath: "polygon(50% 0,100% 25%,100% 75%,50% 100%,0 75%,0 25%)" }}
              >
                {i + 1}
              </span>
              <div className="min-w-0 flex-1">
                <div className="font-display text-xl leading-none text-bone-50 truncate">{s.name}</div>
                <div className="num text-[10px] font-bold text-bone-500 mt-0.5">
                  lv {s.level} · depth {s.wave} · {s.kills} reaped · ×{s.combo} chain
                </div>
              </div>
              <div className="text-right shrink-0">
                <div className="num font-head text-lg font-black text-gold-300 leading-none">{fmt(s.score)}</div>
                <div className="font-head text-[9px] tracking-[0.2em] text-bone-700">
                  {s.rank} · {s.date}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-4 flex justify-center">
          <Btn variant="primary" size="lg" onClick={onStart} icon={<Swords className="w-4 h-4" />}>
            Take up the scythe
          </Btn>
        </div>
      </Panel>
    </div>
  );
}
