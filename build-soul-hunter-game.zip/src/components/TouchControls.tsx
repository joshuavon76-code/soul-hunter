import React, { useRef, useState } from "react";
import { Crosshair, Flame, Hammer, Store, Swords, Wind } from "lucide-react";
import type { SkillHud } from "../game/types";

/* Thumb-operated control rig. Left: floating joystick (anywhere in the zone).
   Right: reap + dash sigils. */
export default function TouchControls({
  onAxis,
  onSlashDown,
  onSlashUp,
  onDash,
  charges = 1,
  max = 1,
  onShop,
  skills = [],
  onSkill,
}: {
  skills?: SkillHud[];
  onSkill?: (i: number) => void;
  onAxis: (x: number, y: number) => void;
  onSlashDown: () => void;
  onSlashUp: () => void;
  onDash: () => void;
  charges?: number;
  max?: number;
  onShop?: () => void;
}) {
  const zoneRef = useRef<HTMLDivElement>(null);
  const pid = useRef<number | null>(null);
  const origin = useRef({ x: 0, y: 0 });
  const [stick, setStick] = useState<{ ox: number; oy: number; kx: number; ky: number; live: boolean }>({
    ox: 0,
    oy: 0,
    kx: 0,
    ky: 0,
    live: false,
  });
  const MAX = 52;

  const begin = (e: React.PointerEvent) => {
    if (pid.current !== null) return;
    const r = zoneRef.current!.getBoundingClientRect();
    pid.current = e.pointerId;
    (e.target as Element).setPointerCapture?.(e.pointerId);
    const ox = e.clientX - r.left;
    const oy = e.clientY - r.top;
    origin.current = { x: ox, y: oy };
    setStick({ ox, oy, kx: 0, ky: 0, live: true });
  };
  const move = (e: React.PointerEvent) => {
    if (pid.current !== e.pointerId) return;
    const r = zoneRef.current!.getBoundingClientRect();
    let dx = e.clientX - r.left - origin.current.x;
    let dy = e.clientY - r.top - origin.current.y;
    const d = Math.hypot(dx, dy) || 1;
    const cd = Math.min(d, MAX);
    dx = (dx / d) * cd;
    dy = (dy / d) * cd;
    setStick((s) => ({ ...s, kx: dx, ky: dy }));
    onAxis(dx / MAX, dy / MAX);
  };
  const end = (e: React.PointerEvent) => {
    if (pid.current !== e.pointerId) return;
    pid.current = null;
    onAxis(0, 0);
    setStick((s) => ({ ...s, live: false, kx: 0, ky: 0 }));
  };

  return (
    <div className="absolute inset-0 z-20 pointer-events-none select-none">
      {/* movement zone */}
      <div
        ref={zoneRef}
        onPointerDown={begin}
        onPointerMove={move}
        onPointerUp={end}
        onPointerCancel={end}
        className="absolute left-0 bottom-0 h-[46%] w-[52%] pointer-events-auto touch-none"
      >
        <div
          className={`absolute transition-opacity duration-200 ${stick.live ? "opacity-100" : "opacity-45"}`}
          style={{
            left: stick.live ? stick.ox - MAX - 10 : 58,
            top: stick.live ? stick.oy - MAX - 10 : "50%",
            width: (MAX + 10) * 2,
            height: (MAX + 10) * 2,
          }}
        >
          <div className="absolute inset-0 rounded-full border-2 border-dashed border-spectral-400/40" />
          <div
            className="absolute rounded-full bg-[radial-gradient(circle_at_35%_30%,rgba(199,255,240,0.95),rgba(18,199,154,0.55)_45%,rgba(11,7,22,0.75))] shadow-[0_0_26px_rgba(63,230,184,0.55)]"
            style={{
              width: 62,
              height: 62,
              left: MAX + 10 - 31 + stick.kx,
              top: MAX + 10 - 31 + stick.ky,
            }}
          />
          {!stick.live && (
            <span className="absolute inset-0 grid place-items-center font-head text-[9px] uppercase tracking-[0.3em] text-spectral-300/70">
              drag to move
            </span>
          )}
        </div>
      </div>

      {/* skill arts, stacked above the reap sigil */}
      {skills.length > 0 && onSkill && (
        <div className="absolute right-3 bottom-[124px] flex gap-2 pointer-events-auto">
          {skills.map((s, i) => {
            const ready = s.cd <= 0;
            const Icon = s.icon === "cyclone" ? Wind : s.icon === "lance" ? Crosshair : Hammer;
            return (
              <button
                key={s.id}
                aria-label={s.name}
                onPointerDown={(e) => {
                  e.preventDefault();
                  onSkill(i);
                }}
                className="relative w-[46px] h-[46px] cut-both border-2 bg-void-950/85 flex items-center justify-center active:scale-90 transition-transform"
                style={{
                  borderColor: ready ? s.color : "#2c1e49",
                  color: ready ? s.color : "#5d5344",
                  boxShadow: ready ? `0 0 16px -4px ${s.color}` : "none",
                }}
              >
                <Icon className="w-5 h-5" strokeWidth={2} />
                {!ready && (
                  <span
                    className="absolute inset-0"
                    style={{ background: `conic-gradient(rgba(6,4,12,0.82) ${(s.cd / s.max) * 360}deg, transparent 0deg)` }}
                  />
                )}
                <span className="absolute -top-2 left-1 bg-void-950 px-1 font-head text-[8px] font-black text-bone-300">{s.key}</span>
              </button>
            );
          })}
        </div>
      )}

      {/* action sigils */}
      <div className="absolute right-3 bottom-5 flex items-end gap-3 pointer-events-auto">
        {onShop && (
          <button
            onPointerDown={(e) => {
              e.preventDefault();
              onShop();
            }}
            className="w-[46px] h-[46px] mb-2 cut-both bg-void-900/90 border-2 border-gold-400/50 active:scale-90 transition-transform flex items-center justify-center text-gold-300"
            aria-label="Soul Bazaar"
          >
            <Store className="w-5 h-5" />
          </button>
        )}
        <button
          onPointerDown={(e) => {
            e.preventDefault();
            onDash();
          }}
          className={`w-[62px] h-[62px] cut-both border-2 active:scale-90 transition-all shadow-[0_0_24px_-6px_rgba(255,154,77,0.9)] flex flex-col items-center justify-center text-void-950 ${
            charges > 0
              ? "bg-[linear-gradient(155deg,rgba(255,192,138,0.95),rgba(185,61,7,0.92))] border-ember-300/60"
              : "bg-void-900/80 border-void-600/70 text-bone-700 shadow-none"
          }`}
        >
          <Flame className={`w-6 h-6 ${charges > 0 ? "" : "opacity-40"}`} strokeWidth={2.2} />
          <span className="font-head text-[8px] font-black uppercase tracking-[0.18em]">dash</span>
          <span className="mt-0.5 flex gap-[3px]">
            {Array.from({ length: Math.max(1, max) }).map((_, i) => (
              <span
                key={i}
                className={`block w-1.5 h-1.5 ${i < charges ? "bg-void-950" : "bg-void-950/25"}`}
                style={{ clipPath: "polygon(50% 0,100% 50%,50% 100%,0 50%)" }}
              />
            ))}
          </span>
        </button>
        <button
          onPointerDown={(e) => {
            e.preventDefault();
            onSlashDown();
          }}
          onPointerUp={onSlashUp}
          onPointerCancel={onSlashUp}
          onPointerLeave={onSlashUp}
          className="w-[96px] h-[96px] cut-both bg-[linear-gradient(155deg,rgba(200,255,240,0.95),rgba(18,199,154,0.85)_45%,rgba(10,125,99,0.95))] border-2 border-spectral-200/70 active:scale-90 transition-transform shadow-[0_0_38px_-6px_rgba(63,230,184,0.95)] flex flex-col items-center justify-center text-void-950"
        >
          <Swords className="w-9 h-9" strokeWidth={2.1} />
          <span className="font-head text-[10px] font-black uppercase tracking-[0.22em]">reap</span>
        </button>
      </div>
    </div>
  );
}
