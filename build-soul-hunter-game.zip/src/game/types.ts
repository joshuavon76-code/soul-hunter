/* ============ Shared game types ============ */

export type Tier = "Common" | "Rare" | "Epic" | "Forbidden";

export type IconKey =
  | "arc"
  | "blade"
  | "magnet"
  | "wind"
  | "sparkle"
  | "void"
  | "flame"
  | "heart"
  | "hourglass"
  | "bolt"
  | "shield"
  | "ring"
  | "echo"
  | "shock"
  | "thorn"
  | "skull"
  | "coin"
  | "book"
  | "ghost";

export interface Player {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  aim: number;

  hp: number;
  maxHp: number;
  invuln: number;
  shields: number;

  level: number;
  xp: number;
  xpNeed: number;
  score: number;
  combo: number;
  comboT: number;
  bestCombo: number;
  harvest: number;

  /* combat stats */
  dmg: number;
  dmgMult: number;
  arc: number; // half-angle of the reap sweep
  reach: number;
  slashCd: number;
  slashT: number;
  slashWindow: number;
  slashing: number; // frames left of active hitbox
  echo: number; // chance of a second delayed slash
  shock: number; // shockwave rings released per slash
  execute: number; // bonus dmg multiplier on wounded foes
  crit: number;
  critMult: number;
  thorns: number;
  lifesteal: number;
  soulGain: number;
  xpMult: number;
  greed: number; // score multiplier

  /* movement */
  speed: number;
  speedMult: number;
  dashCharges: number;
  maxDash: number;
  dashCd: number;
  dashCdMax: number;
  dashT: number;
  dashDur: number;
  dashVec: { x: number; y: number };
  dashTrail: boolean;
  grazes: number;

  /* utility */
  magnet: number;
  luck: number;
  orbit: number; // orbiting blades
  orbitDmg: number;
  orbitAngle: number;
  aura: number; // necrotic aura radius (0 = off)
  slowField: number; // chrono radius

  /* frenzy */
  frenzy: number; // 0..100
  frenzyOn: boolean;
  frenzyT: number;
  frenzyMax: number;
  frenzyMult: number;

  /* temporary buffs */
  rageT: number;

  stacked: Record<string, number>;
}

export type EnemyKind = "phantom" | "wisp" | "stalker" | "revenant" | "charger" | "warden";

export interface Enemy {
  id: number;
  kind: EnemyKind;
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  hp: number;
  maxHp: number;
  speed: number;
  dmg: number;
  score: number;
  xp: number;
  hue: string;
  face: number;
  hit: number; // flash frames
  born: number; // spawn-in animation
  state: number; // per-kind behaviour timer
  telegraph: number;
  fireT: number;
  spin: number;
  slow: number;
  contactCd: number;
  grazed: boolean;
  stun?: number;
  dead?: boolean;
}

export interface Bolt {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  dmg: number;
  life: number;
  color: string;
  hostile: boolean;
  pierce: number;
  hitIds?: number[];
}

export type SoulKind = "pure" | "gold" | "life" | "nova" | "rage" | "shield";

export interface Soul {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  kind: SoulKind;
  xp: number;
  score: number;
  t: number;
  pulled: boolean;
  life: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  life: number;
  maxLife: number;
  color: string;
  kind: 0 | 1 | 2 | 3; // 0 spark 1 ember 2 ring 3 smoke
  drag: number;
  add: boolean;
  spin?: number;
}

export interface FloatText {
  x: number;
  y: number;
  vy: number;
  life: number;
  maxLife: number;
  text: string;
  color: string;
  size: number;
  bold: boolean;
}

export interface SlashArc {
  x: number;
  y: number;
  angle: number;
  arc: number;
  reach: number;
  inner: number;
  life: number;
  maxLife: number;
  gold: boolean;
  dmg: number;
  targets: number[];
}

export interface UpgradeCard {
  id: string;
  name: string;
  blurb: string;
  icon: IconKey;
  tier: Tier;
  max: number;
  apply: (p: Player) => void;
}

export interface TimelinePoint {
  t: number;
  score: number;
  combo: number;
}

export interface RunResult {
  score: number;
  level: number;
  wave: number;
  kills: number;
  bestCombo: number;
  harvest: number;
  grazes: number;
  time: number;
  rank: string;
  newRecord: boolean;
  boons: { id: string; n: number }[];
  difficulty: number;
  killsByKind: Record<string, number>;
  timeline: TimelinePoint[];
}

export interface HudSnapshot {
  score: number;
  combo: number;
  comboPct: number;
  bestCombo: number;
  level: number;
  xpPct: number;
  xp: number;
  xpNeed: number;
  hp: number;
  maxHp: number;
  shields: number;
  dash: number;
  maxDash: number;
  dashPct: number;
  frenzy: number;
  frenzyOn: boolean;
  frenzyPct: number;
  wave: number;
  kills: number;
  time: number;
  bossHp: number;
  bossName: string;
  rage: number;
  boons: { id: string; n: number }[];
  zone: string;
  zoneSub: string;
  inCrypt: boolean;
  depth: number;
  roomsCleared: number;
  roomsTotal: number;
  chests: number;
  prompt: string;
  safe: boolean;
  skills?: SkillHud[];
}

export interface HighScore {
  name: string;
  score: number;
  level: number;
  wave: number;
  kills: number;
  combo: number;
  rank: string;
  date: string;
}

export interface SkillHud {
  id: string;
  name: string;
  key: string;
  cd: number;
  max: number;
  color: string;
  icon: "cyclone" | "lance" | "slam";
}

export type GamePhase = "attract" | "playing" | "paused" | "levelup" | "over" | "shop";
