export interface DifficultyDef {
  id: number;
  name: string;
  kicker: string;
  blurb: string;
  tone: string;
  spawn: number; // spawn cadence multiplier (higher = more enemies)
  hp: number;
  spd: number;
  invuln: number;
  frenzy: number; // soul-pressure gain rate
  score: number; // score multiplier
  magnet: number;
  hearts: number; // bonus starting hearts
}

export const DIFFICULTIES: DifficultyDef[] = [
  {
    id: 0,
    name: "Novice",
    kicker: "learn the sweep",
    blurb: "Sparser hauntings, forgiving recovery, an extra heart and wider soul pull.",
    tone: "#3fe6b8",
    spawn: 0.72,
    hp: 0.82,
    spd: 0.92,
    invuln: 1.5,
    frenzy: 1.3,
    score: 0.85,
    magnet: 1.3,
    hearts: 1,
  },
  {
    id: 1,
    name: "Reaper",
    kicker: "the intended rite",
    blurb: "Balanced escalation, chain-hungry scoring, standard frenzy gain.",
    tone: "#ffc94a",
    spawn: 1,
    hp: 1,
    spd: 1,
    invuln: 1,
    frenzy: 1,
    score: 1,
    magnet: 1,
    hearts: 0,
  },
  {
    id: 2,
    name: "Nightmare",
    kicker: "the veil is thin",
    blurb: "Relentless spawns, tougher and faster damned, ×1.45 souls, pressure drains faster.",
    tone: "#ff5b4d",
    spawn: 1.45,
    hp: 1.22,
    spd: 1.1,
    invuln: 0.8,
    frenzy: 0.86,
    score: 1.45,
    magnet: 0.92,
    hearts: 0,
  },
];

export const diffOf = (id: number) => DIFFICULTIES[Math.max(0, Math.min(2, id))];
