import type { AccessoryId, ScytheId } from "./gear";

const TAU = Math.PI * 2;
type G = CanvasRenderingContext2D;

/* ------------------------------------------------------------
   SCYTHES — drawn in weapon space: origin at the grip, +x along
   the shaft toward the head, blade curving to -y.  `r` = player r.
   ------------------------------------------------------------ */
export function drawScythe(g: G, id: ScytheId, r: number, t: number, slashing: boolean, frenzy: boolean) {
  switch (id) {
    case "ashthorn":
      return ashthorn(g, r, t, slashing);
    case "voidfang":
      return voidfang(g, r, t, slashing);
    case "crimsoneye":
      return crimsoneye(g, r, t, slashing);
    default:
      return mournsong(g, r, t, slashing, frenzy);
  }
}

function glowLine(g: G, color: string, w: number, a: number, path: () => void) {
  g.save();
  g.globalCompositeOperation = "lighter";
  g.globalAlpha = a;
  g.strokeStyle = color;
  g.lineWidth = w;
  g.lineCap = "round";
  g.beginPath();
  path();
  g.stroke();
  g.restore();
}

function mournsong(g: G, r: number, _t: number, slashing: boolean, frenzy: boolean) {
  const trim = frenzy ? "#ffd47a" : "#c79a4a";
  const bone = frenzy ? "#fff1d2" : "#e9dfc6";
  const eye = frenzy ? "#ffc94a" : "#3fe6b8";
  const L = r * 5.1;
  const shg = g.createLinearGradient(0, -r * 0.1, 0, r * 0.14);
  shg.addColorStop(0, "#5a3a22");
  shg.addColorStop(0.5, "#2e1c11");
  shg.addColorStop(1, "#160c08");
  g.fillStyle = shg;
  g.beginPath();
  g.moveTo(-r * 1.15, -r * 0.06);
  g.lineTo(L, -r * 0.16);
  g.lineTo(L, r * 0.02);
  g.lineTo(-r * 1.15, r * 0.12);
  g.closePath();
  g.fill();
  g.fillStyle = trim;
  for (let i = 0; i < 5; i++) g.fillRect(-r * 0.6 + i * r * 1.05, -r * 0.07, r * 0.16, r * 0.16);
  g.fillStyle = "#4a3a68";
  g.beginPath();
  g.arc(-r * 1.18, r * 0.03, r * 0.16, 0, TAU);
  g.fill();
  g.fillStyle = eye;
  g.beginPath();
  g.arc(-r * 1.18, r * 0.03, r * 0.085, 0, TAU);
  g.fill();
  const bx = L;
  g.beginPath();
  g.moveTo(bx - r * 0.16, -r * 0.14);
  g.quadraticCurveTo(bx + r * 1.22, -r * 0.42, bx + r * 1.02, -r * 1.72);
  g.quadraticCurveTo(bx + r * 0.52, -r * 1.12, bx - r * 0.1, -r * 0.52);
  g.closePath();
  const bgr = g.createLinearGradient(bx - r * 0.1, -r * 1.7, bx + r * 1.1, -r * 0.2);
  bgr.addColorStop(0, bone);
  bgr.addColorStop(0.55, frenzy ? "#ffe0a8" : "#d7e9df");
  bgr.addColorStop(1, frenzy ? "#c2652a" : "#7c9c92");
  g.fillStyle = bgr;
  g.fill();
  glowLine(g, eye, 2.2, 0.5 + (slashing ? 0.5 : 0), () => {
    g.moveTo(bx - r * 0.02, -r * 0.46);
    g.quadraticCurveTo(bx + r * 0.56, -r * 1.06, bx + r * 0.92, -r * 1.62);
  });
}

/* Ashthorn — black iron, crimson filigree, bone-white thorns, long swept blade */
function ashthorn(g: G, r: number, t: number, slashing: boolean) {
  const L = r * 5.4;
  // segmented black shaft with silver ferrules
  g.strokeStyle = "#17121a";
  g.lineWidth = r * 0.22;
  g.lineCap = "round";
  g.beginPath();
  g.moveTo(-r * 1.6, r * 0.08);
  g.quadraticCurveTo(r * 1.6, -r * 0.2, L, -r * 0.1);
  g.stroke();
  g.strokeStyle = "#3a2630";
  g.lineWidth = r * 0.08;
  g.beginPath();
  g.moveTo(-r * 1.5, r * 0.02);
  g.quadraticCurveTo(r * 1.6, -r * 0.26, L - r * 0.2, -r * 0.16);
  g.stroke();
  // crimson rune ticks
  g.strokeStyle = "#e2382f";
  g.lineWidth = 1.4;
  for (let i = 0; i < 9; i++) {
    const x = -r * 0.9 + i * r * 0.6;
    g.beginPath();
    g.moveTo(x, -r * 0.2);
    g.lineTo(x + r * 0.12, r * 0.02);
    g.stroke();
  }
  // ferrules + thorns along the shaft
  g.fillStyle = "#cfcbd6";
  for (const x of [-r * 0.2, r * 1.6, r * 3.4]) {
    g.fillRect(x, -r * 0.2, r * 0.14, r * 0.3);
    g.beginPath();
    g.moveTo(x + r * 0.07, -r * 0.2);
    g.lineTo(x + r * 0.07 - r * 0.16, -r * 0.62);
    g.lineTo(x + r * 0.07 + r * 0.16, -r * 0.2);
    g.closePath();
    g.fill();
  }
  // pommel: thorned reliquary
  g.fillStyle = "#1a1420";
  g.beginPath();
  g.moveTo(-r * 1.6, 0);
  g.lineTo(-r * 2.0, -r * 0.42);
  g.lineTo(-r * 2.5, 0);
  g.lineTo(-r * 2.0, r * 0.42);
  g.closePath();
  g.fill();
  g.strokeStyle = "#cfcbd6";
  g.lineWidth = 1.6;
  g.stroke();
  g.fillStyle = "#e2382f";
  g.beginPath();
  g.arc(-r * 2.0, 0, r * 0.12, 0, TAU);
  g.fill();
  // head: ornate black housing
  const hx = L;
  g.fillStyle = "#1a1420";
  g.beginPath();
  g.moveTo(hx - r * 0.5, r * 0.2);
  g.lineTo(hx - r * 0.3, -r * 0.5);
  g.lineTo(hx + r * 0.6, -r * 0.9);
  g.lineTo(hx + r * 1.3, -r * 0.6);
  g.lineTo(hx + r * 1.1, r * 0.1);
  g.lineTo(hx + r * 0.3, r * 0.5);
  g.closePath();
  g.fill();
  g.strokeStyle = "#cfcbd6";
  g.lineWidth = 1.8;
  g.stroke();
  // bone thorns on the housing
  g.fillStyle = "#e9e3ea";
  for (const [ax, ay, len] of [
    [hx + r * 0.2, r * 0.5, r * 0.6],
    [hx + r * 0.9, r * 0.3, r * 0.5],
    [hx - r * 0.45, -r * 0.1, r * 0.55],
  ]) {
    g.beginPath();
    g.moveTo(ax - r * 0.12, ay);
    g.lineTo(ax, ay + len);
    g.lineTo(ax + r * 0.12, ay);
    g.closePath();
    g.fill();
  }
  // crimson eye-sigil on the housing
  g.strokeStyle = "#ff5b4d";
  g.lineWidth = 1.6;
  g.beginPath();
  g.arc(hx + r * 0.5, -r * 0.3, r * 0.22, 0, TAU);
  g.stroke();
  // long swept blade
  g.beginPath();
  g.moveTo(hx + r * 0.6, -r * 0.9);
  g.quadraticCurveTo(hx + r * 2.2, -r * 1.3, hx + r * 1.6, -r * 3.1);
  g.quadraticCurveTo(hx + r * 1.4, -r * 1.7, hx + r * 1.3, -r * 0.6);
  g.closePath();
  const bg = g.createLinearGradient(hx + r * 0.6, -r * 0.8, hx + r * 1.8, -r * 3);
  bg.addColorStop(0, "#2b1f2a");
  bg.addColorStop(0.6, "#4a3540");
  bg.addColorStop(1, "#c81f2c");
  g.fillStyle = bg;
  g.fill();
  g.strokeStyle = "#d9d4de";
  g.lineWidth = 1.2;
  g.stroke();
  // red edge glow
  glowLine(g, "#ff3b3b", 2.4 + (slashing ? 2 : 0), 0.55 + (slashing ? 0.45 : 0) + Math.sin(t * 6) * 0.08, () => {
    g.moveTo(hx + r * 0.8, -r * 1.0);
    g.quadraticCurveTo(hx + r * 2.1, -r * 1.35, hx + r * 1.62, -r * 3.05);
  });
}

/* Voidfang — obsidian living crest with violet marrow-light */
function voidfang(g: G, r: number, t: number, slashing: boolean) {
  const L = r * 5.3;
  const pulse = 0.6 + Math.sin(t * 5) * 0.25;
  // twisted dark shaft (two strands)
  g.lineCap = "round";
  for (const [off, col, w] of [
    [0, "#1a1026", r * 0.2],
    [r * 0.1, "#2b1740", r * 0.09],
  ] as [number, string, number][]) {
    g.strokeStyle = col;
    g.lineWidth = w;
    g.beginPath();
    g.moveTo(-r * 1.8, off);
    for (let x = -r * 1.8; x <= L; x += r * 0.3) {
      g.lineTo(x, Math.sin(x / r * 2.4) * r * 0.1 - off * 0.5);
    }
    g.stroke();
  }
  // marrow-light slits along the shaft
  g.fillStyle = `rgba(217,120,255,${pulse})`;
  for (let i = 0; i < 6; i++) {
    const x = -r * 1.2 + i * r * 1.0;
    g.beginPath();
    g.ellipse(x, Math.sin(x / r * 2.4) * r * 0.1, r * 0.2, r * 0.06, 0, 0, TAU);
    g.fill();
  }
  // pommel loop
  g.strokeStyle = "#1a1026";
  g.lineWidth = r * 0.1;
  g.beginPath();
  g.ellipse(-r * 2.2, 0, r * 0.4, r * 0.22, 0, 0, TAU);
  g.stroke();
  g.strokeStyle = `rgba(217,120,255,${pulse})`;
  g.lineWidth = 2;
  g.stroke();
  // head: jagged crest
  const hx = L;
  g.fillStyle = "#1a1026";
  g.beginPath();
  g.moveTo(hx - r * 0.9, r * 0.1);
  const spikes: number[][] = [
    [hx - r * 1.3, -r * 0.5],
    [hx - r * 0.6, -r * 0.6],
    [hx - r * 0.9, -r * 1.2],
    [hx - r * 0.1, -r * 1.0],
    [hx - r * 0.2, -r * 1.8],
    [hx + r * 0.5, -r * 1.3],
    [hx + r * 0.7, -r * 2.1],
    [hx + r * 1.2, -r * 1.4],
    [hx + r * 1.8, -r * 1.7],
    [hx + r * 1.7, -r * 0.9],
    [hx + r * 1.2, -r * 0.3],
    [hx + r * 0.4, r * 0.3],
  ];
  for (const [x, y] of spikes) g.lineTo(x, y);
  g.closePath();
  g.fill();
  g.strokeStyle = "#3b2458";
  g.lineWidth = 1.5;
  g.stroke();
  // marrow pools
  g.fillStyle = `rgba(230,150,255,${pulse})`;
  for (const [x, y, rr] of [
    [hx - r * 0.5, -r * 0.6, r * 0.18],
    [hx + r * 0.2, -r * 1.1, r * 0.22],
    [hx + r * 0.9, -r * 1.2, r * 0.16],
    [hx + r * 1.3, -r * 0.7, r * 0.14],
    [hx - r * 0.1, -r * 0.2, r * 0.12],
  ]) {
    g.beginPath();
    g.ellipse(x, y, rr, rr * 0.6, -0.4, 0, TAU);
    g.fill();
  }
  // crescent blade
  g.beginPath();
  g.moveTo(hx + r * 1.2, -r * 1.4);
  g.quadraticCurveTo(hx + r * 3.0, -r * 1.6, hx + r * 2.6, -r * 3.2);
  g.quadraticCurveTo(hx + r * 2.3, -r * 2.0, hx + r * 1.7, -r * 1.7);
  g.closePath();
  const bg = g.createLinearGradient(hx + r, -r * 1.4, hx + r * 2.8, -r * 3);
  bg.addColorStop(0, "#2a1a3c");
  bg.addColorStop(0.5, "#b46cff");
  bg.addColorStop(1, "#f3dcff");
  g.fillStyle = bg;
  g.fill();
  glowLine(g, "#e3b1ff", 3 + (slashing ? 2.5 : 0), 0.5 + pulse * 0.4 + (slashing ? 0.4 : 0), () => {
    g.moveTo(hx + r * 1.4, -r * 1.45);
    g.quadraticCurveTo(hx + r * 2.9, -r * 1.7, hx + r * 2.58, -r * 3.1);
  });
  // ambient void glow
  g.save();
  g.globalCompositeOperation = "lighter";
  const gl = g.createRadialGradient(hx + r * 0.6, -r * 1.0, 0, hx + r * 0.6, -r * 1.0, r * 2.4);
  gl.addColorStop(0, `rgba(180,108,255,${0.28 * pulse})`);
  gl.addColorStop(1, "rgba(0,0,0,0)");
  g.fillStyle = gl;
  g.fillRect(hx - r * 2, -r * 3.6, r * 5, r * 4.4);
  g.restore();
}

/* Crimson Eye — ruby lacquer, pale steel, living eye in the crossguard */
function crimsoneye(g: G, r: number, t: number, slashing: boolean) {
  const L = r * 5.0;
  g.lineCap = "round";
  g.strokeStyle = "#2a0f16";
  g.lineWidth = r * 0.2;
  g.beginPath();
  g.moveTo(-r * 2.2, 0);
  g.lineTo(L, -r * 0.1);
  g.stroke();
  g.strokeStyle = "#5a1c26";
  g.lineWidth = r * 0.07;
  g.beginPath();
  g.moveTo(-r * 2.0, -r * 0.05);
  g.lineTo(L - r * 0.1, -r * 0.15);
  g.stroke();
  // pale-steel grip bands with ruby inlay
  for (const x of [r * 0.7, r * 2.6]) {
    g.fillStyle = "#e6e2dc";
    g.fillRect(x, -r * 0.22, r * 0.5, r * 0.34);
    g.fillStyle = "#ff2d4d";
    g.fillRect(x + r * 0.17, -r * 0.1, r * 0.16, r * 0.12);
  }
  // spear-point pommel
  g.fillStyle = "#e6e2dc";
  g.beginPath();
  g.moveTo(-r * 2.2, -r * 0.16);
  g.lineTo(-r * 3.3, 0);
  g.lineTo(-r * 2.2, r * 0.16);
  g.closePath();
  g.fill();
  g.fillStyle = "#c81f3c";
  g.beginPath();
  g.moveTo(-r * 2.3, -r * 0.08);
  g.lineTo(-r * 3.0, 0);
  g.lineTo(-r * 2.3, r * 0.08);
  g.closePath();
  g.fill();
  // crossguard: ornate winged housing
  const hx = L;
  g.fillStyle = "#3a1118";
  g.beginPath();
  g.moveTo(hx - r * 0.6, r * 0.5);
  g.lineTo(hx - r * 0.4, -r * 0.9);
  g.lineTo(hx + r * 0.3, -r * 1.5);
  g.lineTo(hx + r * 1.0, -r * 1.0);
  g.lineTo(hx + r * 1.3, -r * 0.2);
  g.lineTo(hx + r * 0.6, r * 0.6);
  g.closePath();
  g.fill();
  g.strokeStyle = "#e6e2dc";
  g.lineWidth = 2;
  g.stroke();
  // pale steel flanges
  g.fillStyle = "#e6e2dc";
  for (const [ax, ay, bx, by] of [
    [hx - r * 0.4, -r * 0.9, hx - r * 1.3, -r * 1.6],
    [hx + r * 1.0, -r * 1.0, hx + r * 2.0, -r * 1.4],
    [hx + r * 0.6, r * 0.6, hx + r * 0.9, r * 1.5],
  ]) {
    g.beginPath();
    g.moveTo(ax - r * 0.14, ay + r * 0.1);
    g.lineTo(bx, by);
    g.lineTo(ax + r * 0.14, ay - r * 0.1);
    g.closePath();
    g.fill();
  }
  // the eye
  const blink = (Math.sin(t * 0.9) > 0.97 ? 0.15 : 1);
  g.fillStyle = "#f7e6e8";
  g.beginPath();
  g.ellipse(hx + r * 0.4, -r * 0.5, r * 0.34, r * 0.22 * blink, -0.3, 0, TAU);
  g.fill();
  g.fillStyle = "#ff2d4d";
  g.beginPath();
  g.ellipse(hx + r * 0.4, -r * 0.5, r * 0.16, r * 0.2 * blink, -0.3, 0, TAU);
  g.fill();
  g.fillStyle = "#1a0408";
  g.beginPath();
  g.ellipse(hx + r * 0.4, -r * 0.5, r * 0.05, r * 0.17 * blink, -0.3, 0, TAU);
  g.fill();
  g.save();
  g.globalCompositeOperation = "lighter";
  const gl = g.createRadialGradient(hx + r * 0.4, -r * 0.5, 0, hx + r * 0.4, -r * 0.5, r * 1.1);
  gl.addColorStop(0, "rgba(255,45,77,0.5)");
  gl.addColorStop(1, "rgba(0,0,0,0)");
  g.fillStyle = gl;
  g.fillRect(hx - r, -r * 1.7, r * 3, r * 2.4);
  g.restore();
  // crimson blade: long, slender, downward sweep
  g.beginPath();
  g.moveTo(hx + r * 1.3, -r * 0.2);
  g.quadraticCurveTo(hx + r * 3.6, -r * 0.1, hx + r * 3.4, -r * 2.9);
  g.quadraticCurveTo(hx + r * 2.6, -r * 1.2, hx + r * 1.0, -r * 1.0);
  g.closePath();
  const bg = g.createLinearGradient(hx + r, -r * 0.4, hx + r * 3.4, -r * 2.8);
  bg.addColorStop(0, "#5a0c1c");
  bg.addColorStop(0.55, "#d8142f");
  bg.addColorStop(1, "#ff6b7d");
  g.fillStyle = bg;
  g.fill();
  g.strokeStyle = "#f3dfe2";
  g.lineWidth = 1.2;
  g.stroke();
  glowLine(g, "#ff6b7d", 2.4 + (slashing ? 2.4 : 0), 0.55 + (slashing ? 0.45 : 0), () => {
    g.moveTo(hx + r * 1.5, -r * 0.3);
    g.quadraticCurveTo(hx + r * 3.5, -r * 0.25, hx + r * 3.36, -r * 2.8);
  });
}

/* ------------------------------------------------------------
   ACCESSORIES drawn on the body.  World space, origin at player.
   ------------------------------------------------------------ */
export function drawWings(g: G, id: AccessoryId, r: number, t: number, moving: number, flow: number, dashing: boolean) {
  if (id === "emberveil") return emberveil(g, r, t, moving);
  return duskwings(g, r, t, moving, flow, dashing);
}

function feather(g: G, len: number, w: number, a0: number, a1: number, ink: string, wine: string) {
  // single tapered feather with a dark edge and wine core
  g.beginPath();
  g.moveTo(0, 0);
  g.quadraticCurveTo(len * 0.45, -w, len, -w * 0.25);
  g.quadraticCurveTo(len * 0.5, w * 0.4, 0, w * 0.5);
  g.closePath();
  const grd = g.createLinearGradient(0, 0, len, 0);
  grd.addColorStop(0, wine);
  grd.addColorStop(0.55, a0 > a1 ? "#3b1f3c" : "#2b1a33");
  grd.addColorStop(1, ink);
  g.fillStyle = grd;
  g.fill();
}

function duskwings(g: G, r: number, t: number, moving: number, flow: number, dashing: boolean) {
  const flap = Math.sin(t * (dashing ? 14 : 2.2)) * (0.12 + moving * 0.22 + (dashing ? 0.3 : 0));
  const spread = 0.55 + moving * 0.35 + (dashing ? 0.5 : 0);
  g.save();
  g.translate(0, -r * 0.5);
  // wings trail against motion
  g.rotate(flow + Math.PI / 2 - Math.PI / 2);
  for (const side of [-1, 1]) {
    // upper wing
    for (let w = 0; w < 2; w++) {
      const upper = w === 0;
      const baseA = side * (upper ? -0.9 : 0.35) * spread + flap * side;
      const count = upper ? 9 : 7;
      const L = r * (upper ? 3.6 : 2.6);
      for (let i = 0; i < count; i++) {
        const k = i / (count - 1);
        const a = baseA + side * (k - 0.5) * (upper ? 1.3 : 1.1);
        const len = L * (0.55 + Math.sin(k * Math.PI) * 0.6) * (1 - k * 0.15);
        g.save();
        g.rotate(a);
        feather(g, len, r * 0.26 * (1 - k * 0.3), a, baseA, "#120b16", "#8d1b3d");
        g.restore();
      }
      // white eye-spot on the wing
      g.save();
      g.rotate(baseA);
      g.translate(L * 0.42, -r * 0.1);
      g.fillStyle = "rgba(255,255,255,0.9)";
      g.beginPath();
      g.ellipse(0, 0, r * 0.26, r * 0.16, 0.3 * side, 0, TAU);
      g.fill();
      g.fillStyle = "#8d1b3d";
      g.beginPath();
      g.ellipse(0, 0, r * 0.12, r * 0.08, 0.3 * side, 0, TAU);
      g.fill();
      g.restore();
      // bead chain
      g.save();
      g.rotate(baseA + side * 0.35);
      g.strokeStyle = "rgba(220,205,230,0.55)";
      g.lineWidth = 1;
      g.beginPath();
      g.moveTo(L * 0.3, 0);
      g.quadraticCurveTo(L * 0.6, r * 0.5, L * 0.95, r * 0.25);
      g.stroke();
      g.fillStyle = "#e9dfc6";
      for (let b = 0; b < 3; b++) {
        const k = 0.35 + b * 0.25;
        g.beginPath();
        g.arc(L * k, r * 0.28 * Math.sin(k * Math.PI), 1.6, 0, TAU);
        g.fill();
      }
      g.restore();
    }
  }
  g.restore();
}

function emberveil(g: G, r: number, t: number, moving: number) {
  g.save();
  g.globalCompositeOperation = "lighter";
  for (let i = 0; i < 10; i++) {
    const a = t * 1.3 + (i / 10) * TAU;
    const d = r * (1.5 + Math.sin(t * 2 + i) * 0.3 + moving * 0.4);
    const x = Math.cos(a) * d;
    const y = Math.sin(a) * d * 0.55 + r * 0.3;
    const grd = g.createRadialGradient(x, y, 0, x, y, r * 0.45);
    grd.addColorStop(0, "rgba(255,154,77,0.55)");
    grd.addColorStop(1, "rgba(0,0,0,0)");
    g.fillStyle = grd;
    g.fillRect(x - r * 0.45, y - r * 0.45, r * 0.9, r * 0.9);
  }
  g.restore();
}

export function drawCharm(g: G, id: AccessoryId, r: number, t: number) {
  if (id === "boneward") {
    g.strokeStyle = "rgba(90,58,36,0.9)";
    g.lineWidth = 1.2;
    g.beginPath();
    g.moveTo(-r * 0.3, -r * 0.5);
    g.quadraticCurveTo(0, r * 0.05, r * 0.3, -r * 0.5);
    g.stroke();
    g.fillStyle = "#e9dfc6";
    g.beginPath();
    g.ellipse(0, r * 0.02, r * 0.1, r * 0.14, 0, 0, TAU);
    g.fill();
  } else if (id === "soulchain") {
    g.fillStyle = "#3fe6b8";
    for (let i = 0; i < 7; i++) {
      const k = i / 6;
      const x = -r * 0.34 + k * r * 0.68;
      const y = -r * 0.45 + Math.sin(k * Math.PI) * r * 0.45;
      g.globalAlpha = 0.6 + Math.sin(t * 4 + i) * 0.3;
      g.beginPath();
      g.arc(x, y, r * 0.05, 0, TAU);
      g.fill();
    }
    g.globalAlpha = 1;
  }
}

export function drawTrinket(g: G, id: AccessoryId, r: number, t: number, headX: number, headY: number) {
  if (id === "hollowcrown") {
    g.save();
    g.translate(headX, headY - r * 0.95);
    g.strokeStyle = "#2b2033";
    g.lineWidth = 2.2;
    g.beginPath();
    g.moveTo(-r * 0.6, 0);
    g.lineTo(r * 0.6, 0);
    g.stroke();
    g.fillStyle = "#d9a6ff";
    for (let i = -2; i <= 2; i++) {
      const h = r * (0.26 + (2 - Math.abs(i)) * 0.09);
      g.globalAlpha = 0.7 + Math.sin(t * 3 + i) * 0.3;
      g.beginPath();
      g.moveTo(i * r * 0.26 - r * 0.07, 0);
      g.lineTo(i * r * 0.26, -h);
      g.lineTo(i * r * 0.26 + r * 0.07, 0);
      g.closePath();
      g.fill();
    }
    g.globalAlpha = 1;
    g.restore();
  } else if (id === "gravelantern") {
    g.save();
    g.translate(-r * 0.95, r * 0.2 + Math.sin(t * 3) * 1.5);
    g.rotate(Math.sin(t * 2.2) * 0.15);
    g.strokeStyle = "#3a2a1e";
    g.lineWidth = 1.4;
    g.beginPath();
    g.moveTo(0, -r * 0.4);
    g.lineTo(0, 0);
    g.stroke();
    g.fillStyle = "#3a2a1e";
    g.fillRect(-r * 0.14, 0, r * 0.28, r * 0.34);
    g.fillStyle = "#ffcf6a";
    g.fillRect(-r * 0.09, r * 0.05, r * 0.18, r * 0.22);
    g.globalCompositeOperation = "lighter";
    const gl = g.createRadialGradient(0, r * 0.16, 0, 0, r * 0.16, r * 0.7);
    gl.addColorStop(0, "rgba(255,201,74,0.5)");
    gl.addColorStop(1, "rgba(0,0,0,0)");
    g.fillStyle = gl;
    g.fillRect(-r * 0.7, -r * 0.5, r * 1.4, r * 1.4);
    g.restore();
  }
}
