/* ============================================================
   VAEL — the last reaper.  Drawn entirely with canvas paths so
   it scales, animates and recolours instead of being a sprite.
   ============================================================ */

import type { AccessoryId, ScytheId } from "./gear";
import { drawCharm, drawScythe, drawTrinket, drawWings } from "./gearArt";

const TAU = Math.PI * 2;

export interface ReaperView {
  scythe: ScytheId;
  wings: AccessoryId | null;
  charm: AccessoryId | null;
  trinket: AccessoryId | null;
  t: number;
  x: number;
  y: number;
  r: number;
  aim: number;
  frenzy: boolean;
  dashing: boolean;
  slash: number; // 0 idle → 1 full swing progress
  arc: number;
  reach: number;
  vx: number;
  vy: number;
  moving: number; // 0..1
  blink: boolean;
}

interface Pal {
  cloak: string;
  cloakDeep: string;
  lining: string;
  trim: string;
  bone: string;
  eye: string;
  metal: string;
}

function palette(frenzy: boolean): Pal {
  return frenzy
    ? {
        cloak: "#6d1a2c",
        cloakDeep: "#2b0813",
        lining: "#c2451a",
        trim: "#ffd47a",
        bone: "#fff1d2",
        eye: "#ffc94a",
        metal: "#8a5a1c",
      }
    : {
        cloak: "#331c52",
        cloakDeep: "#150c26",
        lining: "#7d1c33",
        trim: "#c79a4a",
        bone: "#e9dfc6",
        eye: "#3fe6b8",
        metal: "#4a3a68",
      };
}

/** cheap after-image for the dash trail */
export function drawReaperGhost(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  r: number,
  aim: number,
  color: string,
  alpha: number
) {
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.fillStyle = color;
  // cloak silhouette
  ctx.beginPath();
  ctx.moveTo(x - r * 1.05, y + r * 1.35);
  ctx.quadraticCurveTo(x - r * 1.2, y - r * 0.2, x, y - r * 1.5);
  ctx.quadraticCurveTo(x + r * 1.2, y - r * 0.2, x + r * 1.05, y + r * 1.35);
  ctx.quadraticCurveTo(x, y + r * 0.85, x - r * 1.05, y + r * 1.35);
  ctx.closePath();
  ctx.fill();
  // hood peak
  ctx.beginPath();
  ctx.moveTo(x - r * 0.72, y - r * 0.62);
  ctx.quadraticCurveTo(x - r * 0.1 + Math.cos(aim) * 3, y - r * 1.85, x + r * 0.72, y - r * 0.62);
  ctx.quadraticCurveTo(x, y - r * 0.28, x - r * 0.72, y - r * 0.62);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

export function drawReaper(ctx: CanvasRenderingContext2D, v: ReaperView) {
  const { x, y, r, t } = v;
  const pal = palette(v.frenzy);
  const bob = Math.sin(t * 3.05) * 1.5 * (1 - v.moving * 0.5);
  const breathe = Math.sin(t * 2.1) * 0.5 + 0.5;
  const flow = v.moving > 0.06 ? Math.atan2(-v.vy, -v.vx) : v.aim + Math.PI;

  /* ---------- 1. ground shadow + soul flame ---------- */
  ctx.save();
  ctx.fillStyle = "rgba(0,0,0,0.52)";
  ctx.beginPath();
  ctx.ellipse(x, y + r * 1.22, r * (1.12 + v.moving * 0.12), r * 0.38, 0, 0, TAU);
  ctx.fill();
  ctx.globalCompositeOperation = "lighter";
  const flame = ctx.createRadialGradient(x, y + r * 1.15, 0, x, y + r * 1.15, r * 1.5);
  flame.addColorStop(0, v.frenzy ? "rgba(255,140,60,0.5)" : "rgba(63,230,184,0.34)");
  flame.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = flame;
  ctx.fillRect(x - r * 1.6, y - r * 0.4, r * 3.2, r * 3.2);
  ctx.globalCompositeOperation = "source-over";
  ctx.restore();

  /* ---------- 1b. wings / mantle (behind everything) ---------- */
  if (v.wings) {
    ctx.save();
    ctx.translate(x, y);
    drawWings(ctx, v.wings, r, t, v.moving, flow, v.dashing);
    ctx.restore();
  }

  /* ---------- 2. halo ring (behind the head) ---------- */
  const headX = x + Math.cos(v.aim) * r * 0.14;
  const headY = y - r * 0.72 + bob;
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  const haloR = r * (1.42 + breathe * 0.04);
  ctx.strokeStyle = v.frenzy ? "rgba(255,212,122,0.85)" : "rgba(199,154,74,0.5)";
  ctx.lineWidth = v.frenzy ? 2.2 : 1.4;
  ctx.setLineDash([10, 9]);
  ctx.lineDashOffset = -t * (v.frenzy ? 90 : 26);
  ctx.beginPath();
  ctx.arc(headX, headY, haloR, 0, TAU);
  ctx.stroke();
  ctx.setLineDash([]);
  // six rune shards orbiting the halo
  for (let i = 0; i < 6; i++) {
    const a = t * (v.frenzy ? 1.5 : 0.5) + (i / 6) * TAU;
    const rx = headX + Math.cos(a) * haloR;
    const ry = headY + Math.sin(a) * haloR;
    ctx.save();
    ctx.translate(rx, ry);
    ctx.rotate(a + Math.PI / 4);
    ctx.fillStyle = v.frenzy ? "#ffe9b8" : "#c79a4a";
    ctx.globalAlpha = 0.55 + Math.sin(t * 3 + i) * 0.25;
    ctx.fillRect(-2.6, -2.6, 5.2, 5.2);
    ctx.restore();
  }
  ctx.globalAlpha = 1;
  ctx.restore();

  /* ---------- 3. cape ---------- */
  ctx.save();
  ctx.translate(x, y - r * 0.28);
  ctx.rotate(flow + Math.PI / 2);
  const L = r * (2.25 + v.moving * 1.35 + (v.dashing ? 1.25 : 0));
  const W = r * 1.22;
  const sway = (i: number) => Math.sin(t * (3.1 + i * 0.35) + i * 1.7) * (r * 0.2 + v.moving * r * 0.22);

  const capePath = (scale: number, len: number) => {
    const w = W * scale;
    ctx.beginPath();
    ctx.moveTo(-w * 0.82, -r * 0.18);
    ctx.quadraticCurveTo(-w * 1.28, len * 0.42, -w * 0.72, len * 0.9);
    for (let i = 0; i < 5; i++) {
      const k0 = i / 5;
      const k1 = (i + 1) / 5;
      const x0 = -w * 0.72 + w * 1.44 * k0;
      const x1 = -w * 0.72 + w * 1.44 * k1;
      const dip = len * (0.9 + 0.16 * Math.sin(t * 3 + i * 1.35)) + sway(i) * 0.35;
      const mid = (x0 + x1) / 2;
      const midY = dip + (i % 2 ? -len * 0.11 : len * 0.02) + sway(i);
      ctx.quadraticCurveTo(mid * 1.02, midY, x1, len * 0.92 + sway(i + 1) * 0.25);
    }
    ctx.quadraticCurveTo(w * 1.28, len * 0.42, w * 0.82, -r * 0.18);
    ctx.quadraticCurveTo(0, r * 0.12, -w * 0.82, -r * 0.18);
    ctx.closePath();
  };

  // tattered wisps flying off the cape
  ctx.globalCompositeOperation = "lighter";
  for (let i = 0; i < 3; i++) {
    const a = -0.5 + i * 0.5 + Math.sin(t * 1.6 + i) * 0.16;
    ctx.globalAlpha = 0.16;
    ctx.fillStyle = pal.trim;
    ctx.beginPath();
    ctx.moveTo(Math.sin(a) * W * 0.5, L * 0.2);
    ctx.quadraticCurveTo(Math.sin(a) * W * 1.5, L * 0.72, Math.sin(a) * W * 2.1 + sway(i) * 1.4, L * 1.32);
    ctx.quadraticCurveTo(Math.sin(a) * W * 1.2, L * 0.8, Math.sin(a) * W * 0.42, L * 0.28);
    ctx.closePath();
    ctx.fill();
  }
  ctx.globalAlpha = 1;
  ctx.globalCompositeOperation = "source-over";

  // outer cloak
  capePath(1, L);
  const cg = ctx.createLinearGradient(0, -r, 0, L);
  cg.addColorStop(0, pal.cloak);
  cg.addColorStop(0.55, pal.cloakDeep);
  cg.addColorStop(1, pal.cloakDeep);
  ctx.fillStyle = cg;
  ctx.fill();

  // crimson lining
  capePath(0.82, L * 0.9);
  const lg = ctx.createLinearGradient(0, 0, 0, L * 0.9);
  lg.addColorStop(0, pal.lining);
  lg.addColorStop(1, "rgba(20,8,26,0.2)");
  ctx.fillStyle = lg;
  ctx.globalAlpha = 0.75;
  ctx.fill();
  ctx.globalAlpha = 1;

  // gold trim along the hem
  capePath(1.005, L * 1.005);
  ctx.strokeStyle = pal.trim;
  ctx.globalAlpha = 0.55;
  ctx.lineWidth = 1.5;
  ctx.stroke();
  ctx.globalAlpha = 1;
  ctx.restore();

  /* ---------- 4. robe / body ---------- */
  ctx.save();
  ctx.translate(x, y + bob * 0.4);
  const hemY = r * 1.42;
  ctx.beginPath();
  ctx.moveTo(-r * 0.86, -r * 0.42);
  ctx.quadraticCurveTo(-r * 1.02, r * 0.5, -r * 1.12, hemY);
  for (let i = 0; i < 4; i++) {
    const k0 = i / 4;
    const k1 = (i + 1) / 4;
    const x0 = -r * 1.12 + r * 2.24 * k0;
    const x1 = -r * 1.12 + r * 2.24 * k1;
    const mid = (x0 + x1) / 2;
    ctx.quadraticCurveTo(mid, hemY + (i % 2 ? -r * 0.14 : r * 0.1) + Math.sin(t * 2.4 + i) * r * 0.05, x1, hemY);
  }
  ctx.quadraticCurveTo(r * 1.02, r * 0.5, r * 0.86, -r * 0.42);
  ctx.quadraticCurveTo(0, -r * 0.1, -r * 0.86, -r * 0.42);
  ctx.closePath();
  const bg = ctx.createLinearGradient(0, -r * 0.5, 0, hemY);
  bg.addColorStop(0, pal.cloak);
  bg.addColorStop(0.6, pal.cloakDeep);
  bg.addColorStop(1, "#0c0618");
  ctx.fillStyle = bg;
  ctx.fill();

  // centre sash of lining
  ctx.beginPath();
  ctx.moveTo(-r * 0.2, -r * 0.3);
  ctx.lineTo(-r * 0.3, hemY - r * 0.06);
  ctx.lineTo(r * 0.3, hemY - r * 0.06);
  ctx.lineTo(r * 0.2, -r * 0.3);
  ctx.closePath();
  ctx.fillStyle = pal.lining;
  ctx.globalAlpha = 0.5;
  ctx.fill();
  ctx.globalAlpha = 1;

  // belt + sigil
  ctx.fillStyle = pal.metal;
  ctx.fillRect(-r * 0.72, r * 0.3, r * 1.44, r * 0.17);
  ctx.strokeStyle = pal.trim;
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.arc(0, r * 0.385, r * 0.15, 0, TAU);
  ctx.stroke();
  ctx.save();
  ctx.translate(0, r * 0.385);
  ctx.rotate(Math.PI / 4 + t * 0.25);
  ctx.fillStyle = v.frenzy ? "#ffd47a" : "#7ee0c4";
  ctx.fillRect(-r * 0.075, -r * 0.075, r * 0.15, r * 0.15);
  ctx.restore();

  /* ---------- 5. bone chest plate + pauldrons ---------- */
  // chest
  ctx.beginPath();
  ctx.moveTo(-r * 0.62, -r * 0.44);
  ctx.quadraticCurveTo(0, -r * 0.72, r * 0.62, -r * 0.44);
  ctx.quadraticCurveTo(r * 0.5, r * 0.16, 0, r * 0.3);
  ctx.quadraticCurveTo(-r * 0.5, r * 0.16, -r * 0.62, -r * 0.44);
  ctx.closePath();
  const pg = ctx.createLinearGradient(0, -r * 0.7, 0, r * 0.3);
  pg.addColorStop(0, pal.bone);
  pg.addColorStop(1, "#a3947a");
  ctx.fillStyle = pg;
  ctx.fill();
  // ribs
  ctx.strokeStyle = "rgba(40,22,60,0.5)";
  ctx.lineWidth = 1.4;
  for (let i = 0; i < 3; i++) {
    const yy = -r * 0.3 + i * r * 0.19;
    ctx.beginPath();
    ctx.moveTo(-r * (0.52 - i * 0.08), yy);
    ctx.quadraticCurveTo(0, yy + r * 0.13, r * (0.52 - i * 0.08), yy);
    ctx.stroke();
  }
  // clasp gem
  ctx.fillStyle = v.frenzy ? "#ff6a1f" : "#3fe6b8";
  ctx.beginPath();
  ctx.arc(0, -r * 0.22, r * 0.1, 0, TAU);
  ctx.fill();
  if (v.charm) drawCharm(ctx, v.charm, r, t);

  // pauldrons
  for (const s of [-1, 1]) {
    ctx.save();
    ctx.translate(s * r * 0.82, -r * 0.5);
    ctx.rotate(s * (0.24 + breathe * 0.03));
    ctx.beginPath();
    ctx.moveTo(-r * 0.3, r * 0.06);
    ctx.quadraticCurveTo(-r * 0.18, -r * 0.42, r * 0.2, -r * 0.34);
    ctx.lineTo(r * 0.34, r * 0.14);
    ctx.closePath();
    const sgr = ctx.createLinearGradient(0, -r * 0.42, 0, r * 0.14);
    sgr.addColorStop(0, pal.bone);
    sgr.addColorStop(1, pal.metal);
    ctx.fillStyle = sgr;
    ctx.fill();
    ctx.strokeStyle = pal.trim;
    ctx.lineWidth = 1.1;
    ctx.globalAlpha = 0.7;
    ctx.stroke();
    ctx.globalAlpha = 1;
    // spikes
    ctx.fillStyle = pal.bone;
    for (let i = 0; i < 2; i++) {
      ctx.beginPath();
      ctx.moveTo(-r * 0.24 + i * r * 0.28, -r * 0.32 - i * r * 0.06);
      ctx.lineTo(-r * 0.16 + i * r * 0.28, -r * 0.62 - i * r * 0.05);
      ctx.lineTo(-r * 0.06 + i * r * 0.28, -r * 0.3 - i * r * 0.05);
      ctx.closePath();
      ctx.fill();
    }
    ctx.restore();
  }
  ctx.restore();

  /* ---------- 6. hood + face ---------- */
  ctx.save();
  ctx.translate(headX, headY);
  ctx.rotate(v.aim * 0.1);
  // hood shell
  ctx.beginPath();
  ctx.moveTo(-r * 0.92, r * 0.58);
  ctx.quadraticCurveTo(-r * 1.06, -r * 0.62, -r * 0.16, -r * 1.12);
  ctx.quadraticCurveTo(r * 0.62, -r * 1.28, r * 0.92, r * 0.52);
  ctx.quadraticCurveTo(r * 0.2, r * 0.86, -r * 0.92, r * 0.58);
  ctx.closePath();
  const hg = ctx.createLinearGradient(0, -r * 1.3, 0, r * 0.9);
  hg.addColorStop(0, pal.cloak);
  hg.addColorStop(1, pal.cloakDeep);
  ctx.fillStyle = hg;
  ctx.fill();
  // gold hood seam
  ctx.strokeStyle = pal.trim;
  ctx.globalAlpha = 0.5;
  ctx.lineWidth = 1.3;
  ctx.beginPath();
  ctx.moveTo(-r * 0.86, r * 0.5);
  ctx.quadraticCurveTo(-r * 1.0, -r * 0.55, -r * 0.2, -r * 1.04);
  ctx.stroke();
  ctx.globalAlpha = 1;

  // face void
  ctx.beginPath();
  ctx.ellipse(Math.cos(v.aim) * r * 0.1, -r * 0.18, r * 0.56, r * 0.62, 0, 0, TAU);
  const vg = ctx.createRadialGradient(0, -r * 0.24, r * 0.05, 0, -r * 0.18, r * 0.66);
  vg.addColorStop(0, "#150b26");
  vg.addColorStop(1, "#04020a");
  ctx.fillStyle = vg;
  ctx.fill();

  // bone half-mask
  ctx.beginPath();
  ctx.moveTo(-r * 0.5, -r * 0.02);
  ctx.quadraticCurveTo(0, r * 0.62, r * 0.5, -r * 0.02);
  ctx.quadraticCurveTo(0, r * 0.26, -r * 0.5, -r * 0.02);
  ctx.closePath();
  ctx.fillStyle = pal.bone;
  ctx.globalAlpha = 0.92;
  ctx.fill();
  ctx.globalAlpha = 1;
  ctx.strokeStyle = "rgba(30,16,48,0.55)";
  ctx.lineWidth = 1.1;
  for (let i = -1; i <= 1; i++) {
    ctx.beginPath();
    ctx.moveTo(i * r * 0.16, r * 0.1);
    ctx.lineTo(i * r * 0.18, r * 0.34);
    ctx.stroke();
  }

  // eyes (additive)
  ctx.globalCompositeOperation = "lighter";
  const eyeY = -r * 0.3;
  for (const s of [-1, 1]) {
    const ex = Math.cos(v.aim) * r * 0.12 + s * r * 0.235;
    const grd = ctx.createRadialGradient(ex, eyeY, 0, ex, eyeY, r * 0.34);
    grd.addColorStop(0, pal.eye);
    grd.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = grd;
    ctx.fillRect(ex - r * 0.34, eyeY - r * 0.34, r * 0.68, r * 0.68);
    ctx.save();
    ctx.translate(ex, eyeY);
    ctx.rotate(s * 0.34 + Math.cos(v.aim) * 0.12);
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(-r * 0.17, -r * 0.055, r * 0.34, r * 0.11);
    ctx.restore();
  }
  // third eye when frenzying
  if (v.frenzy) {
    const gy = -r * 0.62;
    const g2 = ctx.createRadialGradient(0, gy, 0, 0, gy, r * 0.3);
    g2.addColorStop(0, "#fff2c4");
    g2.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = g2;
    ctx.fillRect(-r * 0.3, gy - r * 0.3, r * 0.6, r * 0.6);
  }
  ctx.globalCompositeOperation = "source-over";
  ctx.restore();

  /* ---------- 6b. trinket (crown / lantern) ---------- */
  if (v.trinket) {
    ctx.save();
    ctx.translate(x, y);
    drawTrinket(ctx, v.trinket, r, t, headX - x, headY - y);
    ctx.restore();
  }

  /* ---------- 7. the scythe (equipped weapon) ---------- */
  ctx.save();
  ctx.translate(x, y - r * 0.16 + bob * 0.5);
  // the blade sweeps across the whole arc while the reap fires
  const swingA =
    v.slash > 0
      ? v.aim - v.arc * 1.15 + Math.min(1, v.slash) * v.arc * 2.3
      : v.aim + Math.sin(t * 1.25) * 0.075;
  ctx.rotate(swingA);
  drawScythe(ctx, v.scythe, r, t, v.slash > 0, v.frenzy);
  ctx.restore();
}

/** Standalone preview for the shop — weapon drawn horizontally in a box */
export function drawScythePreview(ctx: CanvasRenderingContext2D, id: ScytheId, w: number, h: number, t: number) {
  ctx.clearRect(0, 0, w, h);
  const r = Math.min(w / 11, h / 6.5);
  ctx.save();
  ctx.translate(w * 0.28, h * 0.7);
  ctx.rotate(-0.42);
  drawScythe(ctx, id, r, t, false, false);
  ctx.restore();
}

export function drawAccessoryPreview(ctx: CanvasRenderingContext2D, id: AccessoryId, w: number, h: number, t: number) {
  ctx.clearRect(0, 0, w, h);
  const r = Math.min(w, h) / 6.2;
  ctx.save();
  ctx.translate(w / 2, h / 2);
  if (id === "duskwings" || id === "emberveil") {
    drawWings(ctx, id, r, t, 0.3, Math.PI / 2, false);
    // small silhouette so the wings have a body
    ctx.fillStyle = "rgba(20,12,30,0.9)";
    ctx.beginPath();
    ctx.ellipse(0, r * 0.2, r * 0.6, r * 1.1, 0, 0, TAU);
    ctx.fill();
  } else if (id === "hollowcrown" || id === "gravelantern") {
    ctx.scale(2.2, 2.2);
    drawTrinket(ctx, id, r, t, 0, r * 0.9);
  } else {
    ctx.scale(2.6, 2.6);
    ctx.translate(0, r * 0.2);
    drawCharm(ctx, id, r, t);
  }
  ctx.restore();
}
