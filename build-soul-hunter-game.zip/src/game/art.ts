/* ==============================================================
   ART — procedural cartoon props & tiles (chunky ink outlines,
   flat fills, painted highlights). Everything is cached once.
   ============================================================== */

export const TILE = 64;
const TAU = Math.PI * 2;
const INK = "#2a1a14";

export interface Sprite {
  cv: HTMLCanvasElement;
  ax: number; // anchor x (draw at x - ax)
  ay: number; // anchor y (draw at y - ay)
}

type G = CanvasRenderingContext2D;
const cache = new Map<string, Sprite>();

function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function mk(key: string, w: number, h: number, ax: number, ay: number, draw: (g: G) => void): Sprite {
  const hit = cache.get(key);
  if (hit) return hit;
  const cv = document.createElement("canvas");
  cv.width = Math.ceil(w);
  cv.height = Math.ceil(h);
  const g = cv.getContext("2d")!;
  g.lineJoin = "round";
  g.lineCap = "round";
  draw(g);
  const s = { cv, ax, ay };
  cache.set(key, s);
  return s;
}

function ink(g: G, w = 2.4) {
  g.strokeStyle = INK;
  g.lineWidth = w;
}
function rrect(g: G, x: number, y: number, w: number, h: number, r: number) {
  g.beginPath();
  g.moveTo(x + r, y);
  g.arcTo(x + w, y, x + w, y + h, r);
  g.arcTo(x + w, y + h, x, y + h, r);
  g.arcTo(x, y + h, x, y, r);
  g.arcTo(x, y, x + w, y, r);
  g.closePath();
}
function poly(g: G, pts: number[][]) {
  g.beginPath();
  pts.forEach(([x, y], i) => (i ? g.lineTo(x, y) : g.moveTo(x, y)));
  g.closePath();
}
function shade(hex: string, k: number) {
  const n = parseInt(hex.slice(1), 16);
  const r = Math.max(0, Math.min(255, ((n >> 16) & 255) * k));
  const gg = Math.max(0, Math.min(255, ((n >> 8) & 255) * k));
  const b = Math.max(0, Math.min(255, (n & 255) * k));
  return `rgb(${r | 0},${gg | 0},${b | 0})`;
}

/* ======================= TILES ======================= */
export const enum T {
  VOID = 0,
  GRASS = 1,
  DIRT = 2,
  PATH = 3,
  WATER = 4,
  WALL = 5,
  FLOOR = 6,
  DWALL = 7,
  AUTUMN = 8,
  SEAL = 9,
  RUIN = 10,
  /* biome 2 — mossgrave barracks */
  MFLOOR = 11,
  MMOSS = 12,
  MPLANK = 13,
  MWALL = 14,
  /* biome 3 — sewer vault */
  SFLOOR = 15,
  SLIME = 16,
  SWALL = 17,
  RUNE = 18,
  BLOOD = 19,
}

export const isSlime = (t: number) => t === T.SLIME;

export function getTile(type: number, v: number): HTMLCanvasElement {
  return mk(`tile${type}_${v}`, TILE, TILE, 0, 0, (g) => {
    paintTile(g, type, v);
  }).cv;
}

function paintTile(g: G, type: number, v: number) {
  {
    const r = rng(1000 + type * 97 + v * 13);
    switch (type) {
      case T.GRASS:
      case T.AUTUMN: {
        const aut = type === T.AUTUMN;
        g.fillStyle = aut ? "#a9893c" : "#7a9b3d";
        g.fillRect(0, 0, TILE, TILE);
        for (let i = 0; i < 9; i++) {
          g.fillStyle = aut
            ? ["#b8973f", "#9b7a30", "#c2a24a"][i % 3]
            : ["#6c8d34", "#88ad48", "#719537"][i % 3];
          g.beginPath();
          g.ellipse(r() * TILE, r() * TILE, 8 + r() * 12, 5 + r() * 8, r() * 3, 0, TAU);
          g.fill();
        }
        g.strokeStyle = aut ? "#7d5f22" : "#52742a";
        g.lineWidth = 1.6;
        for (let i = 0; i < 7; i++) {
          const x = r() * TILE;
          const y = r() * TILE;
          g.beginPath();
          g.moveTo(x, y);
          g.lineTo(x - 3, y - 7);
          g.moveTo(x + 2, y);
          g.lineTo(x + 5, y - 6);
          g.stroke();
        }
        if (aut) {
          for (let i = 0; i < 6; i++) {
            g.fillStyle = ["#d8702a", "#c04526", "#e59a3a"][i % 3];
            g.beginPath();
            g.ellipse(r() * TILE, r() * TILE, 3.2, 2, r() * 3, 0, TAU);
            g.fill();
          }
        }
        break;
      }
      case T.DIRT: {
        g.fillStyle = "#b99b6b";
        g.fillRect(0, 0, TILE, TILE);
        for (let i = 0; i < 6; i++) {
          g.fillStyle = i % 2 ? "#a88a5c" : "#c5a877";
          g.beginPath();
          g.ellipse(r() * TILE, r() * TILE, 10 + r() * 12, 6 + r() * 7, r() * 3, 0, TAU);
          g.fill();
        }
        for (let i = 0; i < 5; i++) {
          const x = r() * TILE;
          const y = r() * TILE;
          g.fillStyle = "#8f8375";
          g.beginPath();
          g.ellipse(x, y, 3, 2.2, 0, 0, TAU);
          g.fill();
          g.strokeStyle = "rgba(42,26,20,0.5)";
          g.lineWidth = 1;
          g.stroke();
        }
        break;
      }
      case T.PATH:
      case T.RUIN: {
        const ruin = type === T.RUIN;
        g.fillStyle = ruin ? "#6f6a63" : "#8d7c62";
        g.fillRect(0, 0, TILE, TILE);
        const n = 2 + (v % 2);
        const s = TILE / n;
        for (let i = 0; i < n; i++)
          for (let j = 0; j < n; j++) {
            if (ruin && r() < 0.18) continue;
            const x = i * s + 2 + r() * 2;
            const y = j * s + 2 + r() * 2;
            const w = s - 5 - r() * 3;
            const h = s - 5 - r() * 3;
            g.fillStyle = (ruin ? ["#9a948b", "#8a847b", "#a39d94"] : ["#bba98b", "#ad9b7e", "#c7b595"])[(i + j + v) % 3];
            rrect(g, x, y, w, h, 5);
            g.fill();
            g.strokeStyle = "rgba(42,26,20,0.65)";
            g.lineWidth = 1.8;
            g.stroke();
            g.fillStyle = "rgba(255,255,255,0.14)";
            g.fillRect(x + 3, y + 2, w - 6, 3);
          }
        if (ruin || r() < 0.4) {
          g.fillStyle = ruin ? "#6f8f3a" : "#7a9b3d";
          g.beginPath();
          g.ellipse(r() * TILE, r() * TILE, 7, 4, r(), 0, TAU);
          g.fill();
        }
        break;
      }
      case T.WATER: {
        g.fillStyle = "#3b6fb2";
        g.fillRect(0, 0, TILE, TILE);
        g.strokeStyle = "#6c9edb";
        g.lineWidth = 2;
        for (let i = 0; i < 4; i++) {
          const x = r() * TILE;
          const y = r() * TILE;
          g.beginPath();
          g.ellipse(x, y, 8 + r() * 8, 3, 0, 0, Math.PI);
          g.stroke();
        }
        g.fillStyle = "rgba(255,255,255,0.35)";
        for (let i = 0; i < 3; i++) g.fillRect(r() * TILE, r() * TILE, 5, 2);
        break;
      }
      case T.WALL: {
        // village curtain wall: battlement top band, stone face
        g.fillStyle = "#cbc4b5";
        g.fillRect(0, 0, TILE, TILE);
        g.fillStyle = "#b4ad9e";
        g.fillRect(0, 18, TILE, 46);
        g.strokeStyle = "rgba(42,26,20,0.55)";
        g.lineWidth = 1.6;
        for (let row = 0; row < 3; row++) {
          const y = 18 + row * 15;
          g.beginPath();
          g.moveTo(0, y);
          g.lineTo(TILE, y);
          g.stroke();
          for (let c = 0; c < 3; c++) {
            const x = ((c * 21 + (row % 2) * 10) % TILE) + r() * 3;
            g.beginPath();
            g.moveTo(x, y);
            g.lineTo(x, y + 15);
            g.stroke();
          }
        }
        // merlons
        g.fillStyle = "#e0d9ca";
        for (let i = 0; i < 3; i++) {
          g.fillRect(i * 22 + 2, 0, 16, 16);
          ink(g, 2);
          g.strokeRect(i * 22 + 2, 0, 16, 16);
        }
        g.fillStyle = "#4a4046";
        for (let i = 0; i < 2; i++) g.fillRect(i * 22 + 19, 0, 5, 12);
        g.fillStyle = "rgba(0,0,0,0.18)";
        g.fillRect(0, 56, TILE, 8);
        break;
      }
      case T.FLOOR: {
        g.fillStyle = "#3b3b4b";
        g.fillRect(0, 0, TILE, TILE);
        const n = 2;
        const s = TILE / n;
        for (let i = 0; i < n; i++)
          for (let j = 0; j < n; j++) {
            const x = i * s + 2;
            const y = j * s + 2;
            g.fillStyle = ["#6a6c7d", "#5e6071", "#73758a", "#656779"][(i + j * 2 + v) % 4];
            rrect(g, x, y, s - 4, s - 4, 4);
            g.fill();
            g.strokeStyle = "rgba(14,12,22,0.75)";
            g.lineWidth = 1.8;
            g.stroke();
            g.fillStyle = "rgba(255,255,255,0.07)";
            g.fillRect(x + 3, y + 2, s - 10, 3);
          }
        if (r() < 0.35) {
          g.strokeStyle = "rgba(14,12,22,0.5)";
          g.lineWidth = 1.2;
          g.beginPath();
          g.moveTo(r() * TILE, r() * TILE);
          g.lineTo(r() * TILE, r() * TILE);
          g.stroke();
        }
        if (r() < 0.25) {
          g.fillStyle = "rgba(96,140,70,0.45)";
          g.beginPath();
          g.ellipse(r() * TILE, r() * TILE, 7, 4, r(), 0, TAU);
          g.fill();
        }
        break;
      }
      case T.DWALL: {
        g.fillStyle = "#2a2534";
        g.fillRect(0, 0, TILE, TILE);
        g.strokeStyle = "rgba(10,8,16,0.9)";
        g.lineWidth = 2;
        for (let row = 0; row < 4; row++) {
          const y = row * 16;
          for (let c = 0; c < 3; c++) {
            const off = (row % 2) * 11;
            const x = c * 22 + off - 11;
            g.fillStyle = ["#4d465c", "#443d53", "#564e68"][(c + row + v) % 3];
            rrect(g, x + 1, y + 1, 20, 14, 2);
            g.fill();
            g.stroke();
          }
        }
        g.fillStyle = "rgba(255,255,255,0.05)";
        g.fillRect(0, 0, TILE, 4);
        break;
      }
      /* ---------- biome 2: Mossgrave Barracks ---------- */
      case T.MFLOOR:
      case T.MMOSS: {
        const mossy = type === T.MMOSS;
        g.fillStyle = mossy ? "#5f6b3e" : "#6d6a55";
        g.fillRect(0, 0, TILE, TILE);
        // irregular cobbles
        for (let i = 0; i < 11; i++) {
          const x = r() * TILE;
          const y = r() * TILE;
          const w = 9 + r() * 12;
          const h = 7 + r() * 9;
          g.fillStyle = ["#8c8a70", "#7f7d64", "#999680", "#757358"][(i + v) % 4];
          g.beginPath();
          g.ellipse(x, y, w / 2, h / 2, r() * 3, 0, TAU);
          g.fill();
          g.strokeStyle = "rgba(42,36,24,0.7)";
          g.lineWidth = 1.6;
          g.stroke();
        }
        if (mossy || r() < 0.3) {
          for (let i = 0; i < (mossy ? 5 : 2); i++) {
            g.fillStyle = ["#6f8f3a", "#8aa84a", "#5c7a30"][i % 3];
            g.globalAlpha = 0.75;
            g.beginPath();
            g.ellipse(r() * TILE, r() * TILE, 10 + r() * 14, 7 + r() * 9, r() * 3, 0, TAU);
            g.fill();
            g.globalAlpha = 1;
          }
        }
        break;
      }
      case T.MPLANK: {
        g.fillStyle = "#7a5230";
        g.fillRect(0, 0, TILE, TILE);
        const n = 4;
        for (let i = 0; i < n; i++) {
          const y = i * (TILE / n);
          g.fillStyle = ["#9a6a3c", "#8a5c34", "#a37242", "#8f6238"][(i + v) % 4];
          g.fillRect(0, y + 1, TILE, TILE / n - 2);
          g.strokeStyle = "rgba(42,26,14,0.8)";
          g.lineWidth = 1.8;
          g.strokeRect(0, y + 1, TILE, TILE / n - 2);
          // grain
          g.strokeStyle = "rgba(60,36,18,0.45)";
          g.lineWidth = 1;
          g.beginPath();
          g.moveTo(4, y + 6 + r() * 4);
          g.lineTo(TILE - 4, y + 8 + r() * 4);
          g.stroke();
          // plank seam
          const sx = r() * TILE;
          g.strokeStyle = "rgba(42,26,14,0.8)";
          g.lineWidth = 1.6;
          g.beginPath();
          g.moveTo(sx, y + 1);
          g.lineTo(sx, y + TILE / n - 1);
          g.stroke();
        }
        break;
      }
      case T.MWALL: {
        g.fillStyle = "#3a3528";
        g.fillRect(0, 0, TILE, TILE);
        g.strokeStyle = "rgba(20,16,10,0.9)";
        g.lineWidth = 2;
        for (let row = 0; row < 4; row++) {
          const y = row * 16;
          for (let c = 0; c < 3; c++) {
            const x = c * 22 + (row % 2) * 11 - 11;
            g.fillStyle = ["#8c8a70", "#7f7d64", "#999680"][(c + row + v) % 3];
            rrect(g, x + 1, y + 1, 20 + (r() - 0.5) * 4, 14, 4);
            g.fill();
            g.stroke();
          }
        }
        if (r() < 0.5) {
          g.fillStyle = "rgba(111,143,58,0.6)";
          g.beginPath();
          g.ellipse(r() * TILE, TILE - 6, 10, 5, 0, 0, TAU);
          g.fill();
        }
        break;
      }
      /* ---------- biome 3: Sewer Vault ---------- */
      case T.SFLOOR: {
        g.fillStyle = "#4e4760";
        g.fillRect(0, 0, TILE, TILE);
        const n = 2;
        const s = TILE / n;
        for (let i = 0; i < n; i++)
          for (let j = 0; j < n; j++) {
            const x = i * s + 2;
            const y = j * s + 2;
            g.fillStyle = ["#8b84a2", "#7f789a", "#958ead", "#847da0"][(i + j * 2 + v) % 4];
            rrect(g, x, y, s - 4, s - 4, 5);
            g.fill();
            g.strokeStyle = "rgba(30,24,44,0.9)";
            g.lineWidth = 2.2;
            g.stroke();
            g.fillStyle = "rgba(255,255,255,0.08)";
            g.fillRect(x + 3, y + 2, s - 10, 3);
          }
        if (r() < 0.4) {
          g.strokeStyle = "rgba(30,24,44,0.7)";
          g.lineWidth = 1.4;
          g.beginPath();
          g.moveTo(r() * TILE, r() * TILE);
          g.lineTo(r() * TILE, r() * TILE);
          g.stroke();
        }
        if (r() < 0.3) {
          g.fillStyle = "#6a6480";
          g.beginPath();
          g.ellipse(r() * TILE, r() * TILE, 3, 2, 0, 0, TAU);
          g.fill();
        }
        break;
      }
      case T.SLIME: {
        g.fillStyle = "#7ab51a";
        g.fillRect(0, 0, TILE, TILE);
        for (let i = 0; i < 5; i++) {
          g.fillStyle = i % 2 ? "#9ad21f" : "#68a013";
          g.beginPath();
          g.ellipse(r() * TILE, r() * TILE, 10 + r() * 12, 4 + r() * 5, 0, 0, TAU);
          g.fill();
        }
        g.strokeStyle = "rgba(190,240,80,0.6)";
        g.lineWidth = 1.6;
        for (let i = 0; i < 3; i++) {
          const x = r() * TILE;
          const y = r() * TILE;
          g.beginPath();
          g.ellipse(x, y, 6 + r() * 6, 2, 0, 0, Math.PI);
          g.stroke();
        }
        // bubbles
        g.fillStyle = "rgba(230,255,160,0.8)";
        for (let i = 0; i < 3; i++) {
          g.beginPath();
          g.arc(r() * TILE, r() * TILE, 1.5 + r() * 2, 0, TAU);
          g.fill();
        }
        break;
      }
      case T.SWALL: {
        g.fillStyle = "#2a2438";
        g.fillRect(0, 0, TILE, TILE);
        g.strokeStyle = "rgba(14,10,22,0.95)";
        g.lineWidth = 2.2;
        for (let row = 0; row < 3; row++) {
          const y = row * 21;
          for (let c = 0; c < 2; c++) {
            const x = c * 32 + (row % 2) * 16 - 16;
            g.fillStyle = ["#8b84a2", "#766f8e", "#9c95b3"][(c + row + v) % 3];
            rrect(g, x + 1, y + 1, 30, 19, 5);
            g.fill();
            g.stroke();
            g.fillStyle = "rgba(255,255,255,0.08)";
            g.fillRect(x + 4, y + 3, 24, 3);
          }
        }
        break;
      }
      case T.RUNE: {
        // base flagstone, rune lines are drawn as an overlay prop
        g.fillStyle = "#5a5a74";
        g.fillRect(0, 0, TILE, TILE);
        const s = TILE / 2;
        for (let i = 0; i < 2; i++)
          for (let j = 0; j < 2; j++) {
            g.fillStyle = ["#8e94b5", "#848aad", "#979dbf"][(i + j + v) % 3];
            rrect(g, i * s + 2, j * s + 2, s - 4, s - 4, 5);
            g.fill();
            g.strokeStyle = "rgba(30,24,44,0.9)";
            g.lineWidth = 2.2;
            g.stroke();
          }
        break;
      }
      case T.BLOOD: {
        paintTile(g, T.SFLOOR, v);
        g.fillStyle = "rgba(200,30,40,0.85)";
        for (let i = 0; i < 4; i++) {
          g.beginPath();
          g.ellipse(r() * TILE, r() * TILE, 8 + r() * 12, 6 + r() * 8, r() * 3, 0, TAU);
          g.fill();
        }
        g.fillStyle = "rgba(140,10,20,0.6)";
        for (let i = 0; i < 6; i++) {
          g.beginPath();
          g.arc(r() * TILE, r() * TILE, 1.5 + r() * 2.5, 0, TAU);
          g.fill();
        }
        break;
      }
      case T.SEAL: {
        g.fillStyle = "#17102a";
        g.fillRect(0, 0, TILE, TILE);
        g.strokeStyle = "#b46cff";
        g.lineWidth = 3;
        for (let i = 0; i < 4; i++) {
          g.beginPath();
          g.moveTo(10 + i * 15, 2);
          g.lineTo(10 + i * 15, TILE - 2);
          g.stroke();
        }
        g.strokeStyle = "rgba(217,166,255,0.5)";
        g.lineWidth = 1.2;
        g.beginPath();
        g.arc(TILE / 2, TILE / 2, 16, 0, TAU);
        g.stroke();
        break;
      }
      default:
        g.fillStyle = "#06040c";
        g.fillRect(0, 0, TILE, TILE);
    }
  }
}

/* ======================= PROPS ======================= */
export type PropKind =
  | "oak"
  | "pine"
  | "bush"
  | "rock"
  | "log"
  | "house"
  | "tower"
  | "well"
  | "lantern"
  | "sconce"
  | "arch"
  | "stairs"
  | "pillar"
  | "grave"
  | "barrel"
  | "crate"
  | "bones"
  | "stump"
  | "chest"
  | "chestOpen"
  | "fence"
  /* barracks */
  | "table"
  | "bench"
  | "shelf"
  | "cot"
  | "oillamp"
  | "torch"
  | "rug"
  /* sewer */
  | "pipe"
  | "grate"
  | "cauldron"
  | "fountain"
  | "bonepile"
  | "chain"
  | "runecircle"
  | "boulder"
  | "sarcophagus";

const OAK_TINTS = [
  ["#5e8f39", "#79a94a", "#97c35c"],
  ["#c6632a", "#de8234", "#f0a244"],
  ["#a63320", "#c84a28", "#e06c35"],
  ["#8d9a3a", "#aab54a", "#c9cf5f"],
];

function canopy(g: G, cx: number, cy: number, blobs: number[][], tint: string[]) {
  // ink silhouette
  g.fillStyle = INK;
  for (const [x, y, r] of blobs) {
    g.beginPath();
    g.arc(cx + x, cy + y, r + 3, 0, TAU);
    g.fill();
  }
  g.fillStyle = tint[0];
  for (const [x, y, r] of blobs) {
    g.beginPath();
    g.arc(cx + x, cy + y, r, 0, TAU);
    g.fill();
  }
  g.fillStyle = tint[1];
  for (const [x, y, r] of blobs) {
    g.beginPath();
    g.arc(cx + x - r * 0.18, cy + y - r * 0.22, r * 0.72, 0, TAU);
    g.fill();
  }
  g.fillStyle = tint[2];
  for (const [x, y, r] of blobs) {
    g.beginPath();
    g.arc(cx + x - r * 0.32, cy + y - r * 0.4, r * 0.34, 0, TAU);
    g.fill();
  }
}

export function getProp(kind: PropKind, v = 0): Sprite {
  const key = `${kind}_${v}`;
  switch (kind) {
    case "oak":
      return mk(key, 170, 180, 85, 172, (g) => {
        const r = rng(v * 31 + 7);
        const tint = OAK_TINTS[v % 4];
        // trunk
        g.fillStyle = "#5a3a24";
        ink(g, 3);
        poly(g, [
          [72, 172],
          [78, 120],
          [92, 120],
          [100, 172],
          [112, 176],
          [60, 176],
        ]);
        g.fill();
        g.stroke();
        g.strokeStyle = "#3e2817";
        g.lineWidth = 2;
        g.beginPath();
        g.moveTo(84, 168);
        g.lineTo(86, 128);
        g.stroke();
        const blobs: number[][] = [];
        const n = 5 + Math.floor(r() * 3);
        for (let i = 0; i < n; i++) {
          const a = (i / n) * TAU + r() * 0.5;
          blobs.push([Math.cos(a) * (26 + r() * 14), Math.sin(a) * (18 + r() * 10), 30 + r() * 14]);
        }
        blobs.push([0, -6, 40]);
        canopy(g, 85, 78, blobs, tint);
      });
    case "pine":
      return mk(key, 80, 136, 40, 130, (g) => {
        g.fillStyle = "#5a3a24";
        ink(g, 2.6);
        rrect(g, 34, 100, 12, 30, 3);
        g.fill();
        g.stroke();
        const dark = v % 2 ? "#2f5a33" : "#2b4f3a";
        const mid = v % 2 ? "#3f7a42" : "#3a6d4a";
        const light = v % 2 ? "#5e9a55" : "#558a5c";
        for (let i = 3; i >= 0; i--) {
          const y = 36 + i * 24;
          const w = 22 + i * 10;
          g.fillStyle = INK;
          poly(g, [
            [40, y - 36],
            [40 + w + 3, y + 3],
            [40 - w - 3, y + 3],
          ]);
          g.fill();
          g.fillStyle = dark;
          poly(g, [
            [40, y - 32],
            [40 + w, y],
            [40 - w, y],
          ]);
          g.fill();
          g.fillStyle = mid;
          poly(g, [
            [40, y - 32],
            [40 + w * 0.55, y - 4],
            [40 - w * 0.2, y - 2],
          ]);
          g.fill();
          g.fillStyle = light;
          poly(g, [
            [40, y - 30],
            [40 + w * 0.22, y - 14],
            [40 - w * 0.08, y - 12],
          ]);
          g.fill();
        }
      });
    case "bush":
      return mk(key, 64, 46, 32, 42, (g) => {
        const tint = OAK_TINTS[v % 4];
        canopy(
          g,
          32,
          24,
          [
            [-14, 4, 13],
            [0, -4, 15],
            [14, 4, 13],
            [2, 8, 11],
          ],
          tint
        );
      });
    case "rock":
      return mk(key, 80, 60, 40, 54, (g) => {
        const r = rng(v * 17 + 3);
        const pts: number[][] = [];
        const n = 7;
        const rx = 24 + r() * 12;
        const ry = 16 + r() * 8;
        for (let i = 0; i < n; i++) {
          const a = (i / n) * TAU;
          pts.push([40 + Math.cos(a) * rx * (0.82 + r() * 0.3), 34 + Math.sin(a) * ry * (0.82 + r() * 0.3)]);
        }
        g.fillStyle = "#98918a";
        ink(g, 2.8);
        poly(g, pts);
        g.fill();
        g.stroke();
        // facets
        g.fillStyle = "#bcb5aa";
        poly(g, [pts[4], pts[5], pts[6], [40, 30]]);
        g.fill();
        g.fillStyle = "#6f6962";
        poly(g, [pts[1], pts[2], pts[3], [40, 36]]);
        g.fill();
        g.strokeStyle = "rgba(42,26,20,0.5)";
        g.lineWidth = 1.5;
        g.beginPath();
        g.moveTo(40, 30);
        g.lineTo(pts[1][0], pts[1][1]);
        g.stroke();
        if (v % 2 === 0) {
          g.fillStyle = "#6f8f3a";
          g.beginPath();
          g.ellipse(34, 22, 10, 5, -0.3, 0, TAU);
          g.fill();
          g.fillStyle = "#8db04a";
          g.beginPath();
          g.ellipse(32, 20, 5, 2.5, -0.3, 0, TAU);
          g.fill();
        }
      });
    case "log":
      return mk(key, 100, 44, 50, 40, (g) => {
        g.fillStyle = "#8a5a32";
        ink(g, 2.6);
        rrect(g, 14, 10, 80, 26, 10);
        g.fill();
        g.stroke();
        g.strokeStyle = "#5f3d20";
        g.lineWidth = 2;
        for (let i = 0; i < 4; i++) {
          g.beginPath();
          g.moveTo(28 + i * 16, 14);
          g.lineTo(26 + i * 16, 32);
          g.stroke();
        }
        g.fillStyle = "#cfa26a";
        ink(g, 2.4);
        g.beginPath();
        g.ellipse(16, 23, 9, 13, 0, 0, TAU);
        g.fill();
        g.stroke();
        g.strokeStyle = "#a67445";
        g.lineWidth = 1.4;
        for (let i = 1; i < 4; i++) {
          g.beginPath();
          g.ellipse(16, 23, i * 2.4, i * 3.4, 0, 0, TAU);
          g.stroke();
        }
      });
    case "stump":
      return mk(key, 56, 44, 28, 40, (g) => {
        g.fillStyle = "#7a4e2a";
        ink(g, 2.4);
        rrect(g, 12, 16, 32, 22, 4);
        g.fill();
        g.stroke();
        g.fillStyle = "#cfa26a";
        g.beginPath();
        g.ellipse(28, 16, 17, 8, 0, 0, TAU);
        g.fill();
        g.stroke();
        g.strokeStyle = "#a67445";
        g.lineWidth = 1.3;
        for (let i = 1; i < 4; i++) {
          g.beginPath();
          g.ellipse(28, 16, i * 4.4, i * 2, 0, 0, TAU);
          g.stroke();
        }
      });
    case "house": {
      const spec = [
        { w: 128, h: 118, roof: "#c9973f" },
        { w: 166, h: 136, roof: "#c9973f" },
        { w: 236, h: 146, roof: "#c9973f" },
        { w: 126, h: 160, roof: "#c9973f" },
        { w: 150, h: 128, roof: "#b5472c" },
      ][v % 5];
      return mk(key, spec.w + 24, spec.h + 20, (spec.w + 24) / 2, spec.h + 14, (g) => {
        const w = spec.w;
        const h = spec.h;
        const x0 = 12;
        const wallTop = h * 0.5;
        const wallH = h - wallTop;
        // walls
        g.fillStyle = "#e6dcc3";
        ink(g, 3);
        g.fillRect(x0, wallTop, w, wallH);
        g.strokeRect(x0, wallTop, w, wallH);
        // timber frame
        g.strokeStyle = "#6b4a2e";
        g.lineWidth = 3;
        const bays = Math.max(2, Math.round(w / 48));
        for (let i = 0; i <= bays; i++) {
          const x = x0 + (i / bays) * w;
          g.beginPath();
          g.moveTo(x, wallTop);
          g.lineTo(x, h);
          g.stroke();
        }
        g.beginPath();
        g.moveTo(x0, wallTop + wallH * 0.5);
        g.lineTo(x0 + w, wallTop + wallH * 0.5);
        g.stroke();
        // windows
        for (let i = 0; i < bays; i++) {
          if (i === Math.floor(bays / 2)) continue;
          const x = x0 + ((i + 0.5) / bays) * w - 9;
          const y = wallTop + 12;
          g.fillStyle = "#f2b24a";
          g.fillRect(x, y, 18, 18);
          ink(g, 2.2);
          g.strokeRect(x, y, 18, 18);
          g.beginPath();
          g.moveTo(x + 9, y);
          g.lineTo(x + 9, y + 18);
          g.moveTo(x, y + 9);
          g.lineTo(x + 18, y + 9);
          g.stroke();
        }
        // door
        const dx = x0 + w / 2 - 13;
        g.fillStyle = "#5a3a24";
        g.beginPath();
        g.moveTo(dx, h);
        g.lineTo(dx, h - 24);
        g.arc(dx + 13, h - 24, 13, Math.PI, 0);
        g.lineTo(dx + 26, h);
        g.closePath();
        g.fill();
        ink(g, 2.4);
        g.stroke();
        g.fillStyle = "#f2b24a";
        g.beginPath();
        g.arc(dx + 21, h - 18, 2, 0, TAU);
        g.fill();
        // roof
        const over = 12;
        g.fillStyle = spec.roof;
        ink(g, 3);
        poly(g, [
          [x0 - over, wallTop + 6],
          [x0 + w * 0.12, 6],
          [x0 + w * 0.88, 6],
          [x0 + w + over, wallTop + 6],
        ]);
        g.fill();
        g.stroke();
        if (v % 5 === 4) {
          g.strokeStyle = "rgba(60,20,10,0.5)";
          g.lineWidth = 1.6;
          for (let i = 1; i < 6; i++) {
            const t = i / 6;
            g.beginPath();
            g.moveTo(x0 - over + (w * 0.12 + over) * t, wallTop + 6 - (wallTop) * t);
            g.lineTo(x0 + w + over - (w * 0.12 + over) * t, wallTop + 6 - (wallTop) * t);
            g.stroke();
          }
        } else {
          g.strokeStyle = shade(spec.roof, 0.78);
          g.lineWidth = 2.2;
          for (let i = 0; i < Math.round(w / 14); i++) {
            const t = (i + 0.5) / Math.round(w / 14);
            const xa = x0 - over + (w + over * 2) * t;
            const xb = x0 + w * 0.12 + w * 0.76 * t;
            g.beginPath();
            g.moveTo(xa, wallTop + 4);
            g.lineTo(xb, 10);
            g.stroke();
          }
        }
        // ridge + chimney
        g.fillStyle = shade(spec.roof, 0.7);
        rrect(g, x0 + w * 0.12 - 4, 2, w * 0.76 + 8, 8, 4);
        g.fill();
        g.stroke();
        if (v % 5 !== 0) {
          g.fillStyle = "#8f8a84";
          g.fillRect(x0 + w * 0.72, -2 + 6, 14, 26);
          ink(g, 2.4);
          g.strokeRect(x0 + w * 0.72, 4, 14, 26);
        }
        // ground shade
        g.fillStyle = "rgba(0,0,0,0.18)";
        g.fillRect(x0, h - 6, w, 6);
      });
    }
    case "tower":
      return mk(key, 88, 180, 44, 174, (g) => {
        g.fillStyle = "#cfc8ba";
        ink(g, 3);
        rrect(g, 18, 40, 52, 132, 6);
        g.fill();
        g.stroke();
        g.fillStyle = "#a9a294";
        g.fillRect(54, 42, 14, 128);
        g.strokeStyle = "rgba(42,26,20,0.4)";
        g.lineWidth = 1.5;
        for (let i = 0; i < 7; i++) {
          g.beginPath();
          g.moveTo(20, 56 + i * 16);
          g.lineTo(68, 56 + i * 16);
          g.stroke();
        }
        // slit
        g.fillStyle = "#2a2230";
        g.fillRect(40, 96, 6, 18);
        if (v % 2 === 0) {
          // crenellated top
          g.fillStyle = "#e0d9ca";
          ink(g, 2.6);
          rrect(g, 12, 30, 64, 16, 3);
          g.fill();
          g.stroke();
          for (let i = 0; i < 4; i++) {
            g.fillStyle = "#e0d9ca";
            g.fillRect(14 + i * 16, 18, 10, 14);
            g.strokeRect(14 + i * 16, 18, 10, 14);
          }
        } else {
          // conical roof
          g.fillStyle = "#c9973f";
          ink(g, 3);
          poly(g, [
            [8, 46],
            [44, 2],
            [80, 46],
          ]);
          g.fill();
          g.stroke();
          g.strokeStyle = "#a67a2e";
          g.lineWidth = 2;
          for (let i = 1; i < 5; i++) {
            g.beginPath();
            g.moveTo(44, 2);
            g.lineTo(8 + i * 14.4, 46);
            g.stroke();
          }
        }
        g.fillStyle = "rgba(0,0,0,0.2)";
        g.fillRect(18, 166, 52, 6);
      });
    case "well":
      return mk(key, 84, 96, 42, 90, (g) => {
        // posts + roof
        g.fillStyle = "#5a3a24";
        ink(g, 2.4);
        g.fillRect(16, 26, 6, 48);
        g.strokeRect(16, 26, 6, 48);
        g.fillRect(62, 26, 6, 48);
        g.strokeRect(62, 26, 6, 48);
        g.fillStyle = "#c9973f";
        poly(g, [
          [6, 30],
          [42, 4],
          [78, 30],
        ]);
        g.fill();
        g.stroke();
        // ring
        g.fillStyle = "#a9a294";
        g.beginPath();
        g.ellipse(42, 74, 28, 14, 0, 0, TAU);
        g.fill();
        g.stroke();
        g.fillStyle = "#1e2a44";
        g.beginPath();
        g.ellipse(42, 70, 18, 8, 0, 0, TAU);
        g.fill();
        g.stroke();
        g.fillStyle = "#bcb5aa";
        g.fillRect(14, 74, 56, 10);
        g.strokeRect(14, 74, 56, 10);
        g.fillStyle = "#5a3a24";
        g.fillRect(36, 40, 12, 8);
      });
    case "lantern":
      return mk(key, 40, 100, 20, 96, (g) => {
        g.fillStyle = "#3a2a1e";
        ink(g, 2.4);
        rrect(g, 17, 36, 6, 58, 2);
        g.fill();
        g.stroke();
        rrect(g, 10, 88, 20, 8, 2);
        g.fill();
        g.stroke();
        g.fillStyle = "#c8873a";
        rrect(g, 8, 10, 24, 30, 4);
        g.fill();
        g.stroke();
        g.fillStyle = "#ffcf6a";
        rrect(g, 12, 14, 16, 22, 2);
        g.fill();
        g.fillStyle = "#fff4c2";
        g.beginPath();
        g.ellipse(20, 27, 4, 7, 0, 0, TAU);
        g.fill();
        g.fillStyle = "#c8873a";
        poly(g, [
          [6, 10],
          [20, 2],
          [34, 10],
        ]);
        g.fill();
        g.stroke();
      });
    case "sconce":
      return mk(key, 34, 44, 17, 40, (g) => {
        g.fillStyle = "#4a3a30";
        ink(g, 2.2);
        rrect(g, 12, 22, 10, 18, 2);
        g.fill();
        g.stroke();
        g.fillStyle = "#ff9a3a";
        poly(g, [
          [17, 2],
          [26, 16],
          [22, 24],
          [12, 24],
          [8, 16],
        ]);
        g.fill();
        g.fillStyle = "#fff0b0";
        g.beginPath();
        g.ellipse(17, 16, 3.5, 6, 0, 0, TAU);
        g.fill();
      });
    case "arch":
      return mk(key, 140, 150, 70, 142, (g) => {
        // stone block arch (the Hollow Gate / crypt door)
        g.fillStyle = "#8e8a94";
        ink(g, 3);
        poly(g, [
          [10, 142],
          [10, 60],
          [30, 20],
          [70, 6],
          [110, 20],
          [130, 60],
          [130, 142],
        ]);
        g.fill();
        g.stroke();
        g.strokeStyle = "rgba(42,26,20,0.5)";
        g.lineWidth = 1.8;
        for (let i = 0; i < 6; i++) {
          g.beginPath();
          g.moveTo(10, 72 + i * 12);
          g.lineTo(130, 72 + i * 12);
          g.stroke();
        }
        g.fillStyle = "#140b1f";
        g.beginPath();
        g.moveTo(36, 142);
        g.lineTo(36, 66);
        g.arc(70, 66, 34, Math.PI, 0);
        g.lineTo(104, 142);
        g.closePath();
        g.fill();
        ink(g, 3);
        g.stroke();
        // fire
        const fg = g.createRadialGradient(70, 108, 4, 70, 108, 40);
        fg.addColorStop(0, "rgba(255,200,110,0.95)");
        fg.addColorStop(0.5, "rgba(255,120,40,0.55)");
        fg.addColorStop(1, "rgba(255,120,40,0)");
        g.fillStyle = fg;
        g.fillRect(36, 60, 68, 82);
        g.fillStyle = "#ff9a3a";
        poly(g, [
          [70, 86],
          [82, 108],
          [76, 122],
          [64, 122],
          [58, 108],
        ]);
        g.fill();
        g.fillStyle = "#fff0b0";
        g.beginPath();
        g.ellipse(70, 112, 5, 9, 0, 0, TAU);
        g.fill();
        // steps
        g.fillStyle = "#6f6a74";
        g.fillRect(24, 136, 92, 10);
        g.strokeRect(24, 136, 92, 10);
      });
    case "stairs":
      return mk(key, 110, 86, 55, 70, (g) => {
        g.fillStyle = "#0e0a16";
        ink(g, 3);
        rrect(g, 8, 8, 94, 70, 6);
        g.fill();
        g.stroke();
        for (let i = 0; i < 5; i++) {
          g.fillStyle = ["#6a6c7d", "#565868", "#444554", "#34343f", "#24232c"][i];
          g.fillRect(14, 12 + i * 12, 82, 12);
          g.strokeStyle = "rgba(10,8,16,0.8)";
          g.lineWidth = 1.5;
          g.strokeRect(14, 12 + i * 12, 82, 12);
        }
        g.strokeStyle = "#b46cff";
        g.lineWidth = 2;
        g.strokeRect(10, 10, 90, 66);
      });
    case "pillar":
      return mk(key, 52, 112, 26, 106, (g) => {
        g.fillStyle = "#8a8794";
        ink(g, 2.6);
        rrect(g, 16, 18, 20, 80, 3);
        g.fill();
        g.stroke();
        g.fillStyle = "#6a6775";
        g.fillRect(30, 20, 6, 76);
        g.fillStyle = "#a3a0ad";
        rrect(g, 8, 8, 36, 14, 3);
        g.fill();
        g.stroke();
        rrect(g, 8, 94, 36, 12, 3);
        g.fill();
        g.stroke();
        if (v % 2) {
          g.strokeStyle = "rgba(10,8,16,0.7)";
          g.lineWidth = 1.5;
          g.beginPath();
          g.moveTo(20, 40);
          g.lineTo(28, 56);
          g.lineTo(24, 70);
          g.stroke();
        }
      });
    case "grave":
      return mk(key, 44, 56, 22, 52, (g) => {
        g.fillStyle = v % 2 ? "#9a948f" : "#8b8580";
        ink(g, 2.6);
        g.beginPath();
        g.moveTo(8, 52);
        g.lineTo(8, 20);
        g.arc(22, 20, 14, Math.PI, 0);
        g.lineTo(36, 52);
        g.closePath();
        g.fill();
        g.stroke();
        g.strokeStyle = "rgba(42,26,20,0.6)";
        g.lineWidth = 2.4;
        g.beginPath();
        g.moveTo(22, 18);
        g.lineTo(22, 40);
        g.moveTo(14, 26);
        g.lineTo(30, 26);
        g.stroke();
        if (v % 2) {
          g.fillStyle = "#6f8f3a";
          g.beginPath();
          g.ellipse(12, 48, 9, 4, 0, 0, TAU);
          g.fill();
        }
      });
    case "barrel":
      return mk(key, 56, 76, 28, 70, (g) => {
        g.fillStyle = "#a0683a";
        ink(g, 2.6);
        rrect(g, 10, 22, 36, 48, 8);
        g.fill();
        g.stroke();
        g.fillStyle = "#4a3a30";
        g.fillRect(10, 30, 36, 5);
        g.fillRect(10, 56, 36, 5);
        g.strokeStyle = "#6f4524";
        g.lineWidth = 1.6;
        for (let i = 1; i < 4; i++) {
          g.beginPath();
          g.moveTo(10 + i * 9, 24);
          g.lineTo(10 + i * 9, 68);
          g.stroke();
        }
        g.fillStyle = "#c48b55";
        g.beginPath();
        g.ellipse(28, 22, 18, 7, 0, 0, TAU);
        g.fill();
        ink(g, 2.4);
        g.stroke();
        if (v % 2) {
          canopy(
            g,
            28,
            14,
            [
              [-10, 2, 8],
              [0, -4, 9],
              [10, 2, 8],
            ],
            OAK_TINTS[0]
          );
        }
      });
    case "crate":
      return mk(key, 54, 54, 27, 50, (g) => {
        g.fillStyle = "#b0783f";
        ink(g, 2.6);
        rrect(g, 6, 6, 42, 42, 3);
        g.fill();
        g.stroke();
        g.strokeStyle = "#6f4524";
        g.lineWidth = 2;
        g.beginPath();
        g.moveTo(6, 6);
        g.lineTo(48, 48);
        g.moveTo(48, 6);
        g.lineTo(6, 48);
        g.stroke();
        g.strokeStyle = INK;
        g.strokeRect(12, 12, 30, 30);
      });
    case "bones":
      return mk(key, 60, 34, 30, 30, (g) => {
        g.fillStyle = "#e6dcc3";
        ink(g, 2);
        g.beginPath();
        g.arc(20, 16, 9, 0, TAU);
        g.fill();
        g.stroke();
        g.fillStyle = INK;
        g.fillRect(15, 13, 4, 4);
        g.fillRect(22, 13, 4, 4);
        g.strokeStyle = "#e6dcc3";
        g.lineWidth = 4;
        g.beginPath();
        g.moveTo(32, 26);
        g.lineTo(54, 14);
        g.stroke();
        g.strokeStyle = INK;
        g.lineWidth = 1.5;
        g.stroke();
      });
    case "fence":
      return mk(key, 68, 40, 34, 36, (g) => {
        g.fillStyle = "#8a5a32";
        ink(g, 2.2);
        for (const x of [6, 32, 58]) {
          rrect(g, x, 6, 6, 30, 2);
          g.fill();
          g.stroke();
        }
        g.fillRect(2, 14, 64, 5);
        g.strokeRect(2, 14, 64, 5);
        g.fillRect(2, 26, 64, 5);
        g.strokeRect(2, 26, 64, 5);
      });
    case "chest":
    case "chestOpen": {
      const open = kind === "chestOpen";
      return mk(key, 64, 60, 32, 54, (g) => {
        const tier = v % 3; // 0 wood 1 iron 2 gilded
        const wood = ["#b57a3f", "#8a6a4a", "#c58a45"][tier];
        const band = ["#5a4030", "#3a3a40", "#c99a2a"][tier];
        const lid = ["#a86d36", "#7a5c40", "#efe6d2"][tier];
        // body
        g.fillStyle = wood;
        ink(g, 2.6);
        rrect(g, 8, 26, 48, 28, 4);
        g.fill();
        g.stroke();
        g.strokeStyle = shade(wood, 0.72);
        g.lineWidth = 1.5;
        for (let i = 1; i < 4; i++) {
          g.beginPath();
          g.moveTo(8, 26 + i * 7);
          g.lineTo(56, 26 + i * 7);
          g.stroke();
        }
        // lid
        g.fillStyle = lid;
        ink(g, 2.6);
        if (open) {
          rrect(g, 8, 6, 48, 14, 5);
          g.fill();
          g.stroke();
          g.fillStyle = "#1a1020";
          g.fillRect(10, 20, 44, 8);
          const gl = g.createRadialGradient(32, 26, 2, 32, 26, 26);
          gl.addColorStop(0, tier === 2 ? "rgba(255,220,120,0.9)" : "rgba(130,255,210,0.8)");
          gl.addColorStop(1, "rgba(0,0,0,0)");
          g.fillStyle = gl;
          g.fillRect(4, 0, 56, 40);
        } else {
          g.beginPath();
          g.moveTo(8, 28);
          g.lineTo(8, 20);
          g.quadraticCurveTo(8, 8, 20, 8);
          g.lineTo(44, 8);
          g.quadraticCurveTo(56, 8, 56, 20);
          g.lineTo(56, 28);
          g.closePath();
          g.fill();
          g.stroke();
          if (tier === 2) {
            g.strokeStyle = "rgba(42,26,20,0.35)";
            g.lineWidth = 1.4;
            g.beginPath();
            g.moveTo(14, 12);
            g.lineTo(50, 12);
            g.moveTo(10, 20);
            g.lineTo(54, 20);
            g.stroke();
          }
        }
        // bands
        g.fillStyle = band;
        ink(g, 2);
        for (const x of [14, 44]) {
          g.fillRect(x, open ? 6 : 9, 7, open ? 14 : 44);
          g.strokeRect(x, open ? 6 : 9, 7, open ? 14 : 44);
        }
        g.fillRect(8, open ? 26 : 24, 48, 5);
        g.strokeRect(8, open ? 26 : 24, 48, 5);
        // lock
        g.fillStyle = tier === 2 ? "#ffd47a" : "#c9a24a";
        rrect(g, 27, open ? 30 : 22, 10, 12, 2);
        g.fill();
        g.stroke();
        g.fillStyle = INK;
        g.fillRect(31, open ? 35 : 27, 3, 4);
        // rivets
        g.fillStyle = "#e8d9b0";
        for (const [x, y] of [
          [11, 30],
          [53, 30],
          [11, 50],
          [53, 50],
        ])
          g.fillRect(x, y, 2, 2);
      });
    }
    /* ---------- Mossgrave Barracks ---------- */
    case "table":
      return mk(key, 120, 70, 60, 60, (g) => {
        g.fillStyle = "#4a3220";
        ink(g, 2.4);
        for (const x of [14, 100]) {
          g.fillRect(x, 36, 8, 28);
          g.strokeRect(x, 36, 8, 28);
        }
        g.fillStyle = "#a0683a";
        rrect(g, 6, 14, 110, 30, 4);
        g.fill();
        g.stroke();
        g.strokeStyle = "#6f4524";
        g.lineWidth = 1.4;
        for (let i = 1; i < 4; i++) {
          g.beginPath();
          g.moveTo(8, 14 + i * 7.5);
          g.lineTo(114, 14 + i * 7.5);
          g.stroke();
        }
        // tankards / candle / map
        g.fillStyle = "#e6dcc3";
        g.fillRect(44, 20, 30, 18);
        ink(g, 1.6);
        g.strokeRect(44, 20, 30, 18);
        g.fillStyle = "#8f8a84";
        g.beginPath();
        g.arc(24, 28, 5, 0, TAU);
        g.fill();
        g.stroke();
        g.beginPath();
        g.arc(94, 30, 5, 0, TAU);
        g.fill();
        g.stroke();
        g.fillStyle = "#ffcf6a";
        g.fillRect(82, 20, 4, 9);
        g.fillStyle = "#fff4c2";
        g.beginPath();
        g.ellipse(84, 18, 2.5, 4, 0, 0, TAU);
        g.fill();
      });
    case "bench":
      return mk(key, 90, 34, 45, 30, (g) => {
        g.fillStyle = "#4a3220";
        ink(g, 2.2);
        for (const x of [10, 74]) {
          g.fillRect(x, 16, 6, 16);
          g.strokeRect(x, 16, 6, 16);
        }
        g.fillStyle = "#9a6a3c";
        rrect(g, 4, 8, 82, 12, 3);
        g.fill();
        g.stroke();
      });
    case "shelf":
      return mk(key, 72, 92, 36, 86, (g) => {
        g.fillStyle = "#5a3a24";
        ink(g, 2.6);
        rrect(g, 6, 6, 60, 82, 3);
        g.fill();
        g.stroke();
        for (let row = 0; row < 3; row++) {
          const y = 12 + row * 25;
          g.fillStyle = "#2a1a10";
          g.fillRect(10, y, 52, 20);
          const cols = ["#8d1b3d", "#3a5a8a", "#6f8f3a", "#c9973f", "#7a4e8a", "#b5472c"];
          let x = 12;
          let k = row * 2;
          while (x < 58) {
            const w = 5 + ((k * 7) % 5);
            g.fillStyle = cols[k % cols.length];
            g.fillRect(x, y + 3 + (k % 3), w, 17 - (k % 3));
            ink(g, 1);
            g.strokeRect(x, y + 3 + (k % 3), w, 17 - (k % 3));
            x += w + 1;
            k++;
          }
          g.fillStyle = "#7a5230";
          g.fillRect(8, y + 20, 56, 4);
        }
      });
    case "cot":
      return mk(key, 60, 104, 30, 98, (g) => {
        g.fillStyle = "#5a3a24";
        ink(g, 2.4);
        rrect(g, 6, 6, 48, 94, 4);
        g.fill();
        g.stroke();
        g.fillStyle = v % 2 ? "#8d4a3d" : "#6a7a4a";
        rrect(g, 10, 24, 40, 72, 3);
        g.fill();
        g.stroke();
        g.fillStyle = "#e6dcc3";
        rrect(g, 12, 10, 36, 16, 5);
        g.fill();
        g.stroke();
        g.strokeStyle = "rgba(42,26,20,0.4)";
        g.lineWidth = 1.4;
        for (let i = 0; i < 3; i++) {
          g.beginPath();
          g.moveTo(12, 40 + i * 16);
          g.lineTo(48, 44 + i * 16);
          g.stroke();
        }
      });
    case "oillamp":
      return mk(key, 36, 52, 18, 48, (g) => {
        g.fillStyle = "#4a3a30";
        ink(g, 2.2);
        rrect(g, 12, 36, 12, 12, 2);
        g.fill();
        g.stroke();
        g.fillStyle = "#c8873a";
        rrect(g, 8, 10, 20, 26, 5);
        g.fill();
        g.stroke();
        g.fillStyle = "#ffcf6a";
        rrect(g, 12, 14, 12, 18, 3);
        g.fill();
        g.fillStyle = "#fff4c2";
        g.beginPath();
        g.ellipse(18, 24, 3.5, 6, 0, 0, TAU);
        g.fill();
        g.fillStyle = "#4a3a30";
        g.fillRect(16, 2, 4, 8);
      });
    case "torch":
      return mk(key, 30, 56, 15, 50, (g) => {
        g.fillStyle = "#5a3a24";
        ink(g, 2.2);
        rrect(g, 12, 22, 6, 30, 2);
        g.fill();
        g.stroke();
        g.fillStyle = "#4a3a30";
        g.fillRect(10, 20, 10, 6);
        g.fillStyle = "#ff9a3a";
        poly(g, [
          [15, 0],
          [24, 12],
          [21, 22],
          [9, 22],
          [6, 12],
        ]);
        g.fill();
        g.fillStyle = "#fff0b0";
        g.beginPath();
        g.ellipse(15, 14, 3.5, 6, 0, 0, TAU);
        g.fill();
      });
    case "rug":
      return mk(key, 110, 70, 55, 35, (g) => {
        g.fillStyle = v % 2 ? "#8d1b3d" : "#3a5a8a";
        g.globalAlpha = 0.9;
        rrect(g, 4, 4, 102, 62, 3);
        g.fill();
        g.strokeStyle = "#e6dcc3";
        g.lineWidth = 2;
        g.strokeRect(10, 10, 90, 50);
        g.strokeRect(18, 18, 74, 34);
        g.globalAlpha = 1;
        g.fillStyle = "#e6dcc3";
        for (let i = 0; i < 10; i++) {
          g.fillRect(6 + i * 10, 2, 3, 5);
          g.fillRect(6 + i * 10, 63, 3, 5);
        }
      });
    /* ---------- Sewer Vault ---------- */
    case "pipe":
      return mk(key, 64, 90, 32, 84, (g) => {
        g.fillStyle = "#6b6584";
        ink(g, 2.6);
        rrect(g, 18, 0, 28, 44, 6);
        g.fill();
        g.stroke();
        g.fillStyle = "#8b84a2";
        rrect(g, 12, 36, 40, 14, 4);
        g.fill();
        g.stroke();
        // slime stream
        g.fillStyle = "#7ab51a";
        g.beginPath();
        g.moveTo(22, 46);
        g.quadraticCurveTo(28, 70, 20, 84);
        g.lineTo(44, 84);
        g.quadraticCurveTo(36, 70, 42, 46);
        g.closePath();
        g.fill();
        g.fillStyle = "#b8ef3f";
        g.beginPath();
        g.ellipse(32, 62, 4, 10, 0, 0, TAU);
        g.fill();
        g.fillStyle = "#1c1a24";
        g.beginPath();
        g.ellipse(32, 44, 10, 4, 0, 0, TAU);
        g.fill();
      });
    case "grate":
      return mk(key, 56, 56, 28, 36, (g) => {
        g.fillStyle = "#2a2438";
        ink(g, 2.4);
        rrect(g, 4, 4, 48, 48, 4);
        g.fill();
        g.stroke();
        g.strokeStyle = "#6f8f3a";
        g.lineWidth = 3;
        for (let i = 0; i < 5; i++) {
          g.beginPath();
          g.moveTo(10, 10 + i * 9);
          g.lineTo(46, 10 + i * 9);
          g.stroke();
        }
        g.strokeStyle = "#9c95b3";
        g.lineWidth = 2;
        g.strokeRect(8, 8, 40, 40);
      });
    case "cauldron":
      return mk(key, 60, 60, 30, 52, (g) => {
        g.fillStyle = "#2c2836";
        ink(g, 2.6);
        g.beginPath();
        g.ellipse(30, 36, 24, 18, 0, 0, TAU);
        g.fill();
        g.stroke();
        g.fillStyle = "#1a1722";
        g.beginPath();
        g.ellipse(30, 22, 22, 8, 0, 0, TAU);
        g.fill();
        g.stroke();
        g.fillStyle = "#7ab51a";
        g.beginPath();
        g.ellipse(30, 22, 18, 6, 0, 0, TAU);
        g.fill();
        g.fillStyle = "#b8ef3f";
        g.beginPath();
        g.arc(24, 21, 2.5, 0, TAU);
        g.arc(36, 23, 2, 0, TAU);
        g.fill();
        g.fillStyle = "#2c2836";
        for (const x of [12, 44]) {
          g.fillRect(x, 50, 6, 8);
          g.strokeRect(x, 50, 6, 8);
        }
      });
    case "fountain":
      return mk(key, 80, 84, 40, 74, (g) => {
        g.fillStyle = "#8b84a2";
        ink(g, 2.6);
        g.beginPath();
        g.moveTo(10, 78);
        g.lineTo(10, 30);
        g.arc(40, 30, 30, Math.PI, 0);
        g.lineTo(70, 78);
        g.closePath();
        g.fill();
        g.stroke();
        g.fillStyle = "#2a2438";
        g.beginPath();
        g.moveTo(20, 60);
        g.lineTo(20, 32);
        g.arc(40, 32, 20, Math.PI, 0);
        g.lineTo(60, 60);
        g.closePath();
        g.fill();
        g.fillStyle = "#7ab51a";
        g.fillRect(36, 34, 8, 26);
        g.beginPath();
        g.ellipse(40, 66, 24, 8, 0, 0, TAU);
        g.fill();
        g.stroke();
        g.fillStyle = "#b8ef3f";
        g.beginPath();
        g.ellipse(40, 66, 14, 4, 0, 0, TAU);
        g.fill();
        g.fillStyle = "#1c1a24";
        g.beginPath();
        g.ellipse(40, 34, 8, 4, 0, 0, TAU);
        g.fill();
      });
    case "bonepile":
      return mk(key, 76, 48, 38, 42, (g) => {
        g.fillStyle = "#e6dcc3";
        ink(g, 1.8);
        g.beginPath();
        g.ellipse(38, 34, 30, 10, 0, 0, TAU);
        g.fill();
        g.stroke();
        for (const [x, y, rr] of [
          [24, 24, 9],
          [48, 20, 8],
          [38, 30, 6],
        ]) {
          g.fillStyle = "#f1ead9";
          g.beginPath();
          g.arc(x, y, rr, 0, TAU);
          g.fill();
          g.stroke();
          g.fillStyle = INK;
          g.fillRect(x - rr * 0.5, y - rr * 0.25, rr * 0.35, rr * 0.35);
          g.fillRect(x + rr * 0.15, y - rr * 0.25, rr * 0.35, rr * 0.35);
        }
        g.strokeStyle = "#f1ead9";
        g.lineWidth = 4;
        g.beginPath();
        g.moveTo(8, 36);
        g.lineTo(30, 42);
        g.moveTo(50, 40);
        g.lineTo(70, 30);
        g.stroke();
      });
    case "chain":
      return mk(key, 24, 110, 12, 100, (g) => {
        g.strokeStyle = "#8b84a2";
        g.lineWidth = 3;
        for (let i = 0; i < 9; i++) {
          g.beginPath();
          g.ellipse(12, 8 + i * 11, 4, 6, 0, 0, TAU);
          g.stroke();
        }
        g.fillStyle = "#6b6584";
        ink(g, 2);
        g.beginPath();
        g.moveTo(12, 100);
        g.lineTo(2, 108);
        g.lineTo(22, 108);
        g.closePath();
        g.fill();
        g.stroke();
      });
    case "runecircle":
      return mk(key, 260, 260, 130, 130, (g) => {
        g.strokeStyle = "rgba(90,220,255,0.75)";
        g.lineWidth = 3;
        g.beginPath();
        g.arc(130, 130, 118, 0, TAU);
        g.stroke();
        g.lineWidth = 2;
        g.beginPath();
        g.arc(130, 130, 92, 0, TAU);
        g.stroke();
        g.beginPath();
        g.arc(130, 130, 40, 0, TAU);
        g.stroke();
        // 7-point star
        const pts: number[][] = [];
        for (let i = 0; i < 7; i++) {
          const a = (i / 7) * TAU - Math.PI / 2;
          pts.push([130 + Math.cos(a) * 92, 130 + Math.sin(a) * 92]);
        }
        g.beginPath();
        for (let i = 0; i < 7; i++) {
          const p = pts[i];
          const q = pts[(i + 3) % 7];
          g.moveTo(p[0], p[1]);
          g.lineTo(q[0], q[1]);
        }
        g.stroke();
        // runes
        g.font = "bold 12px serif";
        g.fillStyle = "rgba(140,235,255,0.8)";
        g.textAlign = "center";
        const glyphs = "ᚠᚢᚦᚨᚱᚲᚷᚹᚺᚾᛁᛃᛇᛈᛉᛊ";
        for (let i = 0; i < 16; i++) {
          const a = (i / 16) * TAU;
          g.save();
          g.translate(130 + Math.cos(a) * 105, 130 + Math.sin(a) * 105);
          g.rotate(a + Math.PI / 2);
          g.fillText(glyphs[i], 0, 4);
          g.restore();
        }
      });
    case "boulder":
      return mk(key, 70, 60, 35, 52, (g) => {
        g.fillStyle = "#a8a3b8";
        ink(g, 2.8);
        g.beginPath();
        g.arc(35, 30, 26, 0, TAU);
        g.fill();
        g.stroke();
        g.fillStyle = "#c5c0d4";
        g.beginPath();
        g.arc(28, 22, 12, 0, TAU);
        g.fill();
        g.fillStyle = "#847da0";
        g.beginPath();
        g.ellipse(42, 40, 14, 8, 0.4, 0, TAU);
        g.fill();
        g.strokeStyle = "rgba(30,24,44,0.6)";
        g.lineWidth = 1.5;
        g.beginPath();
        g.moveTo(20, 36);
        g.lineTo(34, 30);
        g.lineTo(44, 36);
        g.stroke();
      });
    case "sarcophagus":
      return mk(key, 60, 120, 30, 110, (g) => {
        g.fillStyle = "#8b84a2";
        ink(g, 2.6);
        rrect(g, 6, 6, 48, 108, 6);
        g.fill();
        g.stroke();
        g.fillStyle = "#2a2438";
        rrect(g, 12, 12, 36, 96, 4);
        g.fill();
        g.stroke();
        // skeleton
        g.fillStyle = "#f1ead9";
        g.beginPath();
        g.arc(30, 30, 9, 0, TAU);
        g.fill();
        g.fillStyle = INK;
        g.fillRect(25, 28, 3, 3);
        g.fillRect(32, 28, 3, 3);
        g.strokeStyle = "#f1ead9";
        g.lineWidth = 3;
        g.beginPath();
        g.moveTo(30, 40);
        g.lineTo(30, 86);
        for (let i = 0; i < 4; i++) {
          g.moveTo(18, 48 + i * 9);
          g.lineTo(42, 48 + i * 9);
        }
        g.moveTo(30, 86);
        g.lineTo(22, 104);
        g.moveTo(30, 86);
        g.lineTo(38, 104);
        g.stroke();
      });
    default:
      return mk(key, 8, 8, 4, 4, () => {});
  }
}

/** collision radius & footprint height for props */
export function propBody(kind: PropKind, v = 0): { r: number; solid: boolean; yOff: number } {
  switch (kind) {
    case "oak":
      return { r: 20, solid: true, yOff: -6 };
    case "pine":
      return { r: 11, solid: true, yOff: -4 };
    case "bush":
      return { r: 16, solid: false, yOff: 0 };
    case "rock":
      return { r: 22, solid: true, yOff: -10 };
    case "log":
      return { r: 26, solid: true, yOff: -10 };
    case "stump":
      return { r: 14, solid: true, yOff: -8 };
    case "house":
      return { r: [52, 68, 98, 50, 62][v % 5], solid: true, yOff: -22 };
    case "tower":
      return { r: 26, solid: true, yOff: -8 };
    case "well":
      return { r: 26, solid: true, yOff: -8 };
    case "lantern":
      return { r: 7, solid: true, yOff: -2 };
    case "arch":
      return { r: 44, solid: false, yOff: -20 };
    case "stairs":
      return { r: 30, solid: false, yOff: -20 };
    case "pillar":
      return { r: 12, solid: true, yOff: -4 };
    case "grave":
      return { r: 12, solid: true, yOff: -4 };
    case "barrel":
      return { r: 16, solid: true, yOff: -6 };
    case "crate":
      return { r: 18, solid: true, yOff: -6 };
    case "fence":
      return { r: 24, solid: true, yOff: -4 };
    case "chest":
    case "chestOpen":
      return { r: 20, solid: false, yOff: -8 };
    case "table":
      return { r: 44, solid: true, yOff: -10 };
    case "bench":
      return { r: 30, solid: true, yOff: -4 };
    case "shelf":
      return { r: 26, solid: true, yOff: -6 };
    case "cot":
      return { r: 24, solid: true, yOff: -20 };
    case "oillamp":
      return { r: 8, solid: true, yOff: -2 };
    case "torch":
      return { r: 0, solid: false, yOff: 0 };
    case "rug":
      return { r: 0, solid: false, yOff: 0 };
    case "pipe":
      return { r: 14, solid: true, yOff: -2 };
    case "grate":
      return { r: 0, solid: false, yOff: 0 };
    case "cauldron":
      return { r: 22, solid: true, yOff: -8 };
    case "fountain":
      return { r: 30, solid: true, yOff: -12 };
    case "bonepile":
      return { r: 0, solid: false, yOff: 0 };
    case "chain":
      return { r: 0, solid: false, yOff: 0 };
    case "runecircle":
      return { r: 0, solid: false, yOff: 0 };
    case "boulder":
      return { r: 24, solid: true, yOff: -10 };
    case "sarcophagus":
      return { r: 24, solid: true, yOff: -24 };
    default:
      return { r: 0, solid: false, yOff: 0 };
  }
}
