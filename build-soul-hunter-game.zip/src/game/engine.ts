import { audio } from "./audio";
import { diffOf } from "./difficulty";
import { rollUpgrades } from "./upgrades";
import { drawReaper, drawReaperGhost } from "./reaper";
import { T, TILE, getProp, getTile } from "./art";
import { ACCESSORIES, SCYTHES, accessoryOf, loadVault, saveVault, scytheOf, type Loadout, type Vault } from "./gear";
import { SKILLS, SLAM_WINDUP, drawSkillFx, makeCracks, type SkillFx } from "./skills";
import {
  BIOME_INFO,
  isWallTile,
  makeDungeon,
  makeOverworld,
  minimapOf,
  resolveCircle,
  roomAt,
  roomPoint,
  sealRoom,
  tileAt,
  walkableAt,
  zoneAt,
  type Chest,
  type GameMap,
  type Portal,
  type Room,
  type Zone,
} from "./world";
import type {
  Bolt,
  Enemy,
  EnemyKind,
  FloatText,
  GamePhase,
  HudSnapshot,
  Particle,
  Player,
  RunResult,
  SlashArc,
  Soul,
  SoulKind,
  TimelinePoint,
  UpgradeCard,
} from "./types";

/* ================= helpers ================= */
const TAU = Math.PI * 2;
const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const rand = (a: number, b: number) => a + Math.random() * (b - a);
const angDelta = (a: number, b: number) => {
  let d = (a - b) % TAU;
  if (d > Math.PI) d -= TAU;
  if (d < -Math.PI) d += TAU;
  return d;
};

export function rankFor(score: number, depth: number): string {
  const v = score + depth * 2600;
  if (v >= 90000) return "SS";
  if (v >= 56000) return "S";
  if (v >= 34000) return "A";
  if (v >= 19000) return "B";
  if (v >= 9500) return "C";
  if (v >= 3800) return "D";
  return "E";
}

interface Ring {
  x: number;
  y: number;
  r: number;
  maxR: number;
  speed: number;
  dmg: number;
  color: string;
  life: number;
  maxLife: number;
  width: number;
  hits: Set<number>;
}
interface Ghost {
  x: number;
  y: number;
  a: number;
  life: number;
  max: number;
}
export interface Toast {
  title: string;
  sub: string;
  kind: "wave" | "boss" | "frenzy" | "milestone" | "zone";
}
export interface EngineHooks {
  onHud: (h: HudSnapshot) => void;
  onLevelUp: (choices: UpgradeCard[]) => void;
  onOver: (r: RunResult) => void;
  onPhase: (p: GamePhase) => void;
  onToast: (t: Toast) => void;
  onVault: (v: Vault) => void;
}

interface Bleed {
  id: number;
  dps: number;
  t: number;
}

/* ================= engine ================= */
export class SoulHunter {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private hooks: EngineHooks;
  private raf = 0;
  private last = 0;
  private dpr = 1;
  W = 800;
  H = 600;

  mode: "attract" | "play" = "attract";
  frozen = false;
  autoAttack = false;
  holdSlash = false;
  wantMusic = false;
  dead = false;
  difficulty = 1;
  showRadar = true;
  reduceFx = false;

  /* persistent vault: banked souls + gear */
  vault: Vault = loadVault();
  private bleeds: Bleed[] = [];
  private bankedThisRun = 0;
  private slimeT = 0;
  private skillCd: number[] = [0, 0, 0];
  private skillFx: SkillFx[] = [];
  shopOpen = false;

  /* world */
  private map: GameMap;
  private overworld: GameMap;
  private depth = 0; // 0 = surface
  private maxDepth = 0;
  private seed = (Math.random() * 1e9) | 0;
  private zone: Zone | null = null;
  private room: Room | null = null;
  private roomsCleared = 0;
  private chestsOpened = 0;
  private prompt = "";
  private fade = 0; // 1 = black
  private fadeDir = 0;
  private pendingPortal: Portal | null = null;
  private returnPos = { x: 0, y: 0 };

  private cam = { x: 0, y: 0, shake: 0, shakeT: 0, punch: 0 };
  private flash = 0;
  private hurtFx = 0;
  private hitStop = 0;
  private slowMo = 0;
  private timeScale = 1;

  private player!: Player;
  private enemies: Enemy[] = [];
  private bolts: Bolt[] = [];
  private souls: Soul[] = [];
  private parts: Particle[] = [];
  private texts: FloatText[] = [];
  private arcs: SlashArc[] = [];
  private rings: Ring[] = [];
  private ghosts: Ghost[] = [];
  private pending: { t: number; angle: number }[] = [];
  private embers: { x: number; y: number; v: number; s: number; a: number }[] = [];

  private idc = 1;
  private t = 0;
  private spawnT = 0;
  private pickupT = 9;
  private kills = 0;
  private killStats: Record<string, number> = {};
  private timeline: TimelinePoint[] = [];
  private tlAcc = 0;
  private grazes = 0;
  private bossId = 0;
  private hudAcc = 0;
  private milestone = 0;
  private pendingLevels = 0;
  private offered: UpgradeCard[] = [];

  /* input */
  private keys = new Set<string>();
  private axis = { x: 0, y: 0 };
  private mouse = { x: 0, y: 0, active: false, idle: 9, down: false };
  private slashQueued = false;
  private dashQueued = false;

  /* cached */
  private glows = new Map<string, HTMLCanvasElement>();
  private lightCv: HTMLCanvasElement | null = null;
  private vignette: HTMLCanvasElement | null = null;

  constructor(canvas: HTMLCanvasElement, hooks: EngineHooks) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d", { alpha: false })!;
    this.hooks = hooks;
    this.overworld = makeOverworld(7);
    this.map = this.overworld;
    this.resetPlayer();
    this.player.x = this.map.spawn.x;
    this.player.y = this.map.spawn.y;
    this.cam.x = this.player.x;
    this.cam.y = this.player.y;
    this.resize();
    window.addEventListener("resize", this.resize);
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    canvas.addEventListener("pointermove", this.onPointerMove);
    canvas.addEventListener("pointerdown", this.onPointerDown);
    window.addEventListener("pointerup", this.onPointerUp);
    window.addEventListener("blur", this.onBlur);
    canvas.addEventListener("contextmenu", this.onCtx);
    this.last = performance.now();
    this.raf = requestAnimationFrame(this.tick);
  }

  destroy() {
    cancelAnimationFrame(this.raf);
    window.removeEventListener("resize", this.resize);
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    this.canvas.removeEventListener("pointermove", this.onPointerMove);
    this.canvas.removeEventListener("pointerdown", this.onPointerDown);
    window.removeEventListener("pointerup", this.onPointerUp);
    window.removeEventListener("blur", this.onBlur);
    this.canvas.removeEventListener("contextmenu", this.onCtx);
    audio.stopMusic();
  }

  /* ---------- lifecycle ---------- */
  private resetPlayer() {
    this.player = {
      x: 0,
      y: 0,
      vx: 0,
      vy: 0,
      r: 19,
      aim: -Math.PI / 2,
      hp: 4,
      maxHp: 4,
      invuln: 0,
      shields: 0,
      level: 1,
      xp: 0,
      xpNeed: 86,
      score: 0,
      combo: 0,
      comboT: 0,
      bestCombo: 0,
      harvest: 0,
      dmg: 46,
      dmgMult: 1,
      arc: 1.02,
      reach: 152,
      slashCd: 0.33,
      slashT: 0,
      slashWindow: 0.14,
      slashing: 0,
      echo: 0,
      shock: 0,
      execute: 0,
      crit: 0.05,
      critMult: 2.4,
      thorns: 0,
      lifesteal: 0,
      soulGain: 0,
      xpMult: 1,
      greed: 1,
      speed: 268,
      speedMult: 1,
      dashCharges: 2,
      maxDash: 2,
      dashCd: 0,
      dashCdMax: 0.95,
      dashT: 0,
      dashDur: 0.17,
      dashVec: { x: 1, y: 0 },
      dashTrail: false,
      grazes: 0,
      magnet: 132,
      luck: 1,
      orbit: 0,
      orbitDmg: 0,
      orbitAngle: 0,
      aura: 0,
      slowField: 0,
      frenzy: 0,
      frenzyOn: false,
      frenzyT: 0,
      frenzyMax: 7.5,
      frenzyMult: 1,
      rageT: 0,
      stacked: {},
    };
  }

  private clearWorldEntities() {
    this.enemies = [];
    this.bolts = [];
    this.souls = [];
    this.parts = [];
    this.texts = [];
    this.arcs = [];
    this.rings = [];
    this.ghosts = [];
    this.pending = [];
    this.bossId = 0;
    this.skillFx = [];
    this.room = null;
  }

  startRun = () => {
    this.resetPlayer();
    this.seed = (Math.random() * 1e9) | 0;
    this.overworld = makeOverworld(7);
    this.map = this.overworld;
    this.depth = 0;
    this.maxDepth = 0;
    this.roomsCleared = 0;
    this.chestsOpened = 0;
    this.clearWorldEntities();
    this.t = 0;
    this.spawnT = 2.5;
    this.pickupT = 11;
    this.kills = 0;
    this.grazes = 0;
    this.killStats = {};
    this.timeline = [{ t: 0, score: 0, combo: 0 }];
    this.tlAcc = 0;
    this.milestone = 0;
    this.pendingLevels = 0;
    this.offered = [];
    this.timeScale = 1;
    this.slowMo = 0;
    this.hitStop = 0;
    this.hurtFx = 0;
    this.cam.shake = 0;
    this.flash = 0.35;
    this.fade = 1;
    this.fadeDir = -1;
    this.pendingPortal = null;
    this.mode = "play";
    this.dead = false;
    this.frozen = false;
    this.mouse.down = false;
    this.holdSlash = false;
    this.axis.x = this.axis.y = 0;
    this.derive();

    const df = diffOf(this.difficulty);
    const pl = this.player;
    pl.maxHp += df.hearts;
    pl.hp = pl.maxHp;
    pl.magnet = Math.round(pl.magnet * df.magnet);
    pl.greed = df.score;
    this.bleeds = [];
    this.bankedThisRun = 0;
    this.shopOpen = false;
    this.applyGearAtStart();
    this.skillCd = [0, 0, 0];
    this.skillFx = [];
    pl.x = this.map.spawn.x;
    pl.y = this.map.spawn.y;
    this.cam.x = pl.x;
    this.cam.y = pl.y;
    this.zone = zoneAt(this.map, pl.x, pl.y);

    // a few souls to chase in the first seconds
    for (let i = 0; i < 5; i++) {
      const a = (i / 5) * TAU;
      this.addSoul(pl.x + Math.cos(a) * 110, pl.y + Math.sin(a) * 90, "pure", 8, 26);
    }
    this.hooks.onToast({ title: "ASHVALE", sub: "find the Hollow Gate in the northern ruins", kind: "zone" });
    this.hud();
    this.hooks.onPhase("playing");
    audio.unlock();
    if (this.wantMusic) audio.startMusic();
    audio.setIntensity(0);
  };

  pause() {
    if (this.mode !== "play" || this.frozen) return;
    this.frozen = true;
    audio.stopMusic();
    this.hooks.onPhase("paused");
  }
  resume() {
    if (this.mode !== "play" || !this.frozen) return;
    this.frozen = false;
    this.last = performance.now();
    if (this.wantMusic) audio.startMusic();
    this.hooks.onPhase("playing");
  }
  togglePause() {
    if (this.frozen && this.mode === "play") this.resume();
    else this.pause();
  }
  toAttract() {
    this.mode = "attract";
    this.dead = false;
    this.frozen = false;
    this.map = this.overworld;
    this.clearWorldEntities();
    this.player.x = this.map.spawn.x;
    this.player.y = this.map.spawn.y;
    audio.stopMusic();
    this.hooks.onPhase("attract");
  }

  openLevelUp() {
    this.pendingLevels++;
    if (this.mode !== "play") {
      this.pendingLevels = 0;
      return;
    }
    this.hud();
    if (this.frozen) return;
    const opts = rollUpgrades(this.player, this.pendingLevels > 1 ? 4 : 3);
    if (opts.length === 0) {
      this.pendingLevels = 0;
      const pl = this.player;
      pl.dmgMult *= 1.14;
      pl.reach *= 1.05;
      pl.score += 2500;
      pl.hp = Math.min(pl.maxHp, pl.hp + 1);
      this.derive();
      audio.pick();
      this.hooks.onToast({ title: "ASCENDED FORM", sub: "+14% power · +1 heart · +2500 souls", kind: "milestone" });
      this.hud();
      return;
    }
    this.frozen = true;
    this.offered = opts;
    audio.stopMusic();
    this.hooks.onLevelUp(this.offered);
    this.hooks.onPhase("levelup");
  }

  applyUpgrade = (id: string) => {
    const p = this.player;
    const card = this.offered.find((c) => c.id === id);
    if (card) {
      card.apply(p);
      p.stacked[card.id] = (p.stacked[card.id] ?? 0) + 1;
      this.derive();
      this.burst(p.x, p.y, "#ffc94a", 34, 3.4, 0.6);
      this.ringFx(p.x, p.y, 230, "#ffdd8a", 0.42, 7);
      this.text(p.x, p.y - 46, card.name.toUpperCase(), "#ffdd8a", 19, true);
      audio.pick();
    }
    this.pendingLevels = Math.max(0, this.pendingLevels - 1);
    if (this.pendingLevels > 0) {
      const more = rollUpgrades(p, 3);
      if (more.length > 0) {
        this.offered = more;
        this.hooks.onLevelUp(this.offered);
        return;
      }
      this.pendingLevels = 0;
      p.dmgMult *= 1.14;
      p.score += 2500;
      this.derive();
    }
    this.frozen = false;
    this.last = performance.now();
    if (this.wantMusic) audio.startMusic();
    this.hud();
    this.hooks.onPhase("playing");
  };

  setAutoAttack(v: boolean) {
    this.autoAttack = v;
  }
  setAxis(x: number, y: number) {
    this.axis.x = x;
    this.axis.y = y;
    if (x || y) this.mouse.active = false;
  }
  requestSlash() {
    this.slashQueued = true;
  }
  requestDash() {
    this.dashQueued = true;
  }
  private derive() {
    const p = this.player;
    const g = this.gearMods();
    p.speed = 268 * p.speedMult * g.speed;
    p.frenzyMax = 7.5 * p.frenzyMult;
  }

  /* ---------- gear ---------- */
  private gearMods() {
    const lo = this.vault.loadout;
    const acc = [accessoryOf(lo.wings), accessoryOf(lo.charm), accessoryOf(lo.trinket)];
    const m = { speed: 1, dash: 0, dashCd: 1, magnet: 0, luck: 0, maxHp: 0, shields: 0, frenzy: 1, greed: 1, xp: 1 };
    for (const a of acc) {
      if (!a) continue;
      const s = a.stats;
      m.speed *= s.speed ?? 1;
      m.dash += s.dash ?? 0;
      m.dashCd *= s.dashCd ?? 1;
      m.magnet += s.magnet ?? 0;
      m.luck += s.luck ?? 0;
      m.maxHp += s.maxHp ?? 0;
      m.shields += s.shields ?? 0;
      m.frenzy *= s.frenzy ?? 1;
      m.greed *= s.greed ?? 1;
      m.xp *= s.xp ?? 1;
    }
    return m;
  }

  /** scythe multipliers layered on top of boons (never mutates base stats) */
  private weapon() {
    return scytheOf(this.vault.loadout.scythe);
  }

  /** apply accessory bonuses to a fresh player at run start */
  private applyGearAtStart() {
    const p = this.player;
    const g = this.gearMods();
    p.maxHp += g.maxHp;
    p.hp = p.maxHp;
    p.shields = Math.min(3, p.shields + g.shields);
    p.maxDash += g.dash;
    p.dashCharges = p.maxDash;
    p.dashCdMax *= g.dashCd;
    p.magnet += g.magnet;
    p.luck += g.luck;
    p.greed *= g.greed;
    p.xpMult *= g.xp;
    p.frenzyMult *= g.frenzy;
    this.derive();
  }

  private shopReturn: GamePhase = "attract";

  openShop() {
    if (this.shopOpen) return;
    if (this.mode === "play" && this.frozen && this.pendingLevels > 0) return; // not over the boon board
    this.shopOpen = true;
    if (this.mode === "play") {
      this.shopReturn = this.frozen ? "paused" : "playing";
      this.frozen = true;
      audio.stopMusic();
    } else this.shopReturn = this.dead ? "over" : "attract";
    audio.ui();
    // bank what you've reaped so far so it can be spent right now
    if (this.mode === "play") this.bankSouls();
    this.hooks.onVault(this.vault);
    this.hooks.onPhase("shop");
  }
  closeShop() {
    if (!this.shopOpen) return;
    this.shopOpen = false;
    audio.ui();
    if (this.mode === "play" && this.shopReturn === "playing") {
      this.frozen = false;
      this.last = performance.now();
      if (this.wantMusic) audio.startMusic();
    }
    this.hooks.onPhase(this.shopReturn);
  }
  toggleShop() {
    if (this.shopOpen) this.closeShop();
    else this.openShop();
  }

  /** souls earned this hunt that haven't been moved into the vault yet */
  get unbanked() {
    return this.mode === "play" ? Math.max(0, this.player.score - this.bankedThisRun) : 0;
  }

  /** bank live score into the vault (called on death & when entering the shop mid-run) */
  bankSouls() {
    const p = this.player;
    const unbanked = p.score - this.bankedThisRun;
    if (unbanked > 0) {
      this.vault.souls += unbanked;
      this.bankedThisRun = p.score;
      saveVault(this.vault);
      this.hooks.onVault(this.vault);
    }
  }

  buy(id: string): boolean {
    const item = SCYTHES.find((s) => s.id === id) ?? ACCESSORIES.find((a) => a.id === id);
    if (!item || this.vault.owned.includes(id)) return false;
    // allow spending unbanked run souls too
    this.bankSouls();
    if (this.vault.souls < item.price) {
      audio.shieldBreak();
      return false;
    }
    this.vault.souls -= item.price;
    this.vault.owned.push(id);
    saveVault(this.vault);
    audio.record();
    this.hooks.onVault(this.vault);
    this.equip(id);
    return true;
  }

  equip(id: string | null, slot?: keyof Loadout) {
    const lo = this.vault.loadout;
    if (id === null && slot) {
      if (slot !== "scythe") lo[slot] = null;
    } else if (id) {
      if (!this.vault.owned.includes(id)) return;
      const sc = SCYTHES.find((s) => s.id === id);
      if (sc) lo.scythe = sc.id;
      const ac = ACCESSORIES.find((a) => a.id === id);
      if (ac) lo[ac.slot] = lo[ac.slot] === ac.id && slot === undefined ? null : ac.id;
    }
    saveVault(this.vault);
    audio.pick();
    this.hooks.onVault({ ...this.vault, loadout: { ...lo } });
    // live re-derive so speed etc. respond mid-run
    this.derive();
    const p = this.player;
    this.burst(p.x, p.y - 10, "#ffdd8a", 16, 2.2, 0.5);
  }

  /* ---------- events ---------- */
  private onCtx = (e: Event) => e.preventDefault();
  private onBlur = () => {
    this.keys.clear();
    this.mouse.down = false;
    if (this.mode === "play" && !this.frozen) this.pause();
  };
  private onKeyDown = (e: KeyboardEvent) => {
    const k = e.key.toLowerCase();
    if (["arrowup", "arrowdown", "arrowleft", "arrowright", " ", "shift"].includes(k)) e.preventDefault();
    if (this.keys.has(k)) return;
    this.keys.add(k);
    if (k === "escape" && this.shopOpen) {
      this.closeShop();
      return;
    }
    if (k === "b" || k === "tab") {
      e.preventDefault();
      this.toggleShop();
      return;
    }
    if (k === "escape" || k === "p") {
      if (this.mode === "play") this.togglePause();
      return;
    }
    if (this.mode !== "play" || this.frozen) return;
    if (k === " " || k === "j") this.slashQueued = true;
    if (k === "q") this.castSkill(0);
    if (k === "f") this.castSkill(1);
    if (k === "c") this.castSkill(2);
    if (k === "shift" || k === "k" || k === "e") this.dashQueued = true;
  };
  private onKeyUp = (e: KeyboardEvent) => this.keys.delete(e.key.toLowerCase());
  private onPointerMove = (e: PointerEvent) => {
    const r = this.canvas.getBoundingClientRect();
    this.mouse.x = e.clientX - r.left;
    this.mouse.y = e.clientY - r.top;
    this.mouse.idle = 0;
    if (e.pointerType === "mouse") this.mouse.active = true;
  };
  private onPointerDown = (e: PointerEvent) => {
    const r = this.canvas.getBoundingClientRect();
    this.mouse.x = e.clientX - r.left;
    this.mouse.y = e.clientY - r.top;
    this.mouse.active = e.pointerType === "mouse";
    this.mouse.idle = 0;
    if (e.pointerType === "mouse") {
      this.mouse.down = true;
      if (this.mode === "play" && !this.frozen) {
        if (e.button === 2) this.dashQueued = true;
        else this.slashQueued = true;
      }
    } else if (e.pointerType === "touch") {
      if (this.mouse.x > this.W * 0.55 && this.mode === "play" && !this.frozen) this.slashQueued = true;
    }
    audio.unlock();
  };
  private onPointerUp = () => {
    this.mouse.down = false;
  };
  private resize = () => {
    const rect = this.canvas.getBoundingClientRect();
    this.dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.W = Math.max(320, rect.width);
    this.H = Math.max(320, rect.height);
    this.canvas.width = Math.floor(this.W * this.dpr);
    this.canvas.height = Math.floor(this.H * this.dpr);
    this.ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    this.lightCv = null;
    this.vignette = null;
    this.embers = [];
    for (let i = 0; i < 60; i++)
      this.embers.push({ x: Math.random() * this.W, y: Math.random() * this.H, v: 6 + Math.random() * 22, s: 0.7 + Math.random() * 1.9, a: 0.12 + Math.random() * 0.4 });
  };

  /* ---------- cached glow sprite ---------- */
  private glow(color: string) {
    let c = this.glows.get(color);
    if (!c) {
      c = document.createElement("canvas");
      c.width = c.height = 64;
      const g = c.getContext("2d")!;
      const grd = g.createRadialGradient(32, 32, 0, 32, 32, 32);
      grd.addColorStop(0, color);
      grd.addColorStop(0.28, color);
      grd.addColorStop(1, "rgba(0,0,0,0)");
      g.fillStyle = grd;
      g.fillRect(0, 0, 64, 64);
      this.glows.set(color, c);
    }
    return c;
  }
  private addGlow(x: number, y: number, r: number, color: string, a = 1) {
    const ctx = this.ctx;
    ctx.globalAlpha = a;
    ctx.drawImage(this.glow(color), x - r, y - r, r * 2, r * 2);
    ctx.globalAlpha = 1;
  }

  /* ================= fx ================= */
  private burst(x: number, y: number, color: string, n: number, spd = 3, life = 0.5, add = true) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * TAU;
      const s = rand(spd * 0.3, spd) * 100;
      this.parts.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, r: rand(1.4, 3.6), life, maxLife: life, color, kind: 0, drag: 2.6, add });
    }
    if (this.parts.length > 1200) this.parts.splice(0, this.parts.length - 1200);
  }
  private ringFx(x: number, y: number, maxR: number, color: string, life = 0.4, width = 5) {
    this.rings.push({ x, y, r: 6, maxR, speed: 0, dmg: 0, color, life, maxLife: life, width, hits: new Set() });
  }
  private smoke(x: number, y: number, color: string, n = 6) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * TAU;
      this.parts.push({ x: x + Math.cos(a) * rand(0, 14), y: y + Math.sin(a) * rand(0, 14), vx: Math.cos(a) * rand(6, 40), vy: Math.sin(a) * rand(6, 40) - 20, r: rand(7, 20), life: rand(0.5, 1.1), maxLife: 1.1, color, kind: 3, drag: 1.1, add: false });
    }
  }
  private text(x: number, y: number, t: string, color: string, size = 15, bold = false) {
    this.texts.push({ x, y, vy: -52, life: 0.9, maxLife: 0.9, text: t, color, size, bold });
    if (this.texts.length > 60) this.texts.shift();
  }
  private kick(amount: number, dur = 0.3) {
    const a = this.reduceFx ? amount * 0.18 : amount;
    this.cam.shake = Math.max(this.cam.shake, a);
    this.cam.shakeT = Math.max(this.cam.shakeT, this.reduceFx ? dur * 0.4 : dur);
  }

  /* ================= spawning ================= */
  private tierScale() {
    return this.map.kind === "dungeon" ? 1 + this.depth * 0.24 : 1 + this.maxDepth * 0.1;
  }

  private makeEnemy(kind: EnemyKind, x: number, y: number): Enemy {
    const scale = this.tierScale();
    const d = this.depth;
    let e: Enemy = {
      id: this.idc++,
      kind,
      x,
      y,
      vx: 0,
      vy: 0,
      r: 20,
      hp: 52 * scale,
      maxHp: 52 * scale,
      speed: 92 + d * 3,
      dmg: 1,
      score: 30,
      xp: 9,
      hue: "#ff5b4d",
      face: 0,
      hit: 0,
      born: 0.42,
      state: 0,
      telegraph: 0,
      fireT: rand(1, 2.4),
      spin: Math.random() * TAU,
      slow: 0,
      contactCd: 0,
      grazed: false,
    };
    switch (kind) {
      case "wisp":
        e = { ...e, r: 13, hp: 24 * scale, maxHp: 24 * scale, speed: 168 + d * 3, score: 24, xp: 8, hue: "#3fe6b8" };
        break;
      case "stalker":
        e = { ...e, r: 30, hp: 150 * scale, maxHp: 150 * scale, speed: 62 + d, score: 90, xp: 22, hue: "#b46cff" };
        break;
      case "revenant":
        e = { ...e, r: 19, hp: 84 * scale, maxHp: 84 * scale, speed: 74, score: 110, xp: 24, hue: "#ffc94a" };
        break;
      case "charger":
        e = { ...e, r: 21, hp: 96 * scale, maxHp: 96 * scale, speed: 78, score: 120, xp: 26, hue: "#ff9a4d" };
        break;
      case "warden":
        e = { ...e, r: 62, hp: 1500 + d * 420, maxHp: 1500 + d * 420, speed: 58, score: 1800, xp: 190, hue: "#e2382f", born: 1.1 };
        break;
    }
    const df = diffOf(this.difficulty);
    e.hp = Math.round(e.hp * df.hp);
    e.maxHp = e.hp;
    e.speed *= df.spd;
    return e;
  }

  private spawnAt(kind: EnemyKind, x: number, y: number) {
    const e = this.makeEnemy(kind, x, y);
    this.enemies.push(e);
    if (kind !== "warden") this.ringFx(e.x, e.y, e.r * 2.6, e.hue, 0.4, 3);
    return e;
  }

  /** overworld ambient spawn: on walkable wild ground, just off-screen */
  private spawnAmbient() {
    const p = this.player;
    for (let i = 0; i < 12; i++) {
      const a = Math.random() * TAU;
      const d = rand(Math.min(this.W, this.H) * 0.5 + 80, 760);
      const x = p.x + Math.cos(a) * d;
      const y = p.y + Math.sin(a) * d;
      const t = tileAt(this.map, Math.floor(x / TILE), Math.floor(y / TILE));
      if (t !== T.GRASS && t !== T.AUTUMN && t !== T.DIRT && t !== T.RUIN) continue;
      const z = zoneAt(this.map, x, y);
      if (z?.safe) continue;
      if (this.map.props.some((q) => q.solid && Math.hypot(q.x - x, q.y - y) < q.r + 26)) continue;
      const roll = Math.random();
      const ruins = z?.name.startsWith("RUINS");
      let kind: EnemyKind = roll < 0.55 ? "phantom" : "wisp";
      if (ruins && roll > 0.8) kind = "revenant";
      if (this.maxDepth >= 2 && roll > 0.9) kind = "stalker";
      this.spawnAt(kind, x, y);
      return;
    }
  }

  private pickKind(roll: number): EnemyKind {
    const d = this.depth;
    const b = this.map.biome;
    if (b === "barracks") {
      // the dead garrison: armoured, aggressive
      if (roll > 0.86) return "charger";
      if (roll > 0.62) return "stalker";
      if (roll > 0.5) return "revenant";
      if (roll > 0.3) return "wisp";
      return "phantom";
    }
    if (b === "sewer") {
      // sludge-born: ranged pressure & swarms, wisps skate over slime
      if (roll > 0.9 && d >= 2) return "charger";
      if (roll > 0.7) return "revenant";
      if (roll > 0.34) return "wisp";
      if (roll > 0.22) return "stalker";
      return "phantom";
    }
    if (d >= 2 && roll > 0.93) return "charger";
    if (d >= 2 && roll > 0.84) return "revenant";
    if (d >= 1 && roll > 0.72) return "stalker";
    if (roll > 0.42) return "wisp";
    return "phantom";
  }

  private activateRoom(rm: Room) {
    rm.active = true;
    sealRoom(this.map, rm, true);
    const p = this.player;
    const df = diffOf(this.difficulty);
    if (rm.kind === "boss") {
      const c = roomPoint(this.map, rm, p.x, p.y, 260);
      const w = this.spawnAt("warden", c.x, c.y);
      this.bossId = w.id;
      for (let i = 0; i < 3; i++) {
        const q = roomPoint(this.map, rm, p.x, p.y, 200);
        this.spawnAt("wisp", q.x, q.y);
      }
      this.hooks.onToast({ title: "THE WARDEN", sub: "guardian of the hollow vault", kind: "boss" });
      audio.bossRoar();
      this.kick(26, 0.7);
      this.flash = 0.5;
    } else {
      const n = Math.round((4 + this.depth * 2 + Math.floor((rm.w * rm.h) / 40)) * (0.75 + df.spawn * 0.25));
      for (let i = 0; i < Math.min(n, 22); i++) {
        const q = roomPoint(this.map, rm, p.x, p.y, 190);
        this.spawnAt(this.pickKind(Math.random()), q.x, q.y);
      }
      this.hooks.onToast({ title: "THE CRYPT STIRS", sub: `chamber ${rm.id} · doors sealed`, kind: "wave" });
      audio.wave(this.depth);
      this.ringFx(p.x, p.y, 380, "#b46cff", 0.6, 5);
    }
    this.kick(8, 0.3);
  }

  private clearRoom(rm: Room) {
    rm.active = false;
    rm.cleared = true;
    sealRoom(this.map, rm, false);
    this.roomsCleared++;
    const p = this.player;
    const bonus = Math.floor((400 + this.depth * 220) * p.greed);
    p.score += bonus;
    audio.levelUp();
    this.hooks.onToast({ title: "CHAMBER CLEANSED", sub: `+${bonus.toLocaleString()} souls · the way is open`, kind: "milestone" });
    this.ringFx(p.x, p.y, 460, "#3fe6b8", 0.7, 6);
    for (let i = 0; i < 6; i++) {
      const q = roomPoint(this.map, rm, p.x, p.y, 60);
      this.addSoul(q.x, q.y, Math.random() < 0.35 ? "gold" : "pure", 12, 44);
    }
    if (Math.random() < 0.45) {
      const q = roomPoint(this.map, rm, p.x, p.y, 80);
      const kinds: SoulKind[] = ["nova", "rage", "shield", "life"];
      this.addSoul(q.x, q.y, kinds[Math.floor(Math.random() * (p.hp < p.maxHp ? 4 : 3))], 0, 60);
    }
    if (rm.kind === "boss") {
      for (const pt of this.map.portals) if (pt.kind === "stairs") pt.locked = false;
    }
  }

  private addSoul(x: number, y: number, kind: SoulKind, xp: number, score: number) {
    this.souls.push({ x, y, vx: rand(-70, 70), vy: rand(-70, 70), r: kind === "gold" ? 10 : kind === "pure" ? 7 : 11, kind, xp, score, t: Math.random() * TAU, pulled: false, life: kind === "pure" ? 24 : 40 });
    if (this.souls.length > 190) this.souls.shift();
  }

  private dropSouls(e: Enemy) {
    const p = this.player;
    const count = 1 + (p.soulGain > 0 && Math.random() < 0.5 + p.soulGain * 0.3 ? 1 : 0) + (e.kind === "stalker" ? 1 : 0) + (e.kind === "warden" ? 10 : 0);
    for (let i = 0; i < count; i++) {
      const lucky = Math.random() < 0.07 * p.luck + (e.kind === "warden" ? 0.5 : 0);
      const a = Math.random() * TAU;
      const d = rand(0, e.r * 0.7);
      this.addSoul(e.x + Math.cos(a) * d, e.y + Math.sin(a) * d, lucky ? "gold" : "pure", lucky ? e.xp * 3 : e.xp, lucky ? e.score * 2.2 : e.score * 0.55);
    }
    if (p.hp < p.maxHp && Math.random() < 0.09) this.addSoul(e.x, e.y, "life", 0, 40);
  }

  /* ================= portals / chests ================= */
  private usePortal(pt: Portal) {
    if (pt.locked) {
      this.prompt = "THE WAY IS SEALED — SLAY THE WARDEN";
      return;
    }
    if (this.fadeDir !== 0 || this.pendingPortal) return;
    this.pendingPortal = pt;
    this.fadeDir = 1;
    audio.pick();
    this.kick(4, 0.2);
  }

  private travel(pt: Portal) {
    const p = this.player;
    this.clearWorldEntities();
    this.pending = [];
    if (pt.kind === "crypt") {
      this.returnPos = { x: p.x, y: p.y + 70 };
      this.depth = Math.max(1, this.depth);
      this.map = makeDungeon(this.depth, this.seed);
      this.maxDepth = Math.max(this.maxDepth, this.depth);
    } else if (pt.kind === "stairs") {
      this.depth++;
      this.maxDepth = Math.max(this.maxDepth, this.depth);
      this.map = makeDungeon(this.depth, this.seed);
      p.score += Math.floor(600 * this.depth * p.greed);
    } else {
      this.map = this.overworld;
      // leaving the crypt heals a heart — the village is a sanctuary
      p.hp = Math.min(p.maxHp, p.hp + 1);
    }
    const sp = pt.kind === "exit" ? this.returnPos : this.map.spawn;
    p.x = sp.x;
    p.y = sp.y;
    p.vx = p.vy = 0;
    this.cam.x = p.x;
    this.cam.y = p.y;
    this.zone = zoneAt(this.map, p.x, p.y);
    this.room = null;
    this.spawnT = 3;
    this.pickupT = 10;
    if (this.zone) this.hooks.onToast({ title: this.zone.name, sub: this.zone.sub, kind: "zone" });
    audio.setIntensity(this.map.kind === "dungeon" ? clamp(0.3 + this.depth * 0.08, 0, 1) : 0);
    this.flash = 0.3;
    this.hud();
  }

  private openChest(c: Chest) {
    const p = this.player;
    c.opened = true;
    this.chestsOpened++;
    audio.pick();
    this.kick(6, 0.25);
    const gold = c.tier === 2;
    this.burst(c.x, c.y - 20, gold ? "#ffdd8a" : c.tier === 1 ? "#c7fff0" : "#ffc08a", gold ? 40 : 22, 3, 0.7);
    this.ringFx(c.x, c.y - 10, gold ? 300 : 180, gold ? "#ffc94a" : "#8ef6da", 0.5, 6);
    const n = c.tier === 0 ? 6 : c.tier === 1 ? 10 : 14;
    for (let i = 0; i < n; i++) {
      const a = (i / n) * TAU;
      const kind: SoulKind = gold ? (i % 2 ? "gold" : "pure") : c.tier === 1 && i % 4 === 0 ? "gold" : "pure";
      this.addSoul(c.x + Math.cos(a) * rand(30, 90), c.y - 10 + Math.sin(a) * rand(30, 90), kind, 10 + c.tier * 6, 40 + c.tier * 30);
    }
    const bonus = Math.floor([150, 450, 1200][c.tier] * p.greed);
    p.score += bonus;
    this.text(c.x, c.y - 60, `+${bonus} SOULS`, "#ffdd8a", 18, true);
    if (c.tier >= 1 && p.hp < p.maxHp) {
      p.hp++;
      this.text(c.x, c.y - 84, "+1 HEART", "#8ef6da", 15, true);
    }
    if (c.tier === 1 && Math.random() < 0.5) this.addSoul(c.x, c.y - 30, Math.random() < 0.5 ? "shield" : "rage", 0, 60);
    if (gold) {
      this.hooks.onToast({ title: "GILDED CACHE", sub: "a forbidden boon awakens", kind: "milestone" });
      this.openLevelUp();
    }
  }

  /* ================= main loop ================= */
  private tick = (now: number) => {
    this.raf = requestAnimationFrame(this.tick);
    let dt = (now - this.last) / 1000;
    this.last = now;
    if (dt > 0.05) dt = 0.05;
    let scale = this.timeScale;
    if (this.hitStop > 0) {
      this.hitStop -= dt;
      scale *= 0.08;
    } else if (this.slowMo > 0) {
      this.slowMo -= dt;
      scale *= 0.34;
    } else this.timeScale = lerp(this.timeScale, 1, 0.12);

    // fade transitions
    if (this.fadeDir !== 0) {
      this.fade = clamp(this.fade + this.fadeDir * dt * 2.6, 0, 1);
      if (this.fadeDir > 0 && this.fade >= 1) {
        if (this.pendingPortal) this.travel(this.pendingPortal);
        this.pendingPortal = null;
        this.fadeDir = -1;
      } else if (this.fadeDir < 0 && this.fade <= 0) this.fadeDir = 0;
    }

    if (!this.frozen && this.fadeDir <= 0) this.update(dt * scale, dt);
    this.render(dt);
  };

  /* ---------- update ---------- */
  private update(dt: number, rawDt: number) {
    const p = this.player;
    const m = this.map;
    this.mouse.idle += rawDt;
    if (this.mouse.idle > 1.6) this.mouse.active = false;
    this.flash = Math.max(0, this.flash - rawDt * 2.2);
    this.hurtFx = Math.max(0, this.hurtFx - rawDt * 1.5);
    if (this.cam.shakeT > 0) {
      this.cam.shakeT -= rawDt;
      this.cam.shake *= 0.9;
    } else this.cam.shake = 0;
    for (const em of this.embers) {
      em.y -= em.v * rawDt;
      if (em.y < -10) {
        em.y = this.H + 10;
        em.x = Math.random() * this.W;
      }
    }

    if (this.mode === "attract") {
      this.updateAttract(dt);
      return;
    }

    this.t += dt;
    this.prompt = "";

    // ---- zone / room tracking ----
    const z = zoneAt(m, p.x, p.y);
    if (z && z !== this.zone) {
      this.zone = z;
      this.hooks.onToast({ title: z.name, sub: z.sub, kind: "zone" });
    }
    if (m.kind === "dungeon") {
      const rm = roomAt(m, p.x, p.y);
      if (rm && rm !== this.room) {
        // only commit once the reaper is a full stride inside — never seal someone in a doorway
        const inset = 46;
        const inside =
          p.x > rm.x * TILE + inset && p.x < (rm.x + rm.w) * TILE - inset && p.y > rm.y * TILE + inset && p.y < (rm.y + rm.h) * TILE - inset;
        if (inside || rm.cleared) {
          this.room = rm;
          if (!rm.cleared && !rm.active && (rm.kind === "combat" || rm.kind === "boss")) this.activateRoom(rm);
        }
      } else if (!rm && this.room && !this.room.active) this.room = null;
      if (this.room?.active && this.enemies.length === 0) this.clearRoom(this.room);
    } else {
      // ambient hunt outside the walls
      const cap = Math.min(16, 7 + this.maxDepth * 2);
      this.spawnT -= dt;
      if (this.spawnT <= 0 && this.enemies.length < cap && !this.zone?.safe) {
        this.spawnT = Math.max(0.9, 2.6 - this.maxDepth * 0.2) / diffOf(this.difficulty).spawn;
        this.spawnAmbient();
        if (Math.random() < 0.4) this.spawnAmbient();
      }
      // despawn far ambient enemies
      for (let i = this.enemies.length - 1; i >= 0; i--) {
        const e = this.enemies[i];
        if (Math.hypot(e.x - p.x, e.y - p.y) > 1500) this.enemies.splice(i, 1);
      }
      this.pickupT -= dt;
      if (this.pickupT <= 0) {
        this.pickupT = rand(14, 20);
        for (let i = 0; i < 10; i++) {
          const a = Math.random() * TAU;
          const d = rand(300, 700);
          const x = p.x + Math.cos(a) * d;
          const y = p.y + Math.sin(a) * d;
          if (!walkableAt(m, x, y)) continue;
          const kinds: SoulKind[] = ["nova", "rage", "shield", "life"];
          const k = kinds[Math.floor(Math.random() * (p.hp < p.maxHp ? 4 : 3))];
          this.addSoul(x, y, k, 0, 60);
          this.ringFx(x, y, 150, "#ffc94a", 0.7, 4);
          break;
        }
      }
    }

    // ---- movement input ----
    let ax = this.axis.x;
    let ay = this.axis.y;
    if (!ax && !ay) {
      if (this.keys.has("a") || this.keys.has("arrowleft")) ax -= 1;
      if (this.keys.has("d") || this.keys.has("arrowright")) ax += 1;
      if (this.keys.has("w") || this.keys.has("arrowup")) ay -= 1;
      if (this.keys.has("s") || this.keys.has("arrowdown")) ay += 1;
      const l = Math.hypot(ax, ay);
      if (l > 0) {
        ax /= l;
        ay /= l;
      }
    }
    const dashing = p.dashT > 0;
    const spd = p.speed * (p.frenzyOn ? 1.16 : 1) * (p.rageT > 0 ? 1.08 : 1);
    if (dashing) {
      p.vx = p.dashVec.x * 1180;
      p.vy = p.dashVec.y * 1180;
      p.dashT -= dt;
      if (Math.random() < 0.85) this.ghosts.push({ x: p.x, y: p.y, a: p.aim, life: 0.26, max: 0.26 });
      if (this.vault.loadout.wings === "duskwings" && Math.random() < 0.7) {
        // shed feathers
        this.parts.push({ x: p.x + rand(-14, 14), y: p.y + rand(-20, 6), vx: -p.dashVec.x * rand(40, 140) + rand(-40, 40), vy: rand(-30, 30), r: rand(2.5, 4.5), life: 0.9, maxLife: 0.9, color: Math.random() < 0.5 ? "#8d1b3d" : "#2b1a33", kind: 3, drag: 1.2, add: false });
      }
      if (p.dashTrail && Math.random() < 0.9) {
        this.parts.push({ x: p.x + rand(-8, 8), y: p.y + rand(-8, 8), vx: rand(-30, 30), vy: rand(-50, -10), r: rand(3, 8), life: 0.5, maxLife: 0.5, color: "#ff6a1f", kind: 1, drag: 1.4, add: true });
        for (const e of this.enemies) if (Math.hypot(e.x - p.x, e.y - p.y) < 64) this.damage(e, 34 * dt * 12 * p.dmgMult, false, true);
      }
      if (p.dashT <= 0) {
        p.dashT = 0;
        if (p.grazes > 0) {
          const bonus = p.grazes * 240;
          p.score += Math.floor(bonus * p.greed);
          p.frenzy = clamp(p.frenzy + p.grazes * 9, 0, 100);
          this.text(p.x, p.y - 42, `PERFECT DODGE ×${p.grazes}  +${bonus}`, "#ffdd8a", 19, true);
          audio.graze();
          this.timeScale = 0.34;
          this.slowMo = 0.22;
          this.ringFx(p.x, p.y, 260, "#ffc94a", 0.45, 6);
        }
        p.grazes = 0;
      }
    } else {
      p.vx = lerp(p.vx, ax * spd, 0.24);
      p.vy = lerp(p.vy, ay * spd, 0.24);
    }
    // slime: thick, caustic. Slows you and eats a heart every ~1.6s unless you're dashing
    const onSlime = tileAt(m, Math.floor(p.x / TILE), Math.floor(p.y / TILE)) === T.SLIME;
    if (onSlime && !dashing) {
      p.vx *= 0.955;
      p.vy *= 0.955;
      this.slimeT += dt;
      if (Math.random() < 0.3)
        this.parts.push({ x: p.x + rand(-14, 14), y: p.y + rand(0, 10), vx: rand(-10, 10), vy: rand(-40, -10), r: rand(2, 4), life: 0.6, maxLife: 0.6, color: "#b8ef3f", kind: 1, drag: 1, add: true });
      if (this.slimeT > 1.6) {
        this.slimeT = 0.4;
        this.hurt(1);
        this.text(p.x, p.y - 40, "CAUSTIC", "#b8ef3f", 15, true);
      } else if (this.slimeT < 0.05) this.text(p.x, p.y - 40, "SLIME — GET OUT", "#b8ef3f", 13, true);
    } else this.slimeT = Math.max(0, this.slimeT - dt * 2);
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    const res = resolveCircle(m, p.x, p.y, p.r * 0.8);
    if (res.hit && dashing) {
      // stop the dash on a wall with a little puff
      this.burst(p.x, p.y, "#cdc0a4", 6, 1.5, 0.3, false);
    }
    p.x = res.x;
    p.y = res.y;

    // ---- aiming ----
    let nearest: Enemy | null = null;
    let nd = 1e9;
    for (const e of this.enemies) {
      const d = Math.hypot(e.x - p.x, e.y - p.y);
      if (d < nd) {
        nd = d;
        nearest = e;
      }
    }
    if (this.mouse.active) {
      const mwx = this.mouse.x - this.W / 2 + this.cam.x;
      const mwy = this.mouse.y - this.H / 2 + this.cam.y;
      p.aim = Math.atan2(mwy - p.y, mwx - p.x);
    } else if (nearest && nd < 520) p.aim = Math.atan2(nearest.y - p.y, nearest.x - p.x);
    else if (ax || ay) p.aim = Math.atan2(ay, ax);

    // ---- slash ----
    p.slashT -= dt;
    if (p.slashT < 0) p.slashT = 0;
    const wantAuto = this.autoAttack && nearest !== null && nd < p.reach + 70;
    const holding = this.keys.has(" ") || this.keys.has("j") || this.mouse.down || this.holdSlash;
    if (p.slashT <= 0 && (this.slashQueued || holding || wantAuto)) this.doSlash();
    this.slashQueued = false;
    if (p.slashing > 0) p.slashing -= dt;
    for (const q of this.pending) {
      q.t -= dt;
      if (q.t <= 0) this.fireArc(q.angle, true);
    }
    this.pending = this.pending.filter((q) => q.t > 0);

    // ---- dash ----
    if (p.dashCd > 0) p.dashCd -= dt;
    if (p.dashCd <= 0 && p.dashCharges < p.maxDash) {
      p.dashCharges++;
      p.dashCd = p.dashCdMax;
    }
    if (this.dashQueued) {
      if (p.dashCharges > 0 && !dashing) {
        let dx = ax;
        let dy = ay;
        if (!dx && !dy) {
          dx = Math.cos(p.aim);
          dy = Math.sin(p.aim);
        }
        const l = Math.hypot(dx, dy) || 1;
        p.dashVec = { x: dx / l, y: dy / l };
        p.dashT = p.dashDur;
        p.dashCharges--;
        if (p.dashCd <= 0) p.dashCd = p.dashCdMax;
        p.invuln = Math.max(p.invuln, p.dashDur + 0.05);
        p.grazes = 0;
        for (const e of this.enemies) e.grazed = false;
        audio.dash();
        this.kick(7, 0.2);
        this.burst(p.x, p.y, "#8ef6da", 12, 2.4, 0.4);
      }
      this.dashQueued = false;
    }
    if (p.invuln > 0) p.invuln -= dt;
    if (p.rageT > 0) p.rageT -= dt;

    // ---- combo / frenzy ----
    if (p.comboT > 0) {
      p.comboT -= dt;
      if (p.comboT <= 0) {
        if (p.combo >= 12) this.text(p.x, p.y - 34, "COMBO FADED", "#93876e", 13);
        p.combo = 0;
      }
    }
    if (p.frenzyOn) {
      p.frenzyT -= dt;
      audio.setIntensity(1);
      if (p.frenzyT <= 0) {
        p.frenzyOn = false;
        p.frenzy = 0;
        audio.frenzyEnd();
        audio.setIntensity(this.map.kind === "dungeon" ? clamp(0.3 + this.depth * 0.08, 0, 1) : 0);
        this.text(p.x, p.y - 40, "FRENZY FADES", "#b46cff", 18, true);
      } else if (Math.random() < 0.5)
        this.parts.push({ x: p.x + rand(-24, 24), y: p.y + rand(-24, 24), vx: rand(-20, 20), vy: rand(-60, -20), r: rand(2, 5), life: 0.5, maxLife: 0.5, color: "#ffc94a", kind: 1, drag: 1.2, add: true });
    }

    // ---- orbit blades / aura ----
    if (p.orbit > 0) {
      p.orbitAngle += dt * (2.6 + (p.frenzyOn ? 1.6 : 0));
      for (let i = 0; i < p.orbit; i++) {
        const a = p.orbitAngle + (i / p.orbit) * TAU;
        const bx = p.x + Math.cos(a) * 82;
        const by = p.y + Math.sin(a) * 82;
        for (const e of this.enemies) {
          if (e.contactCd > 0) continue;
          if (Math.hypot(e.x - bx, e.y - by) < e.r + 16) {
            e.contactCd = 0.28;
            this.damage(e, (16 + p.orbitDmg) * p.dmgMult * (p.frenzyOn ? 1.8 : 1), false, true);
          }
        }
      }
    }
    if (p.aura > 0) {
      for (const e of this.enemies) {
        if (Math.hypot(e.x - p.x, e.y - p.y) < p.aura) {
          e.slow = Math.max(e.slow, 0.16);
          if (Math.random() < 0.06) {
            this.damage(e, (5 + p.dmg * 0.05) * p.dmgMult, false, true);
            this.parts.push({ x: e.x + rand(-e.r, e.r), y: e.y + rand(-e.r, e.r), vx: (p.x - e.x) * 0.4, vy: (p.y - e.y) * 0.4 - 20, r: rand(2, 5), life: 0.5, maxLife: 0.5, color: "#8b3ee8", kind: 1, drag: 1.6, add: true });
          }
        }
      }
    }

    // ---- interactables ----
    for (const c of m.chests) {
      if (c.opened) continue;
      const d = Math.hypot(c.x - p.x, c.y - 10 - p.y);
      if (d < 46) this.openChest(c);
      else if (d < 110) this.prompt = c.tier === 2 ? "A GILDED CACHE — WALK INTO IT" : "A CHEST — WALK INTO IT";
    }
    for (const pt of m.portals) {
      const d = Math.hypot(pt.x - p.x, pt.y - p.y);
      if (d < 44) this.usePortal(pt);
      else if (d < 160) this.prompt = pt.locked ? "SEALED — SLAY THE WARDEN" : pt.label;
    }

    this.updateSkills(dt);

    // ---- weapon bleed ticks (Ashthorn) ----
    if (this.bleeds.length) {
      for (let i = this.bleeds.length - 1; i >= 0; i--) {
        const b = this.bleeds[i];
        const e = this.enemies.find((x) => x.id === b.id);
        b.t -= dt;
        if (!e || b.t <= 0) {
          this.bleeds.splice(i, 1);
          continue;
        }
        e.hp -= b.dps * dt;
        if (Math.random() < 0.25)
          this.parts.push({ x: e.x + rand(-e.r, e.r) * 0.6, y: e.y + rand(-e.r, e.r) * 0.6, vx: rand(-20, 20), vy: rand(10, 60), r: rand(1.5, 3.5), life: 0.5, maxLife: 0.5, color: "#e2382f", kind: 0, drag: 1.5, add: true });
      }
    }

    this.updateEnemies(dt);
    this.updateBolts(dt);
    this.updateRings(dt);
    this.updateSouls(dt);
    this.updateParticles(dt, rawDt);

    // ---- camera (clamped to the map) ----
    const tx = p.x + p.vx * 0.12;
    const ty = p.y + p.vy * 0.12;
    this.cam.x = lerp(this.cam.x, tx, 0.12);
    this.cam.y = lerp(this.cam.y, ty, 0.12);
    const mw = m.w * TILE;
    const mh = m.h * TILE;
    this.cam.x = clamp(this.cam.x, Math.min(this.W / 2, mw / 2), Math.max(mw - this.W / 2, mw / 2));
    this.cam.y = clamp(this.cam.y, Math.min(this.H / 2, mh / 2), Math.max(mh - this.H / 2, mh / 2));

    this.tlAcc += dt;
    if (this.tlAcc >= 0.5) {
      this.tlAcc = 0;
      this.timeline.push({ t: Math.round(this.t * 10) / 10, score: p.score, combo: p.combo });
      if (this.timeline.length > 480) this.timeline.shift();
    }
    this.hudAcc += rawDt;
    if (this.hudAcc > 0.07) {
      this.hudAcc = 0;
      this.hud();
    }
  }

  private updateEnemies(dt: number) {
    const p = this.player;
    const m = this.map;
    const dashing = p.dashT > 0;
    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const e = this.enemies[i];
      if (e.born > 0) {
        e.born -= dt;
        continue;
      }
      if (e.hit > 0) e.hit -= 1;
      if (e.contactCd > 0) e.contactCd -= dt;
      if (e.slow > 0) e.slow -= dt;
      if (e.stun && e.stun > 0) e.stun -= dt;
      const dist = Math.hypot(p.x - e.x, p.y - e.y);
      const inSlime = tileAt(m, Math.floor(e.x / TILE), Math.floor(e.y / TILE)) === T.SLIME;
      const slowFactor = (e.slow > 0 ? 0.55 : p.slowField > 0 && dist < p.slowField ? 0.68 : 1) * (inSlime && e.kind !== "wisp" ? 0.6 : 1) * (e.stun && e.stun > 0 ? 0 : 1);
      const toP = Math.atan2(p.y - e.y, p.x - e.x);
      e.face = lerp(e.face, toP, 0.12);
      e.spin += dt * (e.kind === "warden" ? 0.7 : 2.2);
      // overworld idle: wander until the hunter is close
      const awake = m.kind === "dungeon" || dist < 900;

      switch (e.kind) {
        case "wisp": {
          const a = awake ? toP + Math.sin(this.t * 7 + e.id) * 0.55 : this.t * 0.6 + e.id;
          e.vx = lerp(e.vx, Math.cos(a) * e.speed * slowFactor * (awake ? 1 : 0.4), 0.1);
          e.vy = lerp(e.vy, Math.sin(a) * e.speed * slowFactor * (awake ? 1 : 0.4), 0.1);
          break;
        }
        case "stalker":
          e.vx = lerp(e.vx, Math.cos(toP) * e.speed * slowFactor * (awake ? 1 : 0), 0.05);
          e.vy = lerp(e.vy, Math.sin(toP) * e.speed * slowFactor * (awake ? 1 : 0), 0.05);
          break;
        case "revenant": {
          const dir = dist > 300 ? 1 : -0.8;
          const strafe = Math.sin(this.t * 0.8 + e.id) * 0.7;
          e.vx = lerp(e.vx, (Math.cos(toP) * dir + Math.cos(toP + Math.PI / 2) * strafe) * e.speed * slowFactor * (awake ? 1 : 0), 0.06);
          e.vy = lerp(e.vy, (Math.sin(toP) * dir + Math.sin(toP + Math.PI / 2) * strafe) * e.speed * slowFactor * (awake ? 1 : 0), 0.06);
          if (awake) {
            e.fireT -= dt;
            e.telegraph = e.fireT < 0.45 ? 1 - e.fireT / 0.45 : 0;
            if (e.fireT <= 0) {
              e.fireT = rand(2.1, 3.1);
              for (let s = -1; s <= 1; s++) {
                const a = toP + s * 0.22;
                this.bolts.push({ x: e.x, y: e.y, vx: Math.cos(a) * 300, vy: Math.sin(a) * 300, r: 7, dmg: 1, life: 3.4, color: "#ffc94a", hostile: true, pierce: 0 });
              }
              audio.bolt();
            }
          }
          break;
        }
        case "charger": {
          if (e.state === 0) {
            e.vx = lerp(e.vx, Math.cos(toP) * e.speed * 0.5 * slowFactor, 0.06);
            e.vy = lerp(e.vy, Math.sin(toP) * e.speed * 0.5 * slowFactor, 0.06);
            if (dist < 420) {
              e.state = 1;
              e.telegraph = 0.72;
            }
          } else if (e.state === 1) {
            e.telegraph -= dt;
            e.vx *= 0.82;
            e.vy *= 0.82;
            e.face = toP;
            if (e.telegraph <= 0) {
              e.state = 2;
              e.fireT = 0.5;
              e.vx = Math.cos(toP) * 660;
              e.vy = Math.sin(toP) * 660;
              audio.bolt();
              this.ringFx(e.x, e.y, 90, "#ff9a4d", 0.3, 3);
            }
          } else {
            e.fireT -= dt;
            e.vx *= 0.985;
            e.vy *= 0.985;
            if (Math.random() < 0.6) this.parts.push({ x: e.x, y: e.y, vx: rand(-20, 20), vy: rand(-20, 20), r: rand(2, 6), life: 0.3, maxLife: 0.3, color: "#ff9a4d", kind: 1, drag: 2, add: true });
            if (e.fireT <= 0) e.state = 0;
          }
          break;
        }
        case "warden": {
          e.telegraph -= dt;
          if (e.state === 0) {
            e.vx = lerp(e.vx, Math.cos(toP) * e.speed, 0.03);
            e.vy = lerp(e.vy, Math.sin(toP) * e.speed, 0.03);
            if (e.telegraph <= 0) {
              e.state = 1 + Math.floor(Math.random() * 3);
              e.telegraph = e.state === 1 ? 0.8 : e.state === 2 ? 1.4 : 1.0;
              e.fireT = e.state === 1 ? 0.1 : 0;
              audio.bossRoar();
            }
          } else if (e.state === 1) {
            e.vx *= 0.9;
            e.vy *= 0.9;
            if (e.telegraph <= 0) {
              e.fireT -= dt;
              for (let k = 0; k < 3; k++) {
                const n = 16;
                for (let i2 = 0; i2 < n; i2++) {
                  const a = (i2 / n) * TAU + k * 0.16 + e.spin;
                  this.bolts.push({ x: e.x + Math.cos(a) * e.r, y: e.y + Math.sin(a) * e.r, vx: Math.cos(a) * 230, vy: Math.sin(a) * 230, r: 8, dmg: 1, life: 4, color: "#e2382f", hostile: true, pierce: 0 });
                }
              }
              audio.bolt();
              this.kick(8, 0.2);
              e.telegraph = 0.42;
              if (e.fireT <= 0) {
                e.state = 0;
                e.telegraph = 2.4;
              }
            }
          } else if (e.state === 2) {
            if (e.telegraph > 0.6) {
              e.face = toP;
              e.vx *= 0.86;
              e.vy *= 0.86;
            } else {
              e.vx = Math.cos(e.face) * 620;
              e.vy = Math.sin(e.face) * 620;
              if (Math.random() < 0.8) this.smoke(e.x, e.y, "rgba(226,56,47,0.35)", 2);
            }
            if (e.telegraph <= 0) {
              e.state = 0;
              e.telegraph = 2.2;
            }
          } else if (e.telegraph <= 0) {
            for (let i3 = 0; i3 < 4; i3++) {
              const a = (i3 / 4) * TAU + Math.random();
              const en = this.makeEnemy("wisp", e.x + Math.cos(a) * 80, e.y + Math.sin(a) * 80);
              en.born = 0.3;
              this.enemies.push(en);
              this.ringFx(en.x, en.y, 70, "#3fe6b8", 0.4, 3);
            }
            e.state = 0;
            e.telegraph = 2.6;
          }
          break;
        }
        default: {
          const k = awake ? 1 : 0.25;
          const a = awake ? toP : this.t * 0.3 + e.id * 1.7;
          e.vx = lerp(e.vx, Math.cos(a) * e.speed * slowFactor * k, 0.07);
          e.vy = lerp(e.vy, Math.sin(a) * e.speed * slowFactor * k, 0.07);
        }
      }

      e.x += e.vx * dt;
      e.y += e.vy * dt;
      // stunned bodies bleed off their momentum (covers warden & charger AI that ignores slowFactor)
      if (e.stun && e.stun > 0) {
        e.vx *= 0.84;
        e.vy *= 0.84;
      }
      // Ashvale's wards banish anything that crosses the gate
      if (m.kind === "overworld" && zoneAt(m, e.x, e.y)?.safe) {
        this.burst(e.x, e.y, "#8ef6da", 10, 2, 0.4);
        this.text(e.x, e.y - 20, "BANISHED", "#8ef6da", 12, true);
        this.enemies.splice(i, 1);
        continue;
      }
      const rr = resolveCircle(m, e.x, e.y, e.r * 0.8);
      if (rr.hit) {
        e.x = rr.x;
        e.y = rr.y;
        if (e.kind === "charger" && e.state === 2) {
          e.state = 0;
          e.vx *= 0.1;
          e.vy *= 0.1;
        }
        if (e.kind === "warden" && e.state === 2) {
          e.state = 0;
          e.telegraph = 1.6;
          this.kick(14, 0.3);
        }
      }

      // slash hit detection
      if (p.slashing > 0) {
        for (const arc of this.arcs) {
          if (arc.targets.includes(e.id)) continue;
          const d = Math.hypot(e.x - arc.x, e.y - arc.y);
          if (d > arc.reach + e.r || d < arc.inner) continue;
          if (Math.abs(angDelta(Math.atan2(e.y - arc.y, e.x - arc.x), arc.angle)) > arc.arc) continue;
          arc.targets.push(e.id);
          const wp = this.weapon();
          const crit = Math.random() < (p.crit + wp.crit) * p.luck;
          let dmg = p.dmg * p.dmgMult * wp.dmg * (p.frenzyOn ? 1.9 : 1) * (p.rageT > 0 ? 1.4 : 1);
          if (crit) dmg *= p.critMult;
          if (p.execute > 0 && e.hp / e.maxHp < 0.35) dmg *= 1 + p.execute;
          // weapon passives
          if (wp.passiveId === "eyecrit" && crit && e.kind !== "warden" && e.hp / e.maxHp < 0.2) {
            dmg = e.hp + 1;
            this.text(e.x, e.y - e.r - 26, "JUDGED", "#ff6b7d", 16, true);
          }
          if (wp.passiveId === "bleed") this.bleeds.push({ id: e.id, dps: (dmg * 0.25) / 2, t: 2 });
          if (wp.passiveId === "voidpull") {
            for (const o of this.enemies) {
              const dd = Math.hypot(o.x - p.x, o.y - p.y);
              if (dd < p.reach * 1.8 && dd > 40 && o.kind !== "warden") {
                o.vx += ((p.x - o.x) / dd) * 260;
                o.vy += ((p.y - o.y) / dd) * 260;
              }
            }
            for (const s of this.souls) if (Math.hypot(s.x - p.x, s.y - p.y) < p.reach * 2.2) s.pulled = true;
          }
          this.damage(e, dmg, crit, false);
          const ka = Math.atan2(e.y - p.y, e.x - p.x);
          e.vx += Math.cos(ka) * 240;
          e.vy += Math.sin(ka) * 240;
          if (e.kind === "warden") {
            e.vx *= 0.1;
            e.vy *= 0.1;
          }
        }
      }

      // contact
      if (dist < e.r + p.r) {
        if (dashing) {
          if (!e.grazed) {
            e.grazed = true;
            p.grazes = Math.min(9, p.grazes + 1);
            this.grazes++;
            p.score += Math.floor(40 * p.greed);
            p.frenzy = clamp(p.frenzy + (p.frenzyOn ? 0 : 4.5), 0, 100);
            this.text(e.x, e.y - 22, "GRAZE", "#8ef6da", 14, true);
            audio.graze();
            this.burst(e.x, e.y, "#8ef6da", 6, 1.6, 0.3);
          }
        } else if (e.contactCd <= 0 && p.invuln <= 0 && !(e.stun && e.stun > 0)) {
          e.contactCd = 0.6;
          this.hurt(e.dmg, e);
        }
      }
      if (e.hp <= 0) this.killEnemy(e, i);
    }
  }

  private updateBolts(dt: number) {
    const p = this.player;
    for (let i = this.bolts.length - 1; i >= 0; i--) {
      const b = this.bolts[i];
      b.x += b.vx * dt;
      b.y += b.vy * dt;
      b.life -= dt;
      if (Math.random() < 0.5) this.parts.push({ x: b.x, y: b.y, vx: rand(-8, 8), vy: rand(-8, 8), r: b.r * 0.6, life: 0.22, maxLife: 0.22, color: b.color, kind: 1, drag: 3, add: true });
      if (Math.hypot(b.x - p.x, b.y - p.y) < p.r + b.r) {
        if (p.invuln <= 0 && p.dashT <= 0) this.hurt(1);
        this.bolts.splice(i, 1);
        continue;
      }
      if (b.life <= 0 || !walkableAt(this.map, b.x, b.y)) {
        this.burst(b.x, b.y, b.color, 4, 1.4, 0.25);
        this.bolts.splice(i, 1);
      }
    }
  }

  private updateRings(dt: number) {
    for (let i = this.rings.length - 1; i >= 0; i--) {
      const rg = this.rings[i];
      if (rg.speed > 0) {
        rg.r += rg.speed * dt;
        for (const e of this.enemies) {
          if (rg.hits.has(e.id)) continue;
          const d = Math.hypot(e.x - rg.x, e.y - rg.y);
          if (d < rg.r + e.r && d > rg.r - 46) {
            rg.hits.add(e.id);
            this.damage(e, rg.dmg, false, true);
            const a = Math.atan2(e.y - rg.y, e.x - rg.x);
            e.vx += Math.cos(a) * 300;
            e.vy += Math.sin(a) * 300;
          }
        }
        if (rg.r > rg.maxR) this.rings.splice(i, 1);
      } else {
        rg.life -= dt;
        if (rg.life <= 0) this.rings.splice(i, 1);
      }
    }
  }

  private updateSouls(dt: number) {
    const p = this.player;
    for (let i = this.souls.length - 1; i >= 0; i--) {
      const s = this.souls[i];
      s.t += dt * 3;
      s.life -= dt;
      if (s.life <= 0) {
        this.souls.splice(i, 1);
        continue;
      }
      const d = Math.hypot(p.x - s.x, p.y - s.y);
      if (!s.pulled && d < (p.frenzyOn ? 1e9 : p.magnet)) s.pulled = true;
      if (s.pulled) {
        const pull = p.frenzyOn ? 2600 : 1150;
        const a = Math.atan2(p.y - s.y, p.x - s.x);
        s.vx += Math.cos(a) * pull * dt;
        s.vy += Math.sin(a) * pull * dt;
        const sp = Math.hypot(s.vx, s.vy);
        const maxSp = p.frenzyOn ? 1500 : 780;
        if (sp > maxSp) {
          s.vx = (s.vx / sp) * maxSp;
          s.vy = (s.vy / sp) * maxSp;
        }
      } else {
        s.vx *= 0.9;
        s.vy *= 0.9;
      }
      s.x += s.vx * dt;
      s.y += s.vy * dt;
      if (!s.pulled && !walkableAt(this.map, s.x, s.y)) {
        s.x -= s.vx * dt * 2;
        s.y -= s.vy * dt * 2;
        s.vx *= -0.5;
        s.vy *= -0.5;
      }
      if (d < p.r + s.r + 6) {
        this.collect(s);
        this.souls.splice(i, 1);
      }
    }
  }

  private updateParticles(dt: number, rawDt: number) {
    for (let i = this.parts.length - 1; i >= 0; i--) {
      const q = this.parts[i];
      q.life -= dt;
      if (q.life <= 0) {
        this.parts[i] = this.parts[this.parts.length - 1];
        this.parts.pop();
        continue;
      }
      q.x += q.vx * dt;
      q.y += q.vy * dt;
      const dg = 1 - q.drag * dt;
      q.vx *= dg;
      q.vy *= dg;
      if (q.kind === 1) q.vy -= 24 * dt;
      if (q.kind === 3) q.vy -= 10 * dt;
    }
    for (let i = this.texts.length - 1; i >= 0; i--) {
      const tx = this.texts[i];
      tx.life -= rawDt;
      tx.y += tx.vy * rawDt;
      tx.vy *= 0.94;
      if (tx.life <= 0) this.texts.splice(i, 1);
    }
    for (let i = this.ghosts.length - 1; i >= 0; i--) {
      this.ghosts[i].life -= rawDt;
      if (this.ghosts[i].life <= 0) this.ghosts.splice(i, 1);
    }
    for (let i = this.arcs.length - 1; i >= 0; i--) {
      this.arcs[i].life -= dt;
      if (this.arcs[i].life <= 0) this.arcs.splice(i, 1);
    }
  }

  private updateAttract(dt: number) {
    this.t += dt;
    const p = this.player;
    p.aim = -Math.PI / 2 + Math.sin(this.t * 0.4) * 0.3;
    p.orbitAngle += dt * 1.6;
    if (Math.random() < 0.08) {
      const a = Math.random() * TAU;
      const d = rand(60, 520);
      const x = p.x + Math.cos(a) * d;
      const y = p.y + Math.sin(a) * d;
      if (walkableAt(this.map, x, y)) this.addSoul(x, y, Math.random() < 0.25 ? "gold" : "pure", 0, 0);
    }
    for (let i = this.souls.length - 1; i >= 0; i--) {
      const s = this.souls[i];
      s.t += dt * 2.4;
      s.life -= dt;
      s.x += s.vx * dt;
      s.y += s.vy * dt;
      s.vx *= 0.995;
      s.vy *= 0.995;
      if (s.life <= 0) this.souls.splice(i, 1);
    }
    this.updateParticles(dt, dt);
    for (let i = this.rings.length - 1; i >= 0; i--) {
      this.rings[i].life -= dt;
      if (this.rings[i].life <= 0) this.rings.splice(i, 1);
    }
    this.cam.x = lerp(this.cam.x, p.x + Math.sin(this.t * 0.12) * 170, 0.02);
    this.cam.y = lerp(this.cam.y, p.y - 40 + Math.cos(this.t * 0.09) * 90, 0.02);
    if (Math.random() < 0.05) this.burst(p.x, p.y - 10, "#8ef6da", 2, 0.7, 1.1);
  }

  /* ---------- active skills (Q / F / C) ---------- */
  castSkill(i: number) {
    if (this.mode !== "play" || this.frozen || this.dead || this.shopOpen) return;
    const def = SKILLS[i];
    if (!def || this.skillCd[i] > 0) return;
    const p = this.player;
    const wp = this.weapon();
    this.skillCd[i] = def.cd * (p.frenzyOn ? 0.7 : 1);
    const fx: SkillFx = {
      id: def.id,
      x: p.x,
      y: p.y,
      a: p.aim,
      t: 0,
      dur: def.dur,
      r: def.id === "cyclone" ? p.reach * wp.reach * 0.95 : def.id === "lance" ? 380 * wp.reach : 230,
      color: def.color,
      seed: Math.random() * 1e6,
      hits: new Map(),
      hit: false,
      cracks: def.id === "slam" ? makeCracks(Math.random() * 1e6, 230) : [],
    };
    this.skillFx.push(fx);
    this.text(p.x, p.y - 58, def.name.toUpperCase(), def.color, 14, true);
    if (def.id === "cyclone") {
      p.invuln = Math.max(p.invuln, 0.6);
      audio.cyclone();
      this.kick(7, 0.35);
    } else if (def.id === "lance") {
      p.invuln = Math.max(p.invuln, 0.25);
      audio.lance();
      this.kick(9, 0.2);
      // lunge along the beam
      p.vx = Math.cos(p.aim) * 640;
      p.vy = Math.sin(p.aim) * 640;
      this.lanceStrike(fx, this.skillBase());
    } else {
      audio.slamCharge();
      this.kick(3, 0.3);
    }
    this.hud();
  }

  private skillBase() {
    const p = this.player;
    return p.dmg * p.dmgMult * this.weapon().dmg * (p.frenzyOn ? 1.9 : 1) * (p.rageT > 0 ? 1.4 : 1);
  }

  private lanceStrike(fx: SkillFx, base: number) {
    const dx = Math.cos(fx.a);
    const dy = Math.sin(fx.a);
    for (const e of this.enemies) {
      if (e.born > 0) continue;
      const rx = e.x - fx.x;
      const ry = e.y - fx.y;
      const along = rx * dx + ry * dy;
      if (along < 0 || along > fx.r) continue;
      const across = Math.abs(-rx * dy + ry * dx);
      if (across > 30 + e.r) continue;
      this.skillHit(e, base * 2.6, dx, dy, 360, 0);
      this.burst(e.x, e.y, fx.color, 14, 3, 0.4);
    }
    fx.hit = true;
  }

  private skillHit(e: Enemy, dmg: number, kx: number, ky: number, kb: number, stun: number, silent = false) {
    this.damage(e, dmg, false, silent);
    e.vx += kx * kb;
    e.vy += ky * kb;
    if (stun > 0) e.stun = Math.max(e.stun ?? 0, stun);
  }

  private updateSkills(dt: number) {
    for (let i = 0; i < this.skillCd.length; i++) {
      if (this.skillCd[i] > 0) this.skillCd[i] = Math.max(0, this.skillCd[i] - dt);
    }
    const p = this.player;
    for (let i = this.skillFx.length - 1; i >= 0; i--) {
      const fx = this.skillFx[i];
      fx.t += dt;

      if (fx.id === "cyclone") {
        // the storm travels with the reaper
        fx.x = p.x;
        fx.y = p.y;
        fx.a += dt * 13;
        const base = this.skillBase();
        for (const e of this.enemies) {
          if (e.born > 0) continue;
          if (Math.hypot(e.x - fx.x, e.y - fx.y) > fx.r + e.r) continue;
          const last = fx.hits.get(e.id);
          if (last !== undefined && fx.t - last < 0.22) continue;
          fx.hits.set(e.id, fx.t);
          const ka = Math.atan2(e.y - fx.y, e.x - fx.x);
          this.skillHit(e, base * 0.55, Math.cos(ka), Math.sin(ka), 120, 0, true);
          this.burst(e.x, e.y, fx.color, 5, 2, 0.3);
        }
        if (Math.random() < 0.5) {
          const a = Math.random() * TAU;
          this.burst(fx.x + Math.cos(a) * fx.r * 0.9, fx.y + Math.sin(a) * fx.r * 0.9, fx.color, 2, 1.6, 0.3);
        }
      } else if (fx.id === "slam" && !fx.hit && fx.t >= SLAM_WINDUP) {
        // impact: crater, dust, shockwave and a stun-knockback on everything in range
        fx.hit = true;
        const base = this.skillBase();
        this.ringFx(fx.x, fx.y, fx.r, fx.color, 0.5, 8);
        this.burst(fx.x, fx.y, "#c9b48a", 40, 3.6, 0.7);
        this.burst(fx.x, fx.y, fx.color, 24, 4, 0.6);
        this.smoke(fx.x, fx.y, "rgba(120,100,80,0.4)", 10);
        this.kick(26, 0.5);
        this.flash = Math.max(this.flash, 0.35);
        this.hitStop = Math.max(this.hitStop, 0.06);
        audio.slam();
        for (const e of this.enemies) {
          if (e.born > 0) continue;
          const d = Math.hypot(e.x - fx.x, e.y - fx.y);
          if (d > fx.r + e.r) continue;
          const falloff = 1 - 0.35 * (d / fx.r);
          const ka = Math.atan2(e.y - fx.y, e.x - fx.x);
          this.skillHit(e, base * 2.2 * falloff, Math.cos(ka), Math.sin(ka), 320, 1.1);
        }
      }

      if (fx.t >= fx.dur) this.skillFx.splice(i, 1);
    }
  }

  /* ---------- combat ---------- */
  private doSlash() {
    const p = this.player;
    p.slashT = p.slashCd * this.weapon().cd * (p.rageT > 0 ? 0.55 : 1) * (p.frenzyOn ? 0.6 : 1);
    this.fireArc(p.aim, false);
    if (p.echo > 0 && Math.random() < p.echo) this.pending.push({ t: 0.16, angle: p.aim + rand(-0.5, 0.5) });
    for (let i = 0; i < p.shock; i++) {
      this.rings.push({ x: p.x, y: p.y, r: 30 + i * 16, maxR: 300 + i * 90, speed: 620, dmg: 26 * p.dmgMult * (p.frenzyOn ? 1.7 : 1), color: "#8ef6da", life: 1, maxLife: 1, width: 4, hits: new Set() });
    }
    p.vx += Math.cos(p.aim) * 130;
    p.vy += Math.sin(p.aim) * 130;
  }

  private fireArc(angle: number, echo: boolean) {
    const p = this.player;
    const wp = this.weapon();
    const arcW = Math.min(2.4, p.arc * wp.arc);
    const reach = p.reach * wp.reach * (echo ? 0.9 : 1);
    p.slashing = 0.11;
    this.arcs.push({ x: p.x, y: p.y, angle, arc: arcW, reach, inner: 18, life: 0.19, maxLife: 0.19, gold: p.frenzyOn, dmg: 0, targets: [] });
    audio.slash();
    this.kick(p.frenzyOn ? 4.5 : 3, 0.14);
    const sparkCol = p.frenzyOn ? "#ffc94a" : wp.id === "mournsong" ? "#8ef6da" : wp.glow;
    for (let i = 0; i < 9; i++) {
      const a = angle - arcW + (i / 8) * arcW * 2;
      const rr = reach * 0.95;
      this.parts.push({ x: p.x + Math.cos(a) * rr, y: p.y + Math.sin(a) * rr, vx: Math.cos(a) * rand(80, 260), vy: Math.sin(a) * rand(80, 260), r: rand(2, 5), life: 0.28, maxLife: 0.28, color: sparkCol, kind: 1, drag: 2.4, add: true });
    }
  }

  private damage(e: Enemy, amount: number, crit: boolean, silent: boolean) {
    if (e.born > 0) return;
    e.hp -= amount;
    e.hit = 5;
    if (!silent) {
      audio.hit();
      this.kick(crit ? 9 : 5, 0.16);
      this.hitStop = Math.max(this.hitStop, crit ? 0.05 : 0.028);
      const a = Math.atan2(e.y - this.player.y, e.x - this.player.x);
      this.burst(e.x - Math.cos(a) * e.r * 0.6, e.y - Math.sin(a) * e.r * 0.6, crit ? "#ffdd8a" : "#ffffff", crit ? 10 : 5, 2.2, 0.3);
      this.text(e.x + rand(-10, 10), e.y - e.r - 6, crit ? `${Math.round(amount)}!` : `${Math.round(amount)}`, crit ? "#ffc94a" : "#f1ead9", crit ? 22 : 14, crit);
    }
  }

  private killEnemy(e: Enemy, index: number) {
    const p = this.player;
    this.enemies.splice(index, 1);
    this.kills++;
    this.killStats[e.kind] = (this.killStats[e.kind] ?? 0) + 1;
    p.harvest++;
    const mult = 1 + Math.min(p.combo, 60) * 0.05;
    const gained = Math.floor(e.score * mult * p.greed * (p.frenzyOn ? 2 : 1));
    p.score += gained;
    this.dropSouls(e);
    audio.kill();
    const boss = e.kind === "warden";
    this.kick(boss ? 34 : 8, boss ? 0.9 : 0.22);
    this.hitStop = Math.max(this.hitStop, boss ? 0.26 : 0.045);
    this.burst(e.x, e.y, e.hue, boss ? 90 : 20, boss ? 5 : 3.2, 0.65);
    this.smoke(e.x, e.y, "rgba(30,18,48,0.5)", boss ? 14 : 4);
    this.ringFx(e.x, e.y, boss ? 620 : e.r * 5, boss ? "#ffc94a" : e.hue, boss ? 0.9 : 0.35, boss ? 12 : 4);
    this.text(e.x, e.y - e.r - 16, `+${gained}`, "#ffc94a", boss ? 30 : 15, boss);
    if (e.kind === "stalker") {
      for (let i = 0; i < 2; i++) {
        const a = Math.random() * TAU;
        const child = this.makeEnemy("phantom", e.x + Math.cos(a) * 26, e.y + Math.sin(a) * 26);
        child.r = 15;
        child.hp = child.maxHp = 26 * this.tierScale();
        child.speed = 128;
        child.hue = "#ff9a4d";
        child.born = 0.2;
        child.vx = Math.cos(a) * 160;
        child.vy = Math.sin(a) * 160;
        this.enemies.push(child);
      }
    }
    if (boss) {
      this.bossId = 0;
      this.flash = 0.8;
      this.timeScale = 0.3;
      this.slowMo = 0.75;
      this.hooks.onToast({ title: "WARDEN SLAIN", sub: `+${gained.toLocaleString()} souls · the stairs unseal`, kind: "milestone" });
      p.frenzy = 100;
      if (!p.frenzyOn) this.startFrenzy();
      this.openLevelUp();
    }
  }

  private startFrenzy() {
    const p = this.player;
    p.frenzyOn = true;
    p.frenzyT = p.frenzyMax;
    p.frenzy = 100;
    audio.frenzyStart();
    this.flash = 0.6;
    this.kick(20, 0.6);
    this.ringFx(p.x, p.y, 560, "#ffc94a", 0.7, 10);
    this.ringFx(p.x, p.y, 380, "#ff6a1f", 0.55, 6);
    this.burst(p.x, p.y, "#ffdd8a", 60, 4.4, 0.8);
    this.hooks.onToast({ title: "SOUL FRENZY", sub: "the veil tears open", kind: "frenzy" });
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * TAU;
      const x = p.x + Math.cos(a) * rand(140, 320);
      const y = p.y + Math.sin(a) * rand(140, 320);
      if (walkableAt(this.map, x, y)) this.addSoul(x, y, "gold", 26, 90);
    }
  }

  private collect(s: Soul) {
    const p = this.player;
    switch (s.kind) {
      case "life":
        p.hp = Math.min(p.maxHp, p.hp + 1);
        audio.soul(true, false);
        this.burst(p.x, p.y, "#3fe6b8", 16, 2.4, 0.5);
        this.text(p.x, p.y - 40, "+1 HEART", "#8ef6da", 18, true);
        break;
      case "nova":
        audio.nova();
        this.flash = 0.55;
        this.kick(24, 0.5);
        this.rings.push({ x: p.x, y: p.y, r: 20, maxR: 560, speed: 1250, dmg: 130 * p.dmgMult, color: "#ffc94a", life: 1, maxLife: 1, width: 10, hits: new Set() });
        this.text(p.x, p.y - 44, "SOUL NOVA", "#ffdd8a", 22, true);
        break;
      case "rage":
        p.rageT = 6.5;
        audio.soul(true, true);
        this.burst(p.x, p.y, "#ff6a1f", 24, 3, 0.6);
        this.text(p.x, p.y - 44, "RAGE ×2 SPEED", "#ff9a4d", 20, true);
        break;
      case "shield":
        p.shields = Math.min(3, p.shields + 1);
        audio.soul(true, false);
        this.ringFx(p.x, p.y, 130, "#8ef6da", 0.5, 5);
        this.text(p.x, p.y - 44, "WARD +1", "#c7fff0", 18, true);
        break;
      default: {
        const gold = s.kind === "gold";
        p.combo++;
        p.bestCombo = Math.max(p.bestCombo, p.combo);
        p.comboT = 2.3;
        p.harvest++;
        const mult = 1 + Math.min(p.combo, 60) * 0.05;
        p.score += Math.floor(s.score * mult * p.greed * (p.frenzyOn ? 2 : 1));
        p.xp += Math.floor(s.xp * p.xpMult * (p.frenzyOn ? 1.4 : 1));
        if (!p.frenzyOn) {
          const gain = (gold ? 9 : 3.4) * (1 + p.combo * 0.03) * p.frenzyMult * diffOf(this.difficulty).frenzy;
          p.frenzy = clamp(p.frenzy + gain, 0, 100);
          if (p.frenzy >= 100) this.startFrenzy();
        }
        if (p.lifesteal > 0 && Math.random() < p.lifesteal && p.hp < p.maxHp) {
          p.hp++;
          this.text(p.x, p.y - 36, "SIPHONED", "#3fe6b8", 14, true);
          this.burst(p.x, p.y, "#3fe6b8", 10, 2, 0.5);
        }
        audio.soul(gold, p.frenzyOn);
        this.burst(p.x, p.y, gold ? "#ffc94a" : "#3fe6b8", gold ? 14 : 6, gold ? 2.6 : 1.6, 0.36);
        if (gold) this.text(p.x, p.y - 26, `+${Math.floor(s.score * mult)}`, "#ffeeb2", 17, true);
        if (p.combo > 0 && p.combo % 15 === 0 && p.combo > this.milestone) {
          this.milestone = p.combo;
          this.text(p.x, p.y - 58, `${p.combo} CHAIN — ×${mult.toFixed(2)}`, "#ffc94a", 24, true);
          this.ringFx(p.x, p.y, 300, "#ffc94a", 0.5, 6);
          audio.record();
          this.kick(10, 0.3);
          for (let i = 0; i < 4; i++) {
            const a = Math.random() * TAU;
            const x = p.x + Math.cos(a) * rand(120, 260);
            const y = p.y + Math.sin(a) * rand(120, 260);
            if (walkableAt(this.map, x, y)) this.addSoul(x, y, "gold", 22, 70);
          }
          if (p.combo >= 40) p.hp = Math.min(p.maxHp, p.hp + 1);
        }
        if (p.xp >= p.xpNeed) this.levelUp();
      }
    }
  }

  private hurt(amount: number, from?: Enemy) {
    const p = this.player;
    if (p.invuln > 0) return;
    if (p.shields > 0) {
      p.shields--;
      p.invuln = 0.7;
      audio.shieldBreak();
      this.ringFx(p.x, p.y, 190, "#8ef6da", 0.45, 7);
      this.text(p.x, p.y - 40, "WARD BROKEN", "#c7fff0", 17, true);
      this.kick(10, 0.25);
      return;
    }
    p.hp -= amount;
    p.combo = 0;
    p.comboT = 0;
    p.invuln = 1.15 * diffOf(this.difficulty).invuln;
    this.hurtFx = 1;
    this.hitStop = 0.1;
    this.kick(22, 0.55);
    this.flash = 0.28;
    audio.hurt();
    this.burst(p.x, p.y, "#e2382f", 26, 3.2, 0.6);
    this.smoke(p.x, p.y, "rgba(226,56,47,0.25)", 6);
    if (from) {
      const a = Math.atan2(p.y - from.y, p.x - from.x);
      p.vx = Math.cos(a) * 420;
      p.vy = Math.sin(a) * 420;
    }
    if (p.hp <= 0) {
      p.hp = 0;
      this.gameOver();
    }
  }

  private levelUp() {
    const p = this.player;
    while (p.xp >= p.xpNeed) {
      p.xp -= p.xpNeed;
      p.level++;
      p.xpNeed = Math.round(86 * Math.pow(1.2, p.level - 1) + 14 * p.level);
    }
    audio.levelUp();
    this.flash = 0.4;
    this.ringFx(p.x, p.y, 420, "#ffc94a", 0.6, 8);
    this.burst(p.x, p.y, "#ffdd8a", 40, 3.2, 0.7);
    this.text(p.x, p.y - 52, `LEVEL ${p.level}`, "#ffc94a", 28, true);
    this.hud();
    this.openLevelUp();
  }

  private gameOver() {
    this.mode = "attract";
    this.frozen = false;
    this.bolts = [];
    this.pending = [];
    this.slashQueued = this.dashQueued = false;
    this.skillFx = [];
    this.holdSlash = false;
    this.dead = true;
    this.bankSouls();
    audio.gameOver();
    audio.stopMusic();
    audio.setIntensity(0);
    const p = this.player;
    this.burst(p.x, p.y, "#e2382f", 70, 4, 1.1);
    this.ringFx(p.x, p.y, 520, "#e2382f", 0.9, 10);
    this.kick(30, 0.9);
    this.hooks.onOver({
      score: p.score,
      level: p.level,
      wave: this.maxDepth,
      kills: this.kills,
      bestCombo: p.bestCombo,
      harvest: p.harvest,
      grazes: this.grazes,
      time: this.t,
      rank: rankFor(p.score, this.maxDepth),
      newRecord: false,
      boons: Object.entries(p.stacked).map(([id, n]) => ({ id, n })),
      difficulty: this.difficulty,
      killsByKind: { ...this.killStats },
      timeline: this.timeline.slice(-200),
    });
    this.hooks.onPhase("over");
  }

  private hud() {
    const p = this.player;
    const boss = this.bossId ? this.enemies.find((e) => e.id === this.bossId) : undefined;
    const m = this.map;
    const combatRooms = m.rooms.filter((r) => r.kind === "combat" || r.kind === "boss");
    this.hooks.onHud({
      score: p.score,
      combo: p.combo,
      comboPct: clamp(p.comboT / 2.3, 0, 1) * 100,
      bestCombo: p.bestCombo,
      level: p.level,
      xpPct: clamp(p.xp / p.xpNeed, 0, 1) * 100,
      xp: p.xp,
      xpNeed: p.xpNeed,
      hp: p.hp,
      maxHp: p.maxHp,
      shields: p.shields,
      dash: p.dashCharges,
      maxDash: p.maxDash,
      dashPct: p.dashCharges >= p.maxDash ? 100 : clamp(1 - p.dashCd / p.dashCdMax, 0, 1) * 100,
      frenzy: p.frenzy,
      frenzyOn: p.frenzyOn,
      frenzyPct: p.frenzyOn ? clamp(p.frenzyT / p.frenzyMax, 0, 1) * 100 : clamp(p.frenzy, 0, 100),
      wave: this.maxDepth,
      kills: this.kills,
      time: this.t,
      bossHp: boss ? clamp(boss.hp / boss.maxHp, 0, 1) : -1,
      bossName: boss ? "WARDEN OF THE HOLLOW VAULT" : "",
      rage: Math.max(0, p.rageT),
      boons: Object.entries(p.stacked).map(([id, n]) => ({ id, n })),
      zone: this.zone?.name ?? "",
      zoneSub: this.zone?.sub ?? "",
      inCrypt: m.kind === "dungeon",
      depth: this.depth,
      roomsCleared: combatRooms.filter((r) => r.cleared).length,
      roomsTotal: combatRooms.length,
      chests: this.chestsOpened,
      prompt: this.prompt,
      safe: !!this.zone?.safe,
      skills: SKILLS.map((s, i) => ({ id: s.id, name: s.name, key: s.key, cd: this.skillCd[i], max: s.cd, color: s.color, icon: s.id })),
    });
  }

  /* ================= render ================= */
  private render(rawDt: number) {
    const ctx = this.ctx;
    const { W, H } = this;
    const p = this.player;
    const m = this.map;
    void rawDt;

    ctx.fillStyle = "#06040c";
    ctx.fillRect(0, 0, W, H);

    const shake = this.cam.shake;
    const sx = shake ? rand(-shake, shake) : 0;
    const sy = shake ? rand(-shake, shake) : 0;
    const ox = Math.round(W / 2 - this.cam.x + sx);
    const oy = Math.round(H / 2 - this.cam.y + sy);
    ctx.save();
    ctx.translate(ox, oy);

    // ---- tiles ----
    const tx0 = Math.max(0, Math.floor((this.cam.x - W / 2 - shake) / TILE));
    const ty0 = Math.max(0, Math.floor((this.cam.y - H / 2 - shake) / TILE));
    const tx1 = Math.min(m.w - 1, Math.floor((this.cam.x + W / 2 + shake) / TILE));
    const ty1 = Math.min(m.h - 1, Math.floor((this.cam.y + H / 2 + shake) / TILE));
    for (let ty = ty0; ty <= ty1; ty++) {
      for (let tx = tx0; tx <= tx1; tx++) {
        const i = ty * m.w + tx;
        const t = m.tiles[i];
        ctx.drawImage(getTile(t, m.vars[i]), tx * TILE, ty * TILE);
      }
    }
    // soft shadows under wall tops & water edge lines (cheap depth)
    ctx.fillStyle = "rgba(0,0,0,0.22)";
    for (let ty = ty0; ty <= ty1; ty++)
      for (let tx = tx0; tx <= tx1; tx++) {
        const t = m.tiles[ty * m.w + tx];
        if (isWallTile(t) && ty + 1 < m.h) {
          const below = m.tiles[(ty + 1) * m.w + tx];
          if (!isWallTile(below) && below !== T.VOID) ctx.fillRect(tx * TILE, (ty + 1) * TILE, TILE, 14);
        }
      }

    const viewL = this.cam.x - W / 2 - 160;
    const viewR = this.cam.x + W / 2 + 160;
    const viewT = this.cam.y - H / 2 - 220;
    const viewB = this.cam.y + H / 2 + 160;

    // ---- floor decals (never y-sorted) ----
    const DECAL = new Set(["rug", "grate", "bonepile", "runecircle", "bones", "chain", "torch", "sconce"]);
    for (const pr of m.props) {
      if (!DECAL.has(pr.kind) || pr.kind === "chain" || pr.kind === "torch" || pr.kind === "sconce") continue;
      if (pr.x < viewL - 200 || pr.x > viewR + 200 || pr.y < viewT - 200 || pr.y > viewB + 200) continue;
      if (pr.kind === "runecircle") {
        ctx.save();
        ctx.globalCompositeOperation = "lighter";
        ctx.globalAlpha = 0.55 + Math.sin(this.t * 2.2) * 0.25;
        ctx.translate(pr.x, pr.y - 130);
        ctx.rotate(this.t * 0.12);
        const s = getProp("runecircle", 0);
        ctx.drawImage(s.cv, -s.ax, -s.ay + 130);
        ctx.restore();
        continue;
      }
      this.drawProp(pr.kind, pr.v, pr.x, pr.y);
    }

    // ---- ground layer: prop shadows, souls' glow, rings, chests' base ----
    ctx.fillStyle = "rgba(0,0,0,0.3)";
    for (const pr of m.props) {
      if (pr.x < viewL || pr.x > viewR || pr.y < viewT || pr.y > viewB) continue;
      if (DECAL.has(pr.kind) || pr.kind === "stairs" || pr.kind === "fence" || pr.kind === "pipe" || pr.kind === "chain") continue;
      ctx.beginPath();
      ctx.ellipse(pr.x, pr.y - 0, pr.r + 10, (pr.r + 10) * 0.42, 0, 0, TAU);
      ctx.fill();
    }

    ctx.globalCompositeOperation = "lighter";
    for (const rg of this.rings) {
      const a = rg.speed > 0 ? 1 : rg.life / rg.maxLife;
      ctx.globalAlpha = clamp(a, 0, 1) * 0.9;
      ctx.strokeStyle = rg.color;
      ctx.lineWidth = rg.width;
      ctx.beginPath();
      ctx.arc(rg.x, rg.y, rg.r, 0, TAU);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";

    // aura under the player
    if (p.aura > 0 && this.mode === "play") {
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      const pulse = 1 + Math.sin(this.t * 3.2) * 0.05;
      const g = ctx.createRadialGradient(p.x, p.y, p.r, p.x, p.y, p.aura * pulse);
      g.addColorStop(0, "rgba(139,62,232,0.22)");
      g.addColorStop(0.6, "rgba(139,62,232,0.08)");
      g.addColorStop(1, "rgba(139,62,232,0)");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.aura * pulse, 0, TAU);
      ctx.fill();
      ctx.restore();
    }

    // ---- y-sorted scene ----
    type Item = { y: number; d: () => void };
    const items: Item[] = [];
    for (const pr of m.props) {
      if (pr.x < viewL || pr.x > viewR || pr.y < viewT || pr.y > viewB) continue;
      if (DECAL.has(pr.kind) && pr.kind !== "sconce" && pr.kind !== "torch" && pr.kind !== "chain") continue;
      const wallMounted = pr.kind === "sconce" || pr.kind === "torch" || pr.kind === "chain" || pr.kind === "pipe";
      items.push({ y: wallMounted ? pr.y - 10000 : pr.y, d: () => this.drawProp(pr.kind, pr.v, pr.x, pr.y) });
    }
    for (const c of m.chests) {
      if (c.x < viewL || c.x > viewR || c.y < viewT || c.y > viewB) continue;
      items.push({
        y: c.y,
        d: () => {
          if (!c.opened) {
            ctx.globalCompositeOperation = "lighter";
            this.addGlow(c.x, c.y - 16, 44 + Math.sin(this.t * 3 + c.id) * 4, c.tier === 2 ? "#ffc94a" : c.tier === 1 ? "#8ef6da" : "#ffb060", 0.28);
            ctx.globalCompositeOperation = "source-over";
          }
          this.drawProp(c.opened ? "chestOpen" : "chest", c.tier, c.x, c.y);
        },
      });
    }
    for (const pt of m.portals) {
      if (pt.kind === "stairs" || pt.kind === "crypt" || pt.kind === "exit") {
        items.push({
          y: pt.y - 60,
          d: () => {
            ctx.globalCompositeOperation = "lighter";
            this.addGlow(pt.x, pt.y, 90 + Math.sin(this.t * 2) * 8, pt.locked ? "#e2382f" : pt.kind === "stairs" ? "#b46cff" : "#ff9a4d", pt.locked ? 0.25 : 0.4);
            ctx.globalCompositeOperation = "source-over";
          },
        });
      }
    }
    for (const e of this.enemies) {
      if (e.x < viewL || e.x > viewR || e.y < viewT || e.y > viewB) continue;
      items.push({ y: e.y + e.r, d: () => this.drawEnemy(e) });
    }
    for (const g of this.ghosts) items.push({ y: g.y - 1, d: () => drawReaperGhost(ctx, g.x, g.y, p.r * 0.92, g.a, p.frenzyOn ? "#ffc94a" : "#8ef6da", (g.life / g.max) * 0.34) });
    items.push({ y: p.y + p.r, d: () => this.drawPlayer() });
    items.sort((a, b) => a.y - b.y);
    for (const it of items) it.d();

    // ---- souls, bolts, arcs, particles (additive) ----
    ctx.globalCompositeOperation = "lighter";
    for (const s of this.souls) {
      const pulse = 1 + Math.sin(s.t) * 0.16;
      const fade = s.life < 3 ? 0.35 + Math.abs(Math.sin(s.t * 3)) * 0.65 : 1;
      const col = s.kind === "gold" ? "#ffc94a" : s.kind === "nova" ? "#ffdd8a" : s.kind === "rage" ? "#ff6a1f" : s.kind === "shield" ? "#8ef6da" : "#3fe6b8";
      const big = s.kind === "pure" || s.kind === "gold" ? 1 : 1.9;
      this.addGlow(s.x, s.y, s.r * 3.2 * pulse * big, col, 0.55 * fade);
      ctx.fillStyle = "#ffffff";
      ctx.globalAlpha = fade;
      ctx.beginPath();
      ctx.arc(s.x, s.y, s.r * 0.42 * pulse, 0, TAU);
      ctx.fill();
      ctx.globalAlpha = 1;
    }
    for (const b of this.bolts) {
      this.addGlow(b.x, b.y, b.r * 3.4, b.color, 0.7);
      ctx.fillStyle = "#fff6dd";
      ctx.beginPath();
      ctx.arc(b.x, b.y, b.r * 0.55, 0, TAU);
      ctx.fill();
    }
    for (const a of this.arcs) {
      const k = a.life / a.maxLife;
      const rr = a.reach * (1.06 - k * 0.12);
      const grd = ctx.createRadialGradient(a.x, a.y, rr * 0.42, a.x, a.y, rr);
      grd.addColorStop(0, "rgba(0,0,0,0)");
      grd.addColorStop(0.72, a.gold ? "rgba(255,201,74,0.85)" : "rgba(126,246,218,0.8)");
      grd.addColorStop(1, "rgba(255,255,255,0.05)");
      ctx.globalAlpha = k;
      ctx.fillStyle = grd;
      ctx.beginPath();
      ctx.moveTo(a.x, a.y);
      ctx.arc(a.x, a.y, rr, a.angle - a.arc, a.angle + a.arc);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = a.gold ? "#ffeeb2" : "#c7fff0";
      ctx.lineWidth = 3 + k * 4;
      ctx.beginPath();
      ctx.arc(a.x, a.y, rr * 0.99, a.angle - a.arc, a.angle + a.arc);
      ctx.stroke();
      ctx.globalAlpha = 1;
    }
    for (const q of this.parts) {
      const a = clamp(q.life / q.maxLife, 0, 1);
      if (q.add) this.addGlow(q.x, q.y, q.r * (q.kind === 1 ? 4 : 2.6), q.color, a * 0.5);
      ctx.globalAlpha = a * (q.kind === 3 ? 0.5 : 1);
      ctx.fillStyle = q.color;
      ctx.beginPath();
      ctx.arc(q.x, q.y, q.r * (q.kind === 3 ? 1 + (1 - a) * 1.6 : 1), 0, TAU);
      ctx.fill();
      ctx.globalAlpha = 1;
    }
    ctx.globalCompositeOperation = "source-over";

    // skill animations (world space, additive)
    drawSkillFx(ctx, this.skillFx, this.enemies, this.t);

    // aim reticle
    if (this.mode === "play" && this.mouse.active) {
      const rx = this.mouse.x - W / 2 + this.cam.x;
      const ry = this.mouse.y - H / 2 + this.cam.y;
      ctx.globalCompositeOperation = "lighter";
      ctx.strokeStyle = "rgba(255,201,74,0.5)";
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.arc(rx, ry, 12 + Math.sin(this.t * 6) * 1.5, 0, TAU);
      ctx.moveTo(rx - 20, ry);
      ctx.lineTo(rx - 8, ry);
      ctx.moveTo(rx + 8, ry);
      ctx.lineTo(rx + 20, ry);
      ctx.stroke();
      ctx.globalCompositeOperation = "source-over";
    }

    ctx.restore();

    // ---- lighting pass (screen space) ----
    this.drawLighting(ox, oy);

    // floating text (after lighting so it stays readable)
    ctx.save();
    ctx.translate(ox, oy);
    ctx.textAlign = "center";
    for (const tx of this.texts) {
      ctx.globalAlpha = clamp(tx.life / tx.maxLife, 0, 1);
      ctx.font = `${tx.bold ? 700 : 600} ${tx.size}px "Chakra Petch", sans-serif`;
      ctx.lineWidth = 3;
      ctx.strokeStyle = "rgba(6,4,12,0.75)";
      ctx.strokeText(tx.text, tx.x, tx.y);
      ctx.fillStyle = tx.color;
      ctx.fillText(tx.text, tx.x, tx.y);
    }
    ctx.globalAlpha = 1;
    ctx.restore();

    // ---- overlays ----
    if (this.mode === "play") {
      this.drawThreats(ctx);
      if (this.showRadar && W > 680) this.drawRadar(ctx);
    }
    ctx.globalCompositeOperation = "lighter";
    const emberCol = m.biome === "surface" ? "#ff9a4d" : BIOME_INFO[m.biome].ember;
    for (const em of this.embers) {
      ctx.globalAlpha = em.a * (m.kind === "dungeon" ? 0.6 : 1);
      ctx.fillStyle = emberCol;
      ctx.beginPath();
      ctx.arc(em.x, em.y, em.s, 0, TAU);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";
    if (!this.vignette) this.vignette = this.makeVignette();
    ctx.drawImage(this.vignette, 0, 0, W, H);

    if (this.mode === "play" && p.hp / p.maxHp <= 0.25) {
      ctx.globalAlpha = 0.22 + Math.sin(this.t * 5) * 0.1;
      const g = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.25, W / 2, H / 2, Math.max(W, H) * 0.7);
      g.addColorStop(0, "rgba(0,0,0,0)");
      g.addColorStop(1, "rgba(180,20,25,0.9)");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, W, H);
      ctx.globalAlpha = 1;
    }
    if (this.hurtFx > 0) {
      ctx.globalAlpha = this.hurtFx * (this.reduceFx ? 0.2 : 0.5);
      ctx.fillStyle = "#e2382f";
      ctx.fillRect(0, 0, W, H);
      ctx.globalAlpha = 1;
    }
    if (p.frenzyOn) {
      ctx.globalAlpha = 0.1 + Math.sin(this.t * 8) * 0.03;
      const g = ctx.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, "#ff6a1f");
      g.addColorStop(1, "#8b3ee8");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, W, H);
      ctx.globalAlpha = 1;
    }
    if (this.flash > 0) {
      ctx.globalAlpha = Math.min(0.7, this.flash) * (this.reduceFx ? 0.22 : 1);
      ctx.fillStyle = p.frenzyOn ? "#ffeeb2" : "#f1ead9";
      ctx.fillRect(0, 0, W, H);
      ctx.globalAlpha = 1;
    }
    if (this.fade > 0) {
      ctx.globalAlpha = this.fade;
      ctx.fillStyle = "#06040c";
      ctx.fillRect(0, 0, W, H);
      ctx.globalAlpha = 1;
    }
  }

  private drawProp(kind: Parameters<typeof getProp>[0], v: number, x: number, y: number) {
    const s = getProp(kind, v);
    this.ctx.drawImage(s.cv, Math.round(x - s.ax), Math.round(y - s.ay));
  }

  /** darkness with carved-out lights: lanterns, braziers, souls, the reaper's eyes */
  private drawLighting(ox: number, oy: number) {
    const m = this.map;
    const amb = m.ambient;
    if (amb <= 0.01) return;
    const { W, H } = this;
    const S = 0.5; // half-res light buffer
    if (!this.lightCv) {
      this.lightCv = document.createElement("canvas");
      this.lightCv.width = Math.ceil(W * S);
      this.lightCv.height = Math.ceil(H * S);
    }
    const lc = this.lightCv;
    const g = lc.getContext("2d")!;
    g.globalCompositeOperation = "source-over";
    g.fillStyle =
      m.biome === "barracks" ? `rgba(10,8,4,${amb})` : m.biome === "sewer" ? `rgba(6,10,8,${amb})` : m.kind === "dungeon" ? `rgba(4,2,12,${amb})` : `rgba(14,8,34,${amb})`;
    g.fillRect(0, 0, lc.width, lc.height);
    g.globalCompositeOperation = "destination-out";
    const p = this.player;
    const cut = (x: number, y: number, r: number, a: number) => {
      const lx = (x + ox) * S;
      const ly = (y + oy) * S;
      const lr = r * S;
      if (lx < -lr || ly < -lr || lx > lc.width + lr || ly > lc.height + lr) return;
      const grd = g.createRadialGradient(lx, ly, 0, lx, ly, lr);
      grd.addColorStop(0, `rgba(0,0,0,${a})`);
      grd.addColorStop(0.45, `rgba(0,0,0,${a * 0.6})`);
      grd.addColorStop(1, "rgba(0,0,0,0)");
      g.fillStyle = grd;
      g.fillRect(lx - lr, ly - lr, lr * 2, lr * 2);
    };
    const flick = 1 + Math.sin(this.t * 9) * 0.04;
    const lanternBoost = this.vault.loadout.trinket === "gravelantern" ? 1.35 : 1;
    cut(p.x, p.y, (p.frenzyOn ? 420 : 300) * flick * lanternBoost, 1);
    for (const l of m.lights) cut(l.x, l.y, l.r * (1 + Math.sin(this.t * 7 + l.x) * 0.06), 0.95);
    for (const s of this.souls) cut(s.x, s.y, s.kind === "pure" ? 60 : 110, 0.8);
    for (const e of this.enemies) cut(e.x, e.y, e.r * 2.2, 0.5);
    for (const b of this.bolts) cut(b.x, b.y, 50, 0.7);
    for (const c of m.chests) if (!c.opened) cut(c.x, c.y - 10, 90, 0.7);
    for (const pt of m.portals) cut(pt.x, pt.y, 180, 0.9);
    // luminous slime & rune floors
    if (m.biome === "sewer") {
      const tx0 = Math.max(0, Math.floor((this.cam.x - W / 2) / TILE));
      const ty0 = Math.max(0, Math.floor((this.cam.y - H / 2) / TILE));
      const tx1 = Math.min(m.w - 1, Math.floor((this.cam.x + W / 2) / TILE));
      const ty1 = Math.min(m.h - 1, Math.floor((this.cam.y + H / 2) / TILE));
      g.fillStyle = "rgba(0,0,0,0.5)";
      for (let ty = ty0; ty <= ty1; ty++)
        for (let tx = tx0; tx <= tx1; tx++) {
          const t = m.tiles[ty * m.w + tx];
          if (t === T.SLIME || t === T.RUNE) g.fillRect((tx * TILE + ox - 6) * S, (ty * TILE + oy - 6) * S, (TILE + 12) * S, (TILE + 12) * S);
        }
    }
    this.ctx.drawImage(lc, 0, 0, W, H);
    // green cast over slime for extra pop
    if (m.biome === "sewer") {
      const ctx = this.ctx;
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      ctx.translate(ox, oy);
      const tx0 = Math.max(0, Math.floor((this.cam.x - W / 2) / TILE));
      const ty0 = Math.max(0, Math.floor((this.cam.y - H / 2) / TILE));
      const tx1 = Math.min(m.w - 1, Math.floor((this.cam.x + W / 2) / TILE));
      const ty1 = Math.min(m.h - 1, Math.floor((this.cam.y + H / 2) / TILE));
      ctx.fillStyle = `rgba(120,200,30,${0.08 + Math.sin(this.t * 2) * 0.03})`;
      for (let ty = ty0; ty <= ty1; ty++)
        for (let tx = tx0; tx <= tx1; tx++) if (m.tiles[ty * m.w + tx] === T.SLIME) ctx.fillRect(tx * TILE, ty * TILE, TILE, TILE);
      ctx.restore();
    }
  }

  private makeVignette() {
    const c = document.createElement("canvas");
    c.width = 160;
    c.height = 160;
    const g = c.getContext("2d")!;
    const grd = g.createRadialGradient(80, 80, 30, 80, 80, 96);
    grd.addColorStop(0, "rgba(0,0,0,0)");
    grd.addColorStop(0.68, "rgba(0,0,0,0.16)");
    grd.addColorStop(1, "rgba(0,0,0,0.66)");
    g.fillStyle = grd;
    g.fillRect(0, 0, 160, 160);
    return c;
  }

  private drawPlayer() {
    const ctx = this.ctx;
    const p = this.player;
    if (this.dead) {
      ctx.save();
      ctx.translate(p.x, p.y);
      this.drawProp("grave", 0, 0, 10);
      ctx.fillStyle = "rgba(205,192,164,0.9)";
      ctx.font = '700 9px "Cinzel", serif';
      ctx.textAlign = "center";
      ctx.fillText("VAEL", 0, -46);
      ctx.globalCompositeOperation = "lighter";
      this.addGlow(0, -14, 40, "#3fe6b8", 0.3);
      ctx.restore();
      return;
    }
    const frenzy = p.frenzyOn;
    const blink = p.invuln > 0 && Math.floor(this.t * 22) % 2 === 0;
    if (p.rageT > 0) {
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      ctx.strokeStyle = "rgba(255,106,31,0.6)";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r + 12 + Math.sin(this.t * 12) * 2, 0, TAU);
      ctx.stroke();
      ctx.restore();
    }
    if (p.shields > 0) {
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      for (let i = 0; i < p.shields; i++) {
        const a = this.t * 1.6 + (i / p.shields) * TAU;
        const rx = p.x + Math.cos(a) * (p.r + 20);
        const ry = p.y + Math.sin(a) * (p.r + 20);
        this.addGlow(rx, ry, 14, "#8ef6da", 0.75);
        ctx.fillStyle = "#c7fff0";
        ctx.beginPath();
        ctx.arc(rx, ry, 3, 0, TAU);
        ctx.fill();
      }
      ctx.restore();
    }
    if (blink) {
      ctx.save();
      ctx.globalAlpha = 0.5;
    }
    const lo = this.vault.loadout;
    drawReaper(ctx, {
      scythe: lo.scythe,
      wings: lo.wings,
      charm: lo.charm,
      trinket: lo.trinket,
      t: this.t,
      x: p.x,
      y: p.y,
      r: p.r,
      aim: p.aim,
      frenzy,
      dashing: p.dashT > 0,
      slash: p.slashing > 0 ? 1 - p.slashing / 0.11 : 0,
      arc: p.arc * this.weapon().arc,
      reach: p.reach,
      vx: p.vx,
      vy: p.vy,
      moving: clamp(Math.hypot(p.vx, p.vy) / 320, 0, 1),
      blink,
    });
    if (blink) ctx.restore();
    if (p.orbit > 0) {
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      for (let i = 0; i < p.orbit; i++) {
        const a = p.orbitAngle + (i / p.orbit) * TAU;
        const bx = p.x + Math.cos(a) * 82;
        const by = p.y + Math.sin(a) * 82;
        this.addGlow(bx, by, 20, "#8ef6da", 0.6);
        ctx.save();
        ctx.translate(bx, by);
        ctx.rotate(a + this.t * 6);
        ctx.strokeStyle = "#e8fff7";
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(0, 0, 11, -0.4, 2.4);
        ctx.stroke();
        ctx.restore();
      }
      ctx.restore();
    }
  }

  private drawRadar(ctx: CanvasRenderingContext2D) {
    const m = this.map;
    const mm = minimapOf(m);
    const size = 132;
    const k = size / Math.max(mm.width, mm.height);
    const w = mm.width * k;
    const h = mm.height * k;
    const x0 = this.W - w - 18;
    const y0 = this.H * 0.5 - h / 2;
    ctx.save();
    ctx.fillStyle = "rgba(6,4,12,0.7)";
    ctx.fillRect(x0 - 6, y0 - 6, w + 12, h + 12);
    ctx.strokeStyle = "rgba(180,108,255,0.45)";
    ctx.lineWidth = 1;
    ctx.strokeRect(x0 - 6, y0 - 6, w + 12, h + 12);
    ctx.globalAlpha = 0.85;
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(mm, x0, y0, w, h);
    ctx.globalAlpha = 1;
    const sx = (wx: number) => x0 + (wx / (m.w * TILE)) * w;
    const sy = (wy: number) => y0 + (wy / (m.h * TILE)) * h;
    // fog: rooms not yet visited stay dim in the crypt
    if (m.kind === "dungeon") {
      ctx.fillStyle = "rgba(6,4,12,0.55)";
      for (const rm of m.rooms) {
        if (rm.cleared || rm === this.room || rm.active) continue;
        ctx.fillRect(sx(rm.x * TILE), sy(rm.y * TILE), rm.w * TILE * (w / (m.w * TILE)), rm.h * TILE * (h / (m.h * TILE)));
      }
    }
    for (const c of m.chests) {
      if (c.opened) continue;
      ctx.fillStyle = c.tier === 2 ? "#ffc94a" : "#ffb060";
      ctx.fillRect(sx(c.x) - 1.5, sy(c.y) - 1.5, 3, 3);
    }
    for (const pt of m.portals) {
      ctx.fillStyle = pt.locked ? "#e2382f" : pt.kind === "crypt" ? "#ff9a4d" : "#b46cff";
      ctx.beginPath();
      ctx.arc(sx(pt.x), sy(pt.y), 3 + Math.sin(this.t * 4) * 0.8, 0, TAU);
      ctx.fill();
    }
    for (const e of this.enemies) {
      const boss = e.kind === "warden";
      ctx.fillStyle = boss ? "#ff5b4d" : e.hue;
      const s = boss ? 5 : 2.2;
      ctx.fillRect(sx(e.x) - s / 2, sy(e.y) - s / 2, s, s);
    }
    const px = sx(this.player.x);
    const py = sy(this.player.y);
    this.addGlow(px, py, 9, "#f1ead9", 0.75);
    ctx.fillStyle = "#ffffff";
    ctx.beginPath();
    ctx.arc(px, py, 2.4, 0, TAU);
    ctx.fill();
    // viewport
    ctx.strokeStyle = "rgba(241,234,217,0.3)";
    ctx.strokeRect(sx(this.cam.x - this.W / 2), sy(this.cam.y - this.H / 2), (this.W / (m.w * TILE)) * w, (this.H / (m.h * TILE)) * h);
    ctx.font = '700 8px "Cinzel", sans-serif';
    ctx.textAlign = "center";
    ctx.fillStyle = "rgba(205,192,164,0.6)";
    const label = m.biome === "barracks" ? "B A R R A C K S" : m.biome === "sewer" ? "S E W E R" : m.kind === "dungeon" ? "C R Y P T" : "A S H V A L E";
    ctx.fillText(m.kind === "dungeon" ? `${label}  ·  ${this.depth}` : label, x0 + w / 2, y0 - 12);
    ctx.restore();
  }

  private drawThreats(ctx: CanvasRenderingContext2D) {
    const { W, H } = this;
    const m = 40;
    let n = 0;
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    for (const e of this.enemies) {
      if (e.born > 0) continue;
      const sx = e.x - this.cam.x + W / 2;
      const sy = e.y - this.cam.y + H / 2;
      if (sx > m && sx < W - m && sy > m && sy < H - m) continue;
      const dangerous = e.kind === "warden" || e.kind === "charger" || e.kind === "revenant";
      if (!dangerous && n > 3) continue;
      const ang = Math.atan2(sy - H / 2, sx - W / 2);
      const px = W / 2 + Math.cos(ang) * (W / 2 - m);
      const py = H / 2 + Math.sin(ang) * (H / 2 - m);
      const boss = e.kind === "warden";
      const charging = e.kind === "charger" && e.state > 0;
      ctx.save();
      ctx.translate(px, py);
      ctx.rotate(ang);
      ctx.globalAlpha = clamp(0.4 + Math.sin(this.t * (charging ? 14 : 7) + e.id) * 0.3, 0.2, 1);
      ctx.fillStyle = boss ? "#ffc94a" : charging ? "#ff5b4d" : e.hue;
      const s = boss ? 13 : charging ? 10 : 7;
      ctx.beginPath();
      ctx.moveTo(s, 0);
      ctx.lineTo(-s * 0.7, -s * 0.62);
      ctx.lineTo(-s * 0.28, 0);
      ctx.lineTo(-s * 0.7, s * 0.62);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
      if (++n > 10) break;
    }
    // objective arrow on the surface: point at the crypt gate
    if (this.map.kind === "overworld") {
      const gate = this.map.portals.find((p) => p.kind === "crypt");
      if (gate) {
        const sx = gate.x - this.cam.x + W / 2;
        const sy = gate.y - this.cam.y + H / 2;
        if (sx < m || sx > W - m || sy < m || sy > H - m) {
          const ang = Math.atan2(sy - H / 2, sx - W / 2);
          const px = W / 2 + Math.cos(ang) * (W / 2 - m - 8);
          const py = H / 2 + Math.sin(ang) * (H / 2 - m - 8);
          ctx.save();
          ctx.translate(px, py);
          ctx.rotate(ang);
          ctx.globalAlpha = 0.75;
          ctx.fillStyle = "#ff9a4d";
          ctx.beginPath();
          ctx.moveTo(12, 0);
          ctx.lineTo(-8, -8);
          ctx.lineTo(-3, 0);
          ctx.lineTo(-8, 8);
          ctx.closePath();
          ctx.fill();
          ctx.rotate(-ang);
          ctx.font = '700 8px "Cinzel", serif';
          ctx.textAlign = "center";
          ctx.fillStyle = "#ffc08a";
          ctx.fillText("GATE", 0, 20);
          ctx.restore();
        }
      }
    }
    ctx.restore();
  }

  private drawEnemy(e: Enemy) {
    const ctx = this.ctx;
    const scale = e.born > 0 ? clamp(1 - e.born / (e.kind === "warden" ? 1.1 : 0.42), 0.05, 1) : 1;
    // shadow
    ctx.fillStyle = "rgba(0,0,0,0.35)";
    ctx.beginPath();
    ctx.ellipse(e.x, e.y + e.r * 0.9, e.r * 0.9 * scale, e.r * 0.34 * scale, 0, 0, TAU);
    ctx.fill();
    ctx.save();
    ctx.translate(e.x, e.y);
    ctx.scale(scale, scale);
    const flash = e.hit > 0;
    const main = flash ? "#ffffff" : e.hue;

    if (e.kind === "warden") {
      ctx.globalCompositeOperation = "lighter";
      this.addGlow(0, 0, e.r * 2.6, "#8d1418", 0.55);
      ctx.globalCompositeOperation = "source-over";
      ctx.strokeStyle = flash ? "#fff" : "rgba(255,91,77,0.85)";
      ctx.lineWidth = 4;
      for (let i = 0; i < 3; i++) {
        ctx.beginPath();
        ctx.arc(0, 0, e.r + 16 + i * 13, e.spin * (i % 2 ? -1 : 1), e.spin * (i % 2 ? -1 : 1) + 1.9);
        ctx.stroke();
      }
      ctx.fillStyle = "#160b1f";
      ctx.beginPath();
      ctx.arc(0, 0, e.r, 0, TAU);
      ctx.fill();
      ctx.strokeStyle = main;
      ctx.lineWidth = 3;
      ctx.stroke();
      ctx.fillStyle = main;
      for (let i = 0; i < 10; i++) {
        ctx.save();
        ctx.rotate(e.spin * 0.5 + (i / 10) * TAU);
        ctx.beginPath();
        ctx.moveTo(e.r - 2, -5);
        ctx.lineTo(e.r + 14, 0);
        ctx.lineTo(e.r - 2, 5);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
      }
      ctx.globalCompositeOperation = "lighter";
      this.addGlow(0, 0, 40, "#ffc94a", 0.8);
      ctx.globalCompositeOperation = "source-over";
      ctx.fillStyle = "#fff1d0";
      ctx.beginPath();
      ctx.ellipse(Math.cos(e.face) * 6, Math.sin(e.face) * 6, 9, 5, e.face, 0, TAU);
      ctx.fill();
      if (e.telegraph > 0 && e.state !== 0) {
        ctx.globalAlpha = clamp(e.telegraph, 0, 1) * 0.6;
        ctx.strokeStyle = "#ff5b4d";
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(0, 0, e.r + 34, 0, TAU);
        ctx.stroke();
        ctx.globalAlpha = 1;
      }
    } else {
      ctx.globalCompositeOperation = "lighter";
      this.addGlow(0, 0, e.r * 2.5, e.hue, 0.28 + (e.telegraph > 0 && e.state ? e.telegraph * 0.5 : 0));
      ctx.globalCompositeOperation = "source-over";
      ctx.fillStyle = flash ? "#ffffff" : "#100a1c";
      ctx.strokeStyle = main;
      ctx.lineWidth = 2.4;
      if (e.kind === "wisp") {
        ctx.beginPath();
        ctx.moveTo(e.r * 1.5, 0);
        ctx.lineTo(0, -e.r);
        ctx.lineTo(-e.r * 1.1, 0);
        ctx.lineTo(0, e.r);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
      } else if (e.kind === "stalker") {
        ctx.beginPath();
        for (let i = 0; i < 6; i++) {
          const a = e.spin * 0.35 + (i / 6) * TAU;
          i ? ctx.lineTo(Math.cos(a) * e.r, Math.sin(a) * e.r) : ctx.moveTo(Math.cos(a) * e.r, Math.sin(a) * e.r);
        }
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
      } else if (e.kind === "revenant") {
        ctx.beginPath();
        ctx.ellipse(0, 0, e.r * 0.72, e.r * 1.22, 0, 0, TAU);
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = main;
        for (let i = 0; i < 3; i++) {
          const a = e.spin * 1.6 + (i / 3) * TAU;
          ctx.beginPath();
          ctx.arc(Math.cos(a) * (e.r + 9), Math.sin(a) * (e.r + 9), 3, 0, TAU);
          ctx.fill();
        }
      } else if (e.kind === "charger") {
        ctx.rotate(e.face);
        ctx.beginPath();
        ctx.moveTo(e.r * 1.3, 0);
        ctx.lineTo(-e.r * 0.8, -e.r);
        ctx.lineTo(-e.r * 0.25, 0);
        ctx.lineTo(-e.r * 0.8, e.r);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
        if (e.state === 1 && e.telegraph > 0) {
          ctx.globalCompositeOperation = "lighter";
          ctx.globalAlpha = clamp(1 - e.telegraph / 0.72, 0, 1) * 0.75;
          ctx.strokeStyle = "#ff5b4d";
          ctx.lineWidth = 4 + (1 - e.telegraph / 0.72) * 8;
          ctx.setLineDash([16, 12]);
          ctx.beginPath();
          ctx.moveTo(e.r, 0);
          ctx.lineTo(720, 0);
          ctx.stroke();
          ctx.setLineDash([]);
          ctx.globalAlpha = 1;
          ctx.globalCompositeOperation = "source-over";
        }
      } else {
        ctx.beginPath();
        ctx.moveTo(0, -e.r * 1.15);
        ctx.quadraticCurveTo(e.r, -e.r * 0.2, e.r * 0.72, e.r * 1.1);
        ctx.quadraticCurveTo(0, e.r * 0.62, -e.r * 0.72, e.r * 1.1);
        ctx.quadraticCurveTo(-e.r, -e.r * 0.2, 0, -e.r * 1.15);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
      }
      if (e.kind !== "charger") {
        const ex = Math.cos(e.face) * e.r * 0.28;
        const ey = Math.sin(e.face) * e.r * 0.28;
        ctx.fillStyle = "#ffe9c9";
        const eo = e.r * 0.28;
        const es = Math.max(1.4, e.r * 0.12);
        ctx.beginPath();
        ctx.arc(ex + Math.cos(e.face + Math.PI / 2) * eo, ey + Math.sin(e.face + Math.PI / 2) * eo, es, 0, TAU);
        ctx.arc(ex + Math.cos(e.face - Math.PI / 2) * eo, ey + Math.sin(e.face - Math.PI / 2) * eo, es, 0, TAU);
        ctx.fill();
      }
    }
    if (e.hp < e.maxHp && e.kind !== "warden") {
      const bw = e.r * 2.2;
      ctx.fillStyle = "rgba(6,4,12,0.75)";
      ctx.fillRect(-bw / 2, -e.r - 13, bw, 4);
      ctx.fillStyle = main;
      ctx.fillRect(-bw / 2, -e.r - 13, bw * clamp(e.hp / e.maxHp, 0, 1), 4);
    }
    ctx.restore();
  }
}
