/* ==============================================================
   SKILLS — three active arts bound to Q / F / C.
   Each has its own telegraph, impact and afterimage. This module
   holds the definitions and the canvas renderers; the engine owns
   cooldowns and applies damage.
   ============================================================== */
import type { Enemy } from "./types";

const TAU = Math.PI * 2;

export type SkillId = "cyclone" | "lance" | "slam";

export interface SkillDef {
  id: SkillId;
  key: string;
  name: string;
  blurb: string;
  cd: number;
  dur: number;
  color: string;
}

export const SKILLS: SkillDef[] = [
  {
    id: "cyclone",
    key: "Q",
    name: "Spectral Cyclone",
    blurb: "Spin the scythe through a full storm. Everything inside the ring is cut again and again.",
    cd: 5.5,
    dur: 0.6,
    color: "#8ef6da",
  },
  {
    id: "lance",
    key: "F",
    name: "Shadow Lance",
    blurb: "Lunge down your aim line. The beam pierces every foe along its length.",
    cd: 4.2,
    dur: 0.34,
    color: "#ff6b7d",
  },
  {
    id: "slam",
    key: "C",
    name: "Grave Slam",
    blurb: "Gather soul-light, then crash down. Cracks the floor, flings foes and stuns them.",
    cd: 7.5,
    dur: 1.05,
    color: "#ffc94a",
  },
];

export const SLAM_WINDUP = 0.26;

export interface SkillFx {
  id: SkillId;
  x: number;
  y: number;
  a: number;
  t: number;
  dur: number;
  r: number;
  color: string;
  seed: number;
  hits: Map<number, number>;
  hit: boolean;
  cracks: number[][];
}

function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** jagged radial crack lines for the slam impact, stored as flat [x0,y0,x1,y1,...] offsets */
export function makeCracks(seed: number, R: number): number[][] {
  const rnd = rng(seed);
  const out: number[][] = [];
  for (let i = 0; i < 9; i++) {
    let ang = (i / 9) * TAU + rnd() * 0.45;
    const len = R * (0.42 + rnd() * 0.5);
    const steps = 5;
    const pts: number[] = [];
    for (let k = 1; k <= steps; k++) {
      ang += (rnd() - 0.5) * 0.42;
      const d = (len * k) / steps;
      pts.push(Math.cos(ang) * d, Math.sin(ang) * d);
    }
    out.push(pts);
  }
  return out;
}

const ease = (x: number) => {
  const c = x < 0 ? 0 : x > 1 ? 1 : x;
  return 1 - (1 - c) ** 3;
};

function rgba(hex: string, a: number) {
  const n = parseInt(hex.slice(1), 16);
  const r = (n >> 16) & 255;
  const g = (n >> 8) & 255;
  const b = n & 255;
  return `rgba(${r},${g},${b},${Math.max(0, Math.min(1, a))})`;
}

/* ---------------- renderers (world space) ---------------- */

export function drawSkillFx(ctx: CanvasRenderingContext2D, fxs: SkillFx[], enemies: Enemy[], t: number) {
  ctx.save();
  ctx.lineCap = "round";
  for (const fx of fxs) {
    ctx.globalCompositeOperation = "lighter";
    if (fx.id === "cyclone") drawCyclone(ctx, fx);
    else if (fx.id === "lance") drawLance(ctx, fx);
    else drawSlam(ctx, fx);
  }
  // stunned foes wear a ring of orbiting motes
  ctx.globalCompositeOperation = "lighter";
  for (const e of enemies) {
    if (!e.stun || e.stun <= 0) continue;
    for (let i = 0; i < 3; i++) {
      const a = t * 5 + i * 2.094;
      const x = e.x + Math.cos(a) * (e.r + 8);
      const y = e.y - e.r - 6 + Math.sin(a) * 3.5;
      ctx.fillStyle = i % 2 ? "#ffe9a0" : "#8ef6da";
      ctx.globalAlpha = 0.9;
      ctx.beginPath();
      ctx.arc(x, y, 2.4, 0, TAU);
      ctx.fill();
    }
  }
  ctx.globalAlpha = 1;
  ctx.restore();
}

/* Spectral Cyclone: a widening vortex with three rotating blade-arcs and rising embers */
function drawCyclone(ctx: CanvasRenderingContext2D, fx: SkillFx) {
  const k = fx.t / fx.dur;
  const alpha = Math.max(0, 1 - k * k);
  const R = fx.r * (0.3 + 0.7 * ease(fx.t / 0.16));

  const floor = ctx.createRadialGradient(fx.x, fx.y, 0, fx.x, fx.y, R);
  floor.addColorStop(0, rgba(fx.color, 0));
  floor.addColorStop(0.75, rgba(fx.color, 0.18 * alpha));
  floor.addColorStop(1, rgba(fx.color, 0));
  ctx.fillStyle = floor;
  ctx.beginPath();
  ctx.arc(fx.x, fx.y, R, 0, TAU);
  ctx.fill();

  ctx.strokeStyle = rgba(fx.color, 0.55 * alpha);
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.arc(fx.x, fx.y, R, 0, TAU);
  ctx.stroke();

  const br = R * 0.9;
  for (let i = 0; i < 3; i++) {
    const a0 = fx.a + (i * TAU) / 3;
    // fading afterimage arcs trail each blade
    for (let j = 0; j < 4; j++) {
      const s = a0 - j * 0.2;
      ctx.strokeStyle = rgba(fx.color, (0.55 - j * 0.12) * alpha);
      ctx.lineWidth = 13 - j * 2.8;
      ctx.beginPath();
      ctx.arc(fx.x, fx.y, br, s - 0.42, s + 0.08);
      ctx.stroke();
    }
    // white-hot leading edge
    ctx.strokeStyle = rgba("#ffffff", 0.9 * alpha);
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.arc(fx.x, fx.y, br, a0 - 0.42, a0 + 0.08);
    ctx.stroke();
    // tip flare
    const tx = fx.x + Math.cos(a0 + 0.08) * br;
    const ty = fx.y + Math.sin(a0 + 0.08) * br;
    const tg = ctx.createRadialGradient(tx, ty, 0, tx, ty, 14);
    tg.addColorStop(0, rgba("#ffffff", alpha));
    tg.addColorStop(1, rgba(fx.color, 0));
    ctx.fillStyle = tg;
    ctx.beginPath();
    ctx.arc(tx, ty, 14, 0, TAU);
    ctx.fill();
  }
  // embers spiralling up through the storm
  for (let s = 0; s < 8; s++) {
    const q = (s * 0.137 + fx.t * 1.9) % 1;
    const a = fx.a * 1.6 + s * 0.785;
    const rr = R * (0.2 + 0.8 * (1 - q));
    ctx.fillStyle = rgba(fx.color, (1 - q) * alpha);
    ctx.beginPath();
    ctx.arc(fx.x + Math.cos(a) * rr, fx.y + Math.sin(a) * rr, 1.8 + (1 - q) * 1.6, 0, TAU);
    ctx.fill();
  }
}

/* Shadow Lance: a beam that snaps out along the aim, with streaks, a tip flare and an impact ring */
function drawLance(ctx: CanvasRenderingContext2D, fx: SkillFx) {
  const L = fx.r;
  const k = Math.min(1, fx.t / 0.07);
  const fade = Math.max(0, 1 - Math.max(0, fx.t - 0.07) / Math.max(0.01, fx.dur - 0.07));
  const c = Math.cos(fx.a);
  const s = Math.sin(fx.a);
  const ex = fx.x + c * L * k;
  const ey = fx.y + s * L * k;

  const beam = (w: number, col: string) => {
    ctx.strokeStyle = col;
    ctx.lineWidth = w;
    ctx.beginPath();
    ctx.moveTo(fx.x, fx.y);
    ctx.lineTo(ex, ey);
    ctx.stroke();
  };
  beam(44, rgba(fx.color, 0.3 * fade));
  beam(16, rgba(fx.color, 0.8 * fade));
  beam(4, rgba("#ffffff", fade));

  ctx.lineWidth = 1.5;
  for (const off of [-20, -8, 8, 20]) {
    const px = -s * off;
    const py = c * off;
    ctx.strokeStyle = rgba(fx.color, 0.45 * fade);
    ctx.beginPath();
    ctx.moveTo(fx.x + px + c * 12, fx.y + py + s * 12);
    ctx.lineTo(fx.x + px + c * L * k * 0.82, fx.y + py + s * L * k * 0.82);
    ctx.stroke();
  }

  const g = ctx.createRadialGradient(ex, ey, 0, ex, ey, 56);
  g.addColorStop(0, rgba("#ffffff", 0.95 * fade));
  g.addColorStop(0.3, rgba(fx.color, 0.6 * fade));
  g.addColorStop(1, rgba(fx.color, 0));
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(ex, ey, 56, 0, TAU);
  ctx.fill();

  if (fx.t > 0.07 && fx.t < 0.32) {
    const q = (fx.t - 0.07) / 0.25;
    ctx.strokeStyle = rgba(fx.color, (1 - q) * 0.85);
    ctx.lineWidth = 4 * (1 - q) + 1;
    ctx.beginPath();
    ctx.arc(ex, ey, 10 + q * 70, 0, TAU);
    ctx.stroke();
  }
}

/* Grave Slam: runes spiral inward during the windup, then the floor cracks and shockwaves roll out */
function drawSlam(ctx: CanvasRenderingContext2D, fx: SkillFx) {
  if (fx.t < SLAM_WINDUP) {
    const w = fx.t / SLAM_WINDUP;
    const g = ctx.createRadialGradient(fx.x, fx.y, 0, fx.x, fx.y, 74);
    g.addColorStop(0, rgba("#ffffff", 0.35 * w));
    g.addColorStop(0.5, rgba(fx.color, 0.35 * w));
    g.addColorStop(1, rgba(fx.color, 0));
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(fx.x, fx.y, 74, 0, TAU);
    ctx.fill();

    ctx.strokeStyle = rgba(fx.color, 0.5 + 0.4 * w);
    ctx.lineWidth = 2;
    ctx.setLineDash([8, 8]);
    ctx.lineDashOffset = -fx.t * 120;
    ctx.beginPath();
    ctx.arc(fx.x, fx.y, fx.r * (1 - 0.3 * w), 0, TAU);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.lineDashOffset = 0;

    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * TAU + fx.t * (3 + 4 * w);
      const rr = 110 * (1 - w) + 22;
      const x = fx.x + Math.cos(a) * rr;
      const y = fx.y + Math.sin(a) * rr;
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(a + Math.PI / 4);
      ctx.fillStyle = rgba(fx.color, 0.4 + 0.6 * w);
      ctx.fillRect(-4, -4, 8, 8);
      ctx.restore();
    }
    return;
  }

  const s = fx.t - SLAM_WINDUP;
  const life = Math.max(0.01, fx.dur - SLAM_WINDUP);
  const k = Math.min(1, s / life);

  if (s < 0.22) {
    const f = 1 - s / 0.22;
    const g = ctx.createRadialGradient(fx.x, fx.y, 0, fx.x, fx.y, fx.r * 0.8);
    g.addColorStop(0, rgba("#ffffff", 0.7 * f));
    g.addColorStop(0.4, rgba(fx.color, 0.45 * f));
    g.addColorStop(1, rgba(fx.color, 0));
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(fx.x, fx.y, fx.r * 0.8, 0, TAU);
    ctx.fill();
  }

  // cracks: dark pass first (needs source-over to actually darken), then a glowing edge
  const grow = ease(s / 0.2);
  ctx.globalCompositeOperation = "source-over";
  ctx.strokeStyle = `rgba(12,6,18,${0.8 * (1 - k)})`;
  ctx.lineWidth = 4.5;
  for (const c of fx.cracks) {
    const n = c.length / 2;
    const upto = Math.max(1, Math.floor(n * grow));
    ctx.beginPath();
    ctx.moveTo(fx.x, fx.y);
    for (let j = 0; j < upto; j++) ctx.lineTo(fx.x + c[j * 2], fx.y + c[j * 2 + 1]);
    ctx.stroke();
  }
  ctx.globalCompositeOperation = "lighter";
  ctx.strokeStyle = rgba(fx.color, 0.9 * (1 - k));
  ctx.lineWidth = 1.6;
  for (const c of fx.cracks) {
    const n = c.length / 2;
    const upto = Math.max(1, Math.floor(n * grow));
    ctx.beginPath();
    ctx.moveTo(fx.x, fx.y);
    for (let j = 0; j < upto; j++) ctx.lineTo(fx.x + c[j * 2], fx.y + c[j * 2 + 1]);
    ctx.stroke();
  }

  // two staggered shockwaves
  const rings: [number, number][] = [
    [0, 10],
    [0.1, 5],
  ];
  for (const [delay, w] of rings) {
    const q = Math.min(1, Math.max(0, (s - delay) / 0.42));
    if (q <= 0) continue;
    ctx.strokeStyle = rgba(fx.color, (1 - q) * 0.9);
    ctx.lineWidth = w * (1 - q) + 1;
    ctx.beginPath();
    ctx.arc(fx.x, fx.y, fx.r * ease(q), 0, TAU);
    ctx.stroke();
  }
}
