import type { Player, Tier, UpgradeCard } from "./types";

interface Def {
  id: string;
  name: string;
  blurb: string;
  icon: UpgradeCard["icon"];
  tier: Tier;
  max: number;
  apply: (p: Player) => void;
}

const TIER_WEIGHT: Record<Tier, number> = {
  Common: 100,
  Rare: 52,
  Epic: 26,
  Forbidden: 11,
};

export const UPGRADE_POOL: Def[] = [
  {
    id: "arc",
    name: "Reaver's Arc",
    blurb: "+16% reap reach and a wider sweep. Mow down tighter packs.",
    icon: "arc",
    tier: "Common",
    max: 6,
    apply: (p) => {
      p.reach *= 1.16;
      p.arc = Math.min(2.3, p.arc * 1.09);
    },
  },
  {
    id: "cleave",
    name: "Grave Cleave",
    blurb: "+24% reap damage on every swing.",
    icon: "blade",
    tier: "Common",
    max: 8,
    apply: (p) => {
      p.dmgMult *= 1.24;
    },
  },
  {
    id: "haste",
    name: "Cinder Rhythm",
    blurb: "-14% cooldown between reaps. Swing faster, harvest more.",
    icon: "hourglass",
    tier: "Common",
    max: 5,
    apply: (p) => {
      p.slashCd *= 0.86;
    },
  },
  {
    id: "magnet",
    name: "Astral Lodestone",
    blurb: "+70 soul pull range. Spirits fly to you.",
    icon: "magnet",
    tier: "Common",
    max: 6,
    apply: (p) => {
      p.magnet += 70;
    },
  },
  {
    id: "stride",
    name: "Wraithstride",
    blurb: "+12% movement speed. Dance between the damned.",
    icon: "wind",
    tier: "Common",
    max: 6,
    apply: (p) => {
      p.speedMult *= 1.12;
    },
  },
  {
    id: "crit",
    name: "Soulsplit Edge",
    blurb: "+9% critical chance — crits deal 2.4x damage.",
    icon: "sparkle",
    tier: "Rare",
    max: 6,
    apply: (p) => {
      p.crit += 0.09;
    },
  },
  {
    id: "dash",
    name: "Twin Shadows",
    blurb: "+1 dash charge and -18% dash recovery.",
    icon: "ghost",
    tier: "Rare",
    max: 4,
    apply: (p) => {
      p.maxDash += 1;
      p.dashCharges = Math.min(p.maxDash, p.dashCharges + 1);
      p.dashCdMax *= 0.82;
    },
  },
  {
    id: "vital",
    name: "Eldritch Vigour",
    blurb: "+1 max heart and fully restore your health.",
    icon: "heart",
    tier: "Rare",
    max: 5,
    apply: (p) => {
      p.maxHp += 1;
      p.hp = p.maxHp;
    },
  },
  {
    id: "siphon",
    name: "Reaper's Siphon",
    blurb: "9% chance per harvest to drain +1 heart.",
    icon: "thorn",
    tier: "Rare",
    max: 4,
    apply: (p) => {
      p.lifesteal += 0.09;
    },
  },
  {
    id: "frenzy",
    name: "Hollow Hourglass",
    blurb: "Soul Frenzy lasts +3.2s and fills 20% faster.",
    icon: "bolt",
    tier: "Rare",
    max: 4,
    apply: (p) => {
      p.frenzyMult += 0.34;
    },
  },
  {
    id: "fortune",
    name: "Grim Fortune",
    blurb: "+30% luck: rarer boons, more golden souls, +12% score value.",
    icon: "coin",
    tier: "Rare",
    max: 5,
    apply: (p) => {
      p.luck += 0.3;
      p.greed *= 1.12;
    },
  },
  {
    id: "orbit",
    name: "Halo of Scythes",
    blurb: "A spectral blade orbits you, shredding anything close.",
    icon: "ring",
    tier: "Epic",
    max: 4,
    apply: (p) => {
      p.orbit += 1;
      p.orbitDmg += 16;
    },
  },
  {
    id: "aura",
    name: "Necrotic Void",
    blurb: "Radiate decay: slows nearby phantoms and rots their health.",
    icon: "void",
    tier: "Epic",
    max: 4,
    apply: (p) => {
      p.aura = p.aura === 0 ? 108 : p.aura + 34;
    },
  },
  {
    id: "echo",
    name: "Echo Slash",
    blurb: "45% chance a reap repeats itself a heartbeat later.",
    icon: "echo",
    tier: "Epic",
    max: 4,
    apply: (p) => {
      p.echo += 0.45;
    },
  },
  {
    id: "shock",
    name: "Rending Shockwave",
    blurb: "Every reap fires a shockwave ring that ruptures a line of foes.",
    icon: "shock",
    tier: "Epic",
    max: 3,
    apply: (p) => {
      p.shock += 1;
    },
  },
  {
    id: "trail",
    name: "Pyre Trail",
    blurb: "Dashing leaves burning embers that scorch everything they touch.",
    icon: "flame",
    tier: "Epic",
    max: 1,
    apply: (p) => {
      p.dashTrail = true;
    },
  },
  {
    id: "chrono",
    name: "Chrono Veil",
    blurb: "Time thickens around you — phantoms within 190px move 32% slower.",
    icon: "hourglass",
    tier: "Epic",
    max: 2,
    apply: (p) => {
      p.slowField = p.slowField === 0 ? 190 : p.slowField + 60;
    },
  },
  {
    id: "scholar",
    name: "Grave Scholar",
    blurb: "+30% essence gained from every soul. Level up faster.",
    icon: "book",
    tier: "Epic",
    max: 4,
    apply: (p) => {
      p.xpMult *= 1.3;
    },
  },
  {
    id: "split",
    name: "Fission Rite",
    blurb: "Slain phantoms release +1 soul. Double the harvest, double the fun.",
    icon: "skull",
    tier: "Forbidden",
    max: 3,
    apply: (p) => {
      p.soulGain += 1;
    },
  },
  {
    id: "execute",
    name: "Executioner's Pact",
    blurb: "Wounded foes (under 35% hp) take +130% damage. Finish them.",
    icon: "blade",
    tier: "Forbidden",
    max: 2,
    apply: (p) => {
      p.execute += 1.3;
    },
  },
  {
    id: "ward",
    name: "Bone Ward",
    blurb: "A warding sigil absorbs the next hit. Stacks up to 3.",
    icon: "shield",
    tier: "Forbidden",
    max: 3,
    apply: (p) => {
      p.maxHp += 0;
      p.shields = Math.min(3, p.shields + 1);
    },
  },
];

export function rollUpgrades(p: Player, count = 3): UpgradeCard[] {
  const pool = UPGRADE_POOL.filter((d) => (p.stacked[d.id] ?? 0) < d.max);
  const picked: Def[] = [];
  const bag = [...pool];

  // Luck nudges the roll toward higher tiers
  const luckBias = Math.max(0, p.luck - 1);

  while (picked.length < count && bag.length) {
    const weights = bag.map((d) => {
      const tierBoost =
        d.tier === "Forbidden" ? 1 + luckBias * 1.5 : d.tier === "Epic" ? 1 + luckBias : 1;
      return TIER_WEIGHT[d.tier] * tierBoost * (1 + (p.stacked[d.id] ?? 0) * 0.12);
    });
    const total = weights.reduce((a, b) => a + b, 0);
    let roll = Math.random() * total;
    let idx = 0;
    for (let i = 0; i < weights.length; i++) {
      roll -= weights[i];
      if (roll <= 0) {
        idx = i;
        break;
      }
    }
    picked.push(bag[idx]);
    bag.splice(idx, 1);
  }

  return picked.map((d) => ({
    id: d.id,
    name: d.name,
    blurb: d.blurb,
    icon: d.icon,
    tier: d.tier,
    max: d.max,
    apply: d.apply,
  }));
}

export const TIER_STYLE: Record<Tier, { ring: string; text: string; glow: string; bar: string }> = {
  Common: {
    ring: "border-bone-700/60",
    text: "text-bone-300",
    glow: "shadow-[0_0_0px_rgba(0,0,0,0)]",
    bar: "from-bone-700 to-bone-500",
  },
  Rare: {
    ring: "border-spectral-500/50",
    text: "text-spectral-300",
    glow: "shadow-[0_0_22px_-6px_rgba(63,230,184,0.7)]",
    bar: "from-spectral-700 to-spectral-300",
  },
  Epic: {
    ring: "border-hex-400/55",
    text: "text-hex-300",
    glow: "shadow-[0_0_26px_-6px_rgba(180,108,255,0.75)]",
    bar: "from-hex-700 to-hex-300",
  },
  Forbidden: {
    ring: "border-gold-400/70",
    text: "text-gold-300",
    glow: "shadow-[0_0_34px_-6px_rgba(255,201,74,0.85)]",
    bar: "from-ember-700 via-gold-400 to-gold-200",
  },
};
