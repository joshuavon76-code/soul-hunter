/* ==========================================================
   Procedural audio — Web Audio API synth. No assets, no net.
   ========================================================== */

type Ctx = AudioContext;

class AudioEngine {
  private ctx: Ctx | null = null;
  private master: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private noise: AudioBuffer | null = null;

  muted = false;
  musicOn = false;
  private timer: number | null = null;
  private step = 0;
  private nextTime = 0;
  private intensity = 0; // 0 calm → 1 frenzy

  private ensure(): Ctx | null {
    if (!this.ctx) {
      const AC: typeof AudioContext | undefined =
        window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AC) return null;
      const ctx = new AC();
      const master = ctx.createGain();
      master.gain.value = this.muted ? 0 : 0.85;
      const comp = ctx.createDynamicsCompressor();
      comp.threshold.value = -14;
      comp.knee.value = 22;
      comp.ratio.value = 5;
      comp.attack.value = 0.004;
      comp.release.value = 0.16;
      master.connect(comp);
      comp.connect(ctx.destination);

      this.musicGain = ctx.createGain();
      this.musicGain.gain.value = 0.55;
      this.musicGain.connect(master);

      this.sfxGain = ctx.createGain();
      this.sfxGain.gain.value = 1;
      this.sfxGain.connect(master);

      const len = Math.floor(ctx.sampleRate * 0.7);
      const buf = ctx.createBuffer(1, len, ctx.sampleRate);
      const d = buf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      this.noise = buf;

      this.ctx = ctx;
      this.master = master;
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
    return this.ctx;
  }

  unlock() {
    this.ensure();
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(m ? 0 : 0.85, this.ctx.currentTime, 0.02);
    }
  }

  setIntensity(v: number) {
    this.intensity = Math.max(0, Math.min(1, v));
  }

  /* ---------- primitives ---------- */
  private tone(
    type: OscillatorType,
    f0: number,
    f1: number,
    dur: number,
    vol: number,
    dest?: AudioNode,
    delay = 0,
    detune = 0
  ) {
    const ctx = this.ensure();
    if (!ctx || this.muted) return;
    const t = ctx.currentTime + delay;
    const o = ctx.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(Math.max(20, f0), t);
    if (f1 !== f0) o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    if (detune) o.detune.value = detune;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + Math.min(0.02, dur * 0.25));
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g);
    g.connect(dest ?? this.sfxGain!);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  private hiss(dur: number, vol: number, hp: number, bpTo?: number, delay = 0) {
    const ctx = this.ensure();
    if (!ctx || this.muted || !this.noise) return;
    const t = ctx.currentTime + delay;
    const src = ctx.createBufferSource();
    src.buffer = this.noise;
    const f = ctx.createBiquadFilter();
    f.type = bpTo ? "bandpass" : "highpass";
    f.Q.value = bpTo ? 1.4 : 0.8;
    f.frequency.setValueAtTime(hp, t);
    if (bpTo) f.frequency.exponentialRampToValueAtTime(Math.max(80, bpTo), t + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f);
    f.connect(g);
    g.connect(this.sfxGain!);
    src.start(t);
    src.stop(t + dur + 0.02);
  }

  /* ---------- SFX ---------- */
  slash() {
    this.tone("triangle", 420, 1500, 0.13, 0.1);
    this.tone("sawtooth", 210, 90, 0.1, 0.045);
    this.hiss(0.13, 0.075, 2600, undefined);
  }
  hit() {
    this.tone("square", 190, 52, 0.16, 0.1);
    this.hiss(0.09, 0.06, 700, 220);
  }
  kill() {
    this.tone("sawtooth", 300, 40, 0.26, 0.085);
    this.tone("sine", 720, 180, 0.2, 0.06, undefined, 0.02);
  }
  soul(gold: boolean, frenzy: boolean) {
    const base = gold ? 660 : frenzy ? 588 : 494;
    this.tone("sine", base, base * 1.5, 0.11, frenzy ? 0.085 : 0.06);
    this.tone("sine", base * 1.5, base * 2.25, 0.13, 0.045, undefined, 0.05);
    if (gold) this.tone("triangle", base * 2, base * 3, 0.2, 0.035, undefined, 0.09);
  }
  graze() {
    this.tone("sine", 1500, 2400, 0.07, 0.05);
    this.hiss(0.06, 0.03, 5000);
  }
  dash() {
    this.hiss(0.2, 0.1, 480, 3200);
    this.tone("triangle", 150, 620, 0.16, 0.055);
  }
  bolt() {
    this.tone("sawtooth", 900, 220, 0.13, 0.035);
  }
  hurt() {
    this.tone("square", 130, 44, 0.32, 0.15);
    this.hiss(0.22, 0.11, 240, 90);
    this.tone("sawtooth", 62, 30, 0.4, 0.1);
  }
  shieldBreak() {
    this.tone("square", 1200, 300, 0.16, 0.07);
    this.hiss(0.16, 0.07, 3000, 800);
  }
  nova() {
    this.tone("sine", 90, 1400, 0.5, 0.13);
    this.hiss(0.5, 0.1, 300, 4000);
  }
  levelUp() {
    [523.25, 659.25, 783.99, 1046.5, 1318.5].forEach((f, i) => {
      this.tone("triangle", f, f * 1.01, 0.42, 0.075, undefined, i * 0.075);
      this.tone("sine", f * 2, f * 2, 0.3, 0.028, undefined, i * 0.075);
    });
  }
  pick() {
    this.tone("sine", 880, 1320, 0.16, 0.07);
    this.tone("triangle", 440, 660, 0.2, 0.04, undefined, 0.03);
  }
  frenzyStart() {
    this.tone("sawtooth", 110, 660, 0.45, 0.11);
    this.tone("square", 220, 1320, 0.4, 0.055, undefined, 0.04);
    this.hiss(0.5, 0.09, 500, 6000);
  }
  frenzyEnd() {
    this.tone("sawtooth", 520, 90, 0.4, 0.07);
  }
  wave(n: number) {
    const f = 180 + Math.min(n, 10) * 12;
    this.tone("square", f, f * 1.5, 0.22, 0.05);
    this.tone("square", f * 1.5, f * 2, 0.3, 0.04, undefined, 0.12);
  }
  bossRoar() {
    const ctx = this.ensure();
    if (!ctx || this.muted) return;
    this.tone("sawtooth", 150, 40, 1.1, 0.16);
    this.tone("square", 76, 30, 1.3, 0.1, undefined, 0.05);
    this.hiss(1.0, 0.09, 160, 60);
  }
  gameOver() {
    [392, 349.23, 293.66, 220, 146.83].forEach((f, i) => {
      this.tone("square", f, f * 0.98, 0.45, 0.085, undefined, i * 0.16);
      this.tone("sine", f / 2, f / 2, 0.5, 0.06, undefined, i * 0.16);
    });
  }
  ui() {
    this.tone("square", 520, 660, 0.05, 0.045);
  }
  record() {
    [659.25, 830.6, 987.77, 1318.5].forEach((f, i) =>
      this.tone("triangle", f, f, 0.3, 0.07, undefined, i * 0.08)
    );
  }

  /* ---------- skill cues ---------- */
  cyclone() {
    this.hiss(0.55, 0.11, 500, 3600);
    this.tone("triangle", 220, 760, 0.45, 0.07);
    this.tone("sawtooth", 140, 320, 0.4, 0.035, undefined, 0.05);
  }
  lance() {
    this.tone("sawtooth", 1400, 260, 0.2, 0.09);
    this.hiss(0.16, 0.08, 4200);
    this.tone("square", 2200, 900, 0.12, 0.025, undefined, 0.02);
  }
  slamCharge() {
    this.tone("sine", 60, 150, 0.3, 0.09);
  }
  slam() {
    this.tone("sine", 110, 28, 0.6, 0.2);
    this.tone("square", 70, 32, 0.45, 0.07);
    this.hiss(0.4, 0.13, 320, 80);
  }

  /* ---------- Music: lookahead sequencer ---------- */
  startMusic() {
    const ctx = this.ensure();
    if (!ctx || this.musicOn) return;
    this.musicOn = true;
    this.step = 0;
    this.nextTime = ctx.currentTime + 0.06;
    const tick = () => {
      const c = this.ctx;
      if (!c || !this.musicOn) return;
      while (this.nextTime < c.currentTime + 0.22) {
        this.schedule(this.step, this.nextTime);
        const bpm = 108 + this.intensity * 30;
        this.nextTime += 60 / bpm / 2;
        this.step = (this.step + 1) % 32;
      }
      this.timer = window.setTimeout(tick, 40);
    };
    tick();
  }

  stopMusic() {
    this.musicOn = false;
    if (this.timer !== null) {
      clearTimeout(this.timer);
      this.timer = null;
    }
  }

  private mnote(semi: number) {
    return 55 * Math.pow(2, semi / 12);
  }

  private schedule(step: number, t: number) {
    const ctx = this.ctx;
    if (!ctx || this.muted || !this.musicGain) return;
    const delay = Math.max(0, t - ctx.currentTime);
    const hot = this.intensity > 0.5;
    const root = hot ? 0 : 0;

    // Kick: 4-on-the-floor at high intensity, sparser otherwise
    if (step % 4 === 0 || (hot && step % 2 === 0)) {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = "sine";
      o.frequency.setValueAtTime(140, t);
      o.frequency.exponentialRampToValueAtTime(42, t + 0.11);
      g.gain.setValueAtTime(0.34, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.14);
      o.connect(g);
      g.connect(this.musicGain);
      o.start(t);
      o.stop(t + 0.16);
    }

    // Bass riff (phrygian-ish dread)
    const bassPat = [0, 0, 12, 0, 3, 0, 8, 1];
    const b = bassPat[step % 8] + root;
    const bo = ctx.createOscillator();
    const bg = ctx.createGain();
    const bf = ctx.createBiquadFilter();
    bo.type = hot ? "sawtooth" : "triangle";
    bo.frequency.setValueAtTime(this.mnote(b), t);
    bf.type = "lowpass";
    bf.frequency.setValueAtTime(hot ? 900 : 340, t);
    bf.frequency.exponentialRampToValueAtTime(140, t + 0.18);
    bg.gain.setValueAtTime(0.0001, t);
    bg.gain.exponentialRampToValueAtTime(hot ? 0.22 : 0.17, t + 0.012);
    bg.gain.exponentialRampToValueAtTime(0.0001, t + 0.2);
    bo.connect(bf);
    bf.connect(bg);
    bg.connect(this.musicGain);
    bo.start(t);
    bo.stop(t + 0.22);

    // Hats
    if (step % 2 === 1 && this.noise) {
      const n = ctx.createBufferSource();
      n.buffer = this.noise;
      const hp = ctx.createBiquadFilter();
      hp.type = "highpass";
      hp.frequency.value = 7000;
      const hg = ctx.createGain();
      hg.gain.setValueAtTime(0.055, t);
      hg.gain.exponentialRampToValueAtTime(0.0001, t + 0.045);
      n.connect(hp);
      hp.connect(hg);
      hg.connect(this.musicGain);
      n.start(t);
      n.stop(t + 0.06);
    }

    // Snare-ish on 2 & 4
    if (step % 8 === 4 && this.noise) {
      const n = ctx.createBufferSource();
      n.buffer = this.noise;
      const bp = ctx.createBiquadFilter();
      bp.type = "bandpass";
      bp.frequency.value = 1900;
      bp.Q.value = 0.7;
      const ng = ctx.createGain();
      ng.gain.setValueAtTime(0.12, t);
      ng.gain.exponentialRampToValueAtTime(0.0001, t + 0.14);
      n.connect(bp);
      bp.connect(ng);
      ng.connect(this.musicGain);
      n.start(t);
      n.stop(t + 0.16);
    }

    // Arpeggio bell motif every bar
    if (step % 8 === 0 || (hot && step % 4 === 2)) {
      const arp = [12, 15, 19, 24, 19, 15];
      for (let i = 0; i < 3; i++) {
        const f = this.mnote(arp[(step + i) % arp.length]) * 2;
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.type = "sine";
        o.frequency.setValueAtTime(f, t + i * 0.09);
        g.gain.setValueAtTime(0.0001, t + i * 0.09);
        g.gain.exponentialRampToValueAtTime(hot ? 0.1 : 0.06, t + i * 0.09 + 0.01);
        g.gain.exponentialRampToValueAtTime(0.0001, t + i * 0.09 + 0.32);
        o.connect(g);
        g.connect(this.musicGain);
        o.start(t + i * 0.09);
        o.stop(t + i * 0.09 + 0.36);
      }
    }

    // Drone pad
    if (step === 0) {
      [0, 3, 7].forEach((s) => {
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.type = "sawtooth";
        o.frequency.setValueAtTime(this.mnote(s) / 2, t);
        g.gain.setValueAtTime(0.0001, t);
        g.gain.linearRampToValueAtTime(0.03, t + 0.5);
        g.gain.linearRampToValueAtTime(0.0001, t + 2.4);
        o.connect(g);
        g.connect(this.musicGain!);
        o.start(t);
        o.stop(t + 2.5);
      });
    }
    void delay;
  }
}

export const audio = new AudioEngine();
