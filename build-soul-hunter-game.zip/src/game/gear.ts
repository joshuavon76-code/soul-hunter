/* ==============================================================
   GEAR — scythes & accessories sold in the Soul Bazaar.
   Items are persistent across runs (bought with banked souls)
   and rendered procedurally on Vael.
   ============================================================== */

export type ScytheId = "mournsong" | "ashthorn" | "voidfang" | "crimsoneye";
export type AccessoryId = "duskwings" | "boneward" | "gravelantern" | "soulchain" | "hollowcrown" | "emberveil";
export type Slot = "wings" | "charm" | "trinket";

export interface ScytheDef {
  id: ScytheId;
  name: string;
  epithet: string;
  blurb: string;
  price: number;
  tone: string; // accent color
  glow: string;
  /* stat deltas */
  dmg: number; // multiplier
  reach: number; // multiplier
  arc: number; // multiplier
  cd: number; // multiplier (lower = faster)
  crit: number; // +chance
  passive: string;
  passiveId: "none" | "bleed" | "voidpull" | "eyecrit";
}

export interface AccessoryDef {
  id: AccessoryId;
  name: string;
  slot: Slot;
  blurb: string;
  price: number;
  tone: string;
  apply: string[]; // human readable
  stats: Partial<{
    speed: number;
    dash: number;
    dashCd: number;
    magnet: number;
    luck: number;
    maxHp: number;
    shields: number;
    frenzy: number;
    greed: number;
    xp: number;
  }>;
}

export const SCYTHES: ScytheDef[] = [
  {
    id: "mournsong",
    name: "Mournsong",
    epithet: "the bonded blade",
    blurb: "Vael's own crescent. Honest reach, honest steel. It asks nothing and gives everything.",
    price: 0,
    tone: "#cdc0a4",
    glow: "#3fe6b8",
    dmg: 1,
    reach: 1,
    arc: 1,
    cd: 1,
    crit: 0,
    passive: "No passive — but every boon stacks cleanly on it.",
    passiveId: "none",
  },
  {
    id: "ashthorn",
    name: "Ashthorn",
    epithet: "the thorned reliquary",
    blurb: "A black-iron reaper etched with crimson filigree and bone-white thorns. Its edge leaves a wound that keeps opening.",
    price: 4200,
    tone: "#e2382f",
    glow: "#ff5b4d",
    dmg: 1.18,
    reach: 1.12,
    arc: 0.96,
    cd: 1.04,
    crit: 0.04,
    passive: "Hemorrhage — struck foes bleed 25% of the hit again over 2s.",
    passiveId: "bleed",
  },
  {
    id: "voidfang",
    name: "Voidfang",
    epithet: "the abyssal crown",
    blurb: "A living shard of the void grown into a scythe: serrated obsidian crest, violet marrow-light pulsing through every spine.",
    price: 9800,
    tone: "#b46cff",
    glow: "#d9a6ff",
    dmg: 1.08,
    reach: 1.22,
    arc: 1.2,
    cd: 0.9,
    crit: 0.03,
    passive: "Gravity wound — every reap drags nearby souls and phantoms toward you.",
    passiveId: "voidpull",
  },
  {
    id: "crimsoneye",
    name: "Crimson Eye",
    epithet: "the watching edge",
    blurb: "Lacquered ruby and pale steel, a living eye set in the crossguard. It sees the opening before you do.",
    price: 16500,
    tone: "#ff2d4d",
    glow: "#ffb3c0",
    dmg: 1.3,
    reach: 1.06,
    arc: 0.9,
    cd: 0.84,
    crit: 0.16,
    passive: "Judgement — critical hits execute wounded foes under 20% health outright.",
    passiveId: "eyecrit",
  },
];

export const ACCESSORIES: AccessoryDef[] = [
  {
    id: "duskwings",
    name: "Duskfeather Wings",
    slot: "wings",
    blurb: "Four wings of black-and-wine plumage strung with silver chain and bone beads. They do not lift you — they carry you between heartbeats.",
    price: 7200,
    tone: "#8d1b3d",
    apply: ["+1 dash charge", "-22% dash recovery", "+10% move speed", "dash leaves a feather trail"],
    stats: { dash: 1, dashCd: 0.78, speed: 1.1 },
  },
  {
    id: "emberveil",
    name: "Emberveil Mantle",
    slot: "wings",
    blurb: "A cloak of smouldering cinders. Souls burn brighter around it.",
    price: 3600,
    tone: "#ff6a1f",
    apply: ["+30% soul pressure gain", "+8% score", "ember trail"],
    stats: { frenzy: 1.3, greed: 1.08 },
  },
  {
    id: "boneward",
    name: "Boneward Pendant",
    slot: "charm",
    blurb: "A knucklebone on a leather cord, carved with the sigil of the gate.",
    price: 2400,
    tone: "#e9dfc6",
    apply: ["+1 max heart", "start every run with 1 ward"],
    stats: { maxHp: 1, shields: 1 },
  },
  {
    id: "soulchain",
    name: "Soulchain Rosary",
    slot: "charm",
    blurb: "Beads of condensed spirit. Essence flows to the hand that wears it.",
    price: 3000,
    tone: "#3fe6b8",
    apply: ["+90 soul pull range", "+20% essence gained"],
    stats: { magnet: 90, xp: 1.2 },
  },
  {
    id: "gravelantern",
    name: "Gravelantern",
    slot: "trinket",
    blurb: "A tiny iron lantern that burns the memory of the dead. Fortune favours its light.",
    price: 2800,
    tone: "#ffc94a",
    apply: ["+35% luck", "brighter light radius in the crypt"],
    stats: { luck: 0.35 },
  },
  {
    id: "hollowcrown",
    name: "Hollow Crown",
    slot: "trinket",
    blurb: "A circlet of blackened silver thorns. Worn by the gate's first warden.",
    price: 5400,
    tone: "#d9a6ff",
    apply: ["+15% score", "+1 max heart", "a crown of rune shards"],
    stats: { greed: 1.15, maxHp: 1 },
  },
];

export interface Loadout {
  scythe: ScytheId;
  wings: AccessoryId | null;
  charm: AccessoryId | null;
  trinket: AccessoryId | null;
}

export interface Vault {
  souls: number; // banked currency
  owned: string[]; // item ids
  loadout: Loadout;
}

export const DEFAULT_VAULT: Vault = {
  souls: 0,
  owned: ["mournsong"],
  loadout: { scythe: "mournsong", wings: null, charm: null, trinket: null },
};

const KEY = "soul_hunter_vault_v1";

export function loadVault(): Vault {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return structuredClone(DEFAULT_VAULT);
    const v = JSON.parse(raw) as Vault;
    if (!v.owned?.includes("mournsong")) v.owned = ["mournsong", ...(v.owned ?? [])];
    return { ...structuredClone(DEFAULT_VAULT), ...v, loadout: { ...DEFAULT_VAULT.loadout, ...(v.loadout ?? {}) } };
  } catch {
    return structuredClone(DEFAULT_VAULT);
  }
}
export function saveVault(v: Vault) {
  try {
    localStorage.setItem(KEY, JSON.stringify(v));
  } catch {
    /* ignore */
  }
}

export const scytheOf = (id: ScytheId) => SCYTHES.find((s) => s.id === id) ?? SCYTHES[0];
export const accessoryOf = (id: AccessoryId | null) => (id ? ACCESSORIES.find((a) => a.id === id) ?? null : null);
