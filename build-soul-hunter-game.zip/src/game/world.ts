import { T, TILE, propBody, type PropKind } from "./art";

/* ==============================================================
   WORLD — tile maps, props, rooms, chests and portals.
   Overworld: Ashvale (village hub) + Thornwood + Ember Glade
   + Ruins of the Gate.  Dungeon: the Hollow Crypt, procedural.
   ============================================================== */

const TAU = Math.PI * 2;

export interface Prop {
  kind: PropKind;
  v: number;
  x: number;
  y: number;
  r: number;
  solid: boolean;
  light?: number; // light radius
}
export interface Chest {
  id: number;
  x: number;
  y: number;
  tier: 0 | 1 | 2;
  opened: boolean;
}
export interface Portal {
  kind: "crypt" | "stairs" | "exit";
  x: number;
  y: number;
  label: string;
  locked: boolean;
}
export interface Room {
  id: number;
  x: number;
  y: number;
  w: number;
  h: number;
  kind: "entry" | "combat" | "treasure" | "boss" | "stairs";
  cleared: boolean;
  active: boolean;
  doors: { x: number; y: number }[];
}
export interface Zone {
  name: string;
  sub: string;
  x0: number;
  y0: number;
  x1: number;
  y1: number;
  safe: boolean;
}
export interface GameMap {
  kind: "overworld" | "dungeon";
  biome: Biome | "surface";
  depth: number;
  w: number;
  h: number;
  tiles: Uint8Array;
  vars: Uint8Array;
  props: Prop[];
  chests: Chest[];
  portals: Portal[];
  rooms: Room[];
  zones: Zone[];
  spawn: { x: number; y: number };
  ambient: number; // darkness 0..1
  lights: { x: number; y: number; r: number; c: string }[];
  minimap?: HTMLCanvasElement;
}

function mulberry(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export const isSolidTile = (t: number) =>
  t === T.WALL || t === T.DWALL || t === T.WATER || t === T.VOID || t === T.SEAL || t === T.MWALL || t === T.SWALL;

export const isWallTile = (t: number) => t === T.WALL || t === T.DWALL || t === T.MWALL || t === T.SWALL;

export type Biome = "crypt" | "barracks" | "sewer";
export function biomeFor(depth: number): Biome {
  const k = ((depth - 1) % 3 + 3) % 3;
  return k === 0 ? "crypt" : k === 1 ? "barracks" : "sewer";
}
export const BIOME_INFO: Record<Biome, { name: string; sub: string; floor: number; wall: number; ambient: number; light: string; ember: string }> = {
  crypt: { name: "THE HOLLOW CRYPT", sub: "clear each chamber to unseal the way", floor: T.FLOOR, wall: T.DWALL, ambient: 0.84, light: "#ffb060", ember: "#b46cff" },
  barracks: { name: "MOSSGRAVE BARRACKS", sub: "the garrison that never marched home", floor: T.MFLOOR, wall: T.MWALL, ambient: 0.7, light: "#ffc070", ember: "#c9d27a" },
  sewer: { name: "THE SEWER VAULT", sub: "don't drink the green · the circle hums", floor: T.SFLOOR, wall: T.SWALL, ambient: 0.8, light: "#b8ef3f", ember: "#8ef08a" },
};

export function tileAt(m: GameMap, tx: number, ty: number): number {
  if (tx < 0 || ty < 0 || tx >= m.w || ty >= m.h) return T.VOID;
  return m.tiles[ty * m.w + tx];
}
export function setTile(m: GameMap, tx: number, ty: number, t: number) {
  if (tx < 0 || ty < 0 || tx >= m.w || ty >= m.h) return;
  m.tiles[ty * m.w + tx] = t;
}
export function walkableAt(m: GameMap, x: number, y: number) {
  return !isSolidTile(tileAt(m, Math.floor(x / TILE), Math.floor(y / TILE)));
}

/** push a circle out of solid tiles and solid props */
export function resolveCircle(m: GameMap, x: number, y: number, r: number): { x: number; y: number; hit: boolean } {
  let hit = false;
  const tx0 = Math.floor((x - r) / TILE);
  const ty0 = Math.floor((y - r) / TILE);
  const tx1 = Math.floor((x + r) / TILE);
  const ty1 = Math.floor((y + r) / TILE);
  for (let pass = 0; pass < 2; pass++) {
    for (let ty = ty0; ty <= ty1; ty++) {
      for (let tx = tx0; tx <= tx1; tx++) {
        if (!isSolidTile(tileAt(m, tx, ty))) continue;
        const bx = tx * TILE;
        const by = ty * TILE;
        const cx = Math.max(bx, Math.min(x, bx + TILE));
        const cy = Math.max(by, Math.min(y, by + TILE));
        let dx = x - cx;
        let dy = y - cy;
        let d = Math.hypot(dx, dy);
        if (d >= r) continue;
        hit = true;
        if (d < 0.0001) {
          // centre inside the tile: push along the shortest axis
          const lx = x - bx;
          const rx = bx + TILE - x;
          const uy = y - by;
          const dy2 = by + TILE - y;
          const mn = Math.min(lx, rx, uy, dy2);
          if (mn === lx) x = bx - r;
          else if (mn === rx) x = bx + TILE + r;
          else if (mn === uy) y = by - r;
          else y = by + TILE + r;
          continue;
        }
        dx /= d;
        dy /= d;
        d = r - d;
        x += dx * d;
        y += dy * d;
      }
    }
  }
  for (const p of m.props) {
    if (!p.solid) continue;
    const dx = x - p.x;
    const dy = y - p.y;
    const rr = r + p.r;
    const d2 = dx * dx + dy * dy;
    if (d2 >= rr * rr || d2 < 0.0001) continue;
    const d = Math.sqrt(d2);
    x += (dx / d) * (rr - d);
    y += (dy / d) * (rr - d);
    hit = true;
  }
  return { x, y, hit };
}

export function zoneAt(m: GameMap, x: number, y: number): Zone | null {
  for (const z of m.zones) if (x >= z.x0 && x < z.x1 && y >= z.y0 && y < z.y1) return z;
  return null;
}
export function roomAt(m: GameMap, x: number, y: number): Room | null {
  const tx = x / TILE;
  const ty = y / TILE;
  for (const r of m.rooms) if (tx >= r.x && tx < r.x + r.w && ty >= r.y && ty < r.y + r.h) return r;
  return null;
}

function blank(kind: GameMap["kind"], w: number, h: number, fill: number, depth = 0): GameMap {
  const tiles = new Uint8Array(w * h).fill(fill);
  const vars = new Uint8Array(w * h);
  for (let i = 0; i < vars.length; i++) vars[i] = (i * 2654435761) >>> 0 & 3;
  return {
    kind,
    biome: "surface",
    depth,
    w,
    h,
    tiles,
    vars,
    props: [],
    chests: [],
    portals: [],
    rooms: [],
    zones: [],
    spawn: { x: (w * TILE) / 2, y: (h * TILE) / 2 },
    ambient: 0,
    lights: [],
  };
}

function addProp(m: GameMap, kind: PropKind, v: number, x: number, y: number, light?: number, lightColor = "#ffb060") {
  const b = propBody(kind, v);
  m.props.push({ kind, v, x, y: y + b.yOff, r: b.r, solid: b.solid, light });
  if (light) m.lights.push({ x, y: y - (kind === "lantern" ? 70 : kind === "arch" ? 40 : 20), r: light, c: lightColor });
}

function fillRect(m: GameMap, x: number, y: number, w: number, h: number, t: number) {
  for (let j = y; j < y + h; j++) for (let i = x; i < x + w; i++) setTile(m, i, j, t);
}
function fillEllipse(m: GameMap, cx: number, cy: number, rx: number, ry: number, t: number) {
  for (let j = Math.floor(cy - ry); j <= cy + ry; j++)
    for (let i = Math.floor(cx - rx); i <= cx + rx; i++) {
      const dx = (i + 0.5 - cx) / rx;
      const dy = (j + 0.5 - cy) / ry;
      if (dx * dx + dy * dy <= 1) setTile(m, i, j, t);
    }
}
function fillEllipseIf(m: GameMap, cx: number, cy: number, rx: number, ry: number, t: number, only: number) {
  for (let j = Math.floor(cy - ry); j <= cy + ry; j++)
    for (let i = Math.floor(cx - rx); i <= cx + rx; i++) {
      const dx = (i + 0.5 - cx) / rx;
      const dy = (j + 0.5 - cy) / ry;
      if (dx * dx + dy * dy <= 1 && tileAt(m, i, j) === only) setTile(m, i, j, t);
    }
}

/* ---- biome room dressing ---- */
type Rnd = () => number;
type Px = (t: number) => number;

function freeSpot(m: GameMap, rm: Room, r: Rnd, px: Px, margin = 1, clearance = 40): { x: number; y: number } | null {
  for (let i = 0; i < 14; i++) {
    const tx = rm.x + margin + r() * (rm.w - margin * 2);
    const ty = rm.y + margin + r() * (rm.h - margin * 2);
    const x = px(tx - 0.5);
    const y = px(ty - 0.5);
    const t = tileAt(m, Math.floor(tx), Math.floor(ty));
    if (isSolidTile(t) || t === T.SLIME) continue;
    if (!clearFor(m, x, y, clearance)) continue;
    // keep the centre open so spawns & portals have room
    if (Math.hypot(tx - (rm.x + rm.w / 2), ty - (rm.y + rm.h / 2)) < 1.6) continue;
    return { x, y };
  }
  return null;
}

function dressBarracks(m: GameMap, rm: Room, r: Rnd, px: Px) {
  const top = rm.y * TILE + 4;
  // shelves and cots line the top wall
  for (let x = rm.x + 1; x < rm.x + rm.w - 1; x++) {
    if (tileAt(m, x, rm.y - 1) !== T.MWALL) continue;
    const roll = r();
    if (roll < 0.14) addProp(m, "shelf", 0, px(x), top + 60);
    else if (roll < 0.26 && rm.kind !== "entry") addProp(m, "cot", Math.floor(r() * 2), px(x), top + 92);
    else if (roll < 0.32) addProp(m, "barrel", Math.floor(r() * 2), px(x), top + 50);
  }
  if (rm.kind === "combat" && rm.w >= 8 && rm.h >= 6) {
    // mess table in the middle-ish with benches
    const s = freeSpot(m, rm, r, px, 2, 70);
    if (s) {
      addProp(m, "rug", Math.floor(r() * 2), s.x, s.y + 6);
      addProp(m, "table", 0, s.x, s.y);
      addProp(m, "bench", 0, s.x, s.y + 34);
      addProp(m, "bench", 0, s.x, s.y - 40);
      addProp(m, "oillamp", 0, s.x + 70, s.y + 10, 170, "#ffc070");
    }
  } else if (rm.kind === "treasure") {
    const s = freeSpot(m, rm, r, px, 2, 50);
    if (s) addProp(m, "rug", 0, s.x, s.y);
  }
  // scatter: crates, barrels, lamps
  const n = 1 + Math.floor(r() * 3);
  for (let i = 0; i < n; i++) {
    const s = freeSpot(m, rm, r, px);
    if (!s) continue;
    const roll = r();
    if (roll < 0.35) addProp(m, "crate", 0, s.x, s.y);
    else if (roll < 0.7) addProp(m, "barrel", Math.floor(r() * 2), s.x, s.y);
    else addProp(m, "oillamp", 0, s.x, s.y, 160, "#ffc070");
  }
}

function dressSewer(m: GameMap, rm: Room, r: Rnd, px: Px) {
  const top = rm.y * TILE + 4;
  // pipes & chains on the top wall
  for (let x = rm.x + 1; x < rm.x + rm.w - 1; x++) {
    if (tileAt(m, x, rm.y - 1) !== T.SWALL) continue;
    const roll = r();
    if (roll < 0.1) addProp(m, "pipe", 0, px(x), top + 80);
    else if (roll < 0.18) addProp(m, "chain", 0, px(x), top + 100);
  }
  const hasRune = tileAt(m, rm.x + Math.floor(rm.w / 2), rm.y + Math.floor(rm.h / 2)) === T.RUNE;
  if (hasRune) {
    const cx = px(rm.x + rm.w / 2 - 0.5);
    const cy = px(rm.y + rm.h / 2 - 0.5);
    addProp(m, "runecircle", 0, cx, cy + 130);
    m.lights.push({ x: cx, y: cy, r: 260, c: "#5adcff" });
  }
  // fountain or cauldron in bigger rooms
  if (rm.kind === "combat" && rm.w >= 9 && r() < 0.6) {
    const s = freeSpot(m, rm, r, px, 2, 60);
    if (s) {
      addProp(m, r() < 0.5 ? "fountain" : "cauldron", 0, s.x, s.y, 140, "#b8ef3f");
    }
  }
  if (rm.kind === "boss") {
    const cx = px(rm.x + rm.w / 2 - 0.5);
    const cy = px(rm.y + rm.h / 2 - 0.5);
    addProp(m, "sarcophagus", 0, px(rm.x + 1), cy);
    addProp(m, "sarcophagus", 0, px(rm.x + rm.w - 2), cy);
    addProp(m, "cauldron", 0, cx - 150, px(rm.y + rm.h - 1.5), 140, "#b8ef3f");
    addProp(m, "cauldron", 0, cx + 150, px(rm.y + rm.h - 1.5), 140, "#b8ef3f");
  }
  const n = 1 + Math.floor(r() * 3);
  for (let i = 0; i < n; i++) {
    const s = freeSpot(m, rm, r, px);
    if (!s) continue;
    const roll = r();
    if (roll < 0.3) addProp(m, "boulder", 0, s.x, s.y);
    else if (roll < 0.55) addProp(m, "bonepile", 0, s.x, s.y);
    else if (roll < 0.8) addProp(m, "grate", 0, s.x, s.y);
    else addProp(m, "barrel", 0, s.x, s.y);
  }
}

function path(m: GameMap, x0: number, y0: number, x1: number, y1: number, t = T.PATH, width = 2) {
  // L-shaped road
  const sx = Math.sign(x1 - x0) || 1;
  for (let x = x0; x !== x1 + sx; x += sx) for (let k = 0; k < width; k++) setTile(m, x, y0 + k, t);
  const sy = Math.sign(y1 - y0) || 1;
  for (let y = y0; y !== y1 + sy; y += sy) for (let k = 0; k < width; k++) setTile(m, x1 + k, y, t);
}

function clearFor(m: GameMap, x: number, y: number, r: number) {
  for (const p of m.props) if (Math.hypot(p.x - x, p.y - y) < r + p.r) return false;
  for (const c of m.chests) if (Math.hypot(c.x - x, c.y - y) < r + 30) return false;
  for (const p of m.portals) if (Math.hypot(p.x - x, p.y - y) < r + 60) return false;
  return true;
}

/* ============================== OVERWORLD ============================== */
export function makeOverworld(seed = 7): GameMap {
  const W = 76;
  const H = 76;
  const m = blank("overworld", W, H, T.GRASS);
  const r = mulberry(seed);
  m.ambient = 0.3;

  // border void
  fillRect(m, 0, 0, W, 2, T.VOID);
  fillRect(m, 0, H - 2, W, 2, T.VOID);
  fillRect(m, 0, 0, 2, H, T.VOID);
  fillRect(m, W - 2, 0, 2, H, T.VOID);

  // autumn glade (north-east) with a noisy edge
  for (let y = 2; y < 36; y++)
    for (let x = 44; x < W - 2; x++) {
      const edge = x - 44 + (36 - y) * 0.4 + (r() - 0.5) * 5;
      if (edge > 2) setTile(m, x, y, T.AUTUMN);
    }
  // dirt patches
  for (let i = 0; i < 26; i++) fillEllipse(m, 4 + r() * (W - 8), 4 + r() * (H - 8), 1.5 + r() * 3, 1 + r() * 2, T.DIRT);

  // ---- village: Ashvale ----
  const vx0 = 26,
    vy0 = 32,
    vx1 = 50,
    vy1 = 54; // wall rect (tiles)
  fillRect(m, vx0, vy0, vx1 - vx0 + 1, 1, T.WALL);
  fillRect(m, vx0, vy1, vx1 - vx0 + 1, 1, T.WALL);
  fillRect(m, vx0, vy0, 1, vy1 - vy0 + 1, T.WALL);
  fillRect(m, vx1, vy0, 1, vy1 - vy0 + 1, T.WALL);
  // gates (north, south, east)
  const gx = 38;
  fillRect(m, gx - 1, vy0, 3, 1, T.PATH);
  fillRect(m, gx - 1, vy1, 3, 1, T.PATH);
  fillRect(m, vx1, 43, 1, 3, T.PATH);
  // plaza
  fillRect(m, 32, 39, 13, 9, T.PATH);
  fillEllipse(m, 38.5, 43.5, 4, 3, T.DIRT);
  fillRect(m, 37, 36, 3, 14, T.PATH); // north-south street
  fillRect(m, 30, 43, 20, 2, T.PATH); // east-west street
  // roads out
  path(m, gx, 10, gx, vy0 - 1, T.PATH, 2); // north to ruins
  path(m, vx1 + 1, 44, 66, 20, T.PATH, 2); // east to glade
  path(m, gx, vy1 + 1, gx, 66, T.PATH, 2); // south to the pond road
  path(m, gx, 66, 18, 66, T.PATH, 2);

  const px = (tx: number) => tx * TILE;
  // towers at corners + gate flanks
  for (const [tx, ty] of [
    [vx0, vy0],
    [vx1, vy0],
    [vx0, vy1],
    [vx1, vy1],
  ])
    addProp(m, "tower", (tx + ty) % 2, px(tx) + 32, px(ty) + 40);
  addProp(m, "tower", 1, px(gx - 2) + 32, px(vy0) + 40);
  addProp(m, "tower", 1, px(gx + 2) + 32, px(vy0) + 40);

  // houses
  const houses: [number, number, number][] = [
    [29.5, 36.5, 1],
    [45.5, 36.5, 0],
    [29.5, 49.5, 2],
    [46.5, 50.5, 1],
    [33.5, 35.5, 3],
    [42.5, 35.2, 4],
    [28.5, 42.5, 0],
    [47.5, 41, 3],
    [34, 52, 0],
    [42.5, 52.5, 0],
  ];
  for (const [hx, hy, v] of houses) addProp(m, "house", v, px(hx), px(hy));
  addProp(m, "well", 0, px(38.5), px(44));
  for (const [lx, ly] of [
    [32.5, 39.5],
    [44.5, 39.5],
    [32.5, 47.5],
    [44.5, 47.5],
    [38, 33.5],
    [39, 33.5],
    [38, 53],
    [39, 53],
  ])
    addProp(m, "lantern", 0, px(lx), px(ly), 190);
  for (const [bx, by, v] of [
    [35.5, 41, 1],
    [41.5, 46.5, 0],
    [31, 45.5, 1],
  ])
    addProp(m, "barrel", v, px(bx), px(by));
  addProp(m, "crate", 0, px(36.2), px(41.2));
  addProp(m, "crate", 0, px(41), px(41));
  // chests in the village
  m.chests.push({ id: 1, x: px(34.5), y: px(45.8), tier: 0, opened: false });
  m.chests.push({ id: 2, x: px(43), y: px(48.5), tier: 0, opened: false });

  // ---- pond (south-west) ----
  fillEllipse(m, 16, 62, 5, 3.5, T.WATER);
  fillEllipse(m, 16, 62, 6.5, 5, T.DIRT);
  fillEllipse(m, 16, 62, 5, 3.5, T.WATER);
  m.chests.push({ id: 3, x: px(10.5), y: px(59), tier: 2, opened: false });

  // ---- ruins of the gate (north) ----
  fillEllipse(m, gx + 1, 8.5, 7, 5, T.RUIN);
  m.portals.push({ kind: "crypt", x: px(gx + 1), y: px(5.6), label: "THE HOLLOW CRYPT", locked: false });
  addProp(m, "arch", 0, px(gx + 1), px(5.9), 230);
  for (const [cx, cy, v] of [
    [gx - 5, 7, 0],
    [gx + 7, 7, 1],
    [gx - 6, 11.5, 1],
    [gx + 8, 11.5, 0],
  ])
    addProp(m, "pillar", v, px(cx) + 32, px(cy) + 30);
  for (let i = 0; i < 9; i++) addProp(m, "grave", i % 2, px(gx - 6 + r() * 14), px(9 + r() * 4));
  addProp(m, "bones", 0, px(gx + 3), px(9.5));
  m.chests.push({ id: 4, x: px(gx - 4), y: px(5.5), tier: 1, opened: false });
  m.chests.push({ id: 5, x: px(gx + 6), y: px(5.5), tier: 1, opened: false });
  addProp(m, "lantern", 0, px(gx - 2), px(7), 160);
  addProp(m, "lantern", 0, px(gx + 4), px(7), 160);

  // ---- ember glade (autumn) ----
  addProp(m, "house", 4, px(66), px(17));
  addProp(m, "lantern", 0, px(63.5), px(19.5), 170);
  m.chests.push({ id: 6, x: px(70), y: px(11), tier: 2, opened: false });
  m.chests.push({ id: 7, x: px(58), y: px(28), tier: 1, opened: false });
  fillEllipse(m, 60, 12, 2.5, 1.6, T.WATER);

  // ---- thornwood chests ----
  m.chests.push({ id: 8, x: px(9), y: px(20), tier: 1, opened: false });
  m.chests.push({ id: 9, x: px(12), y: px(40), tier: 0, opened: false });
  m.chests.push({ id: 10, x: px(60), y: px(66), tier: 1, opened: false });
  m.chests.push({ id: 11, x: px(68), y: px(44), tier: 0, opened: false });

  // ---- forest scatter ----
  const tries = 1400;
  for (let i = 0; i < tries; i++) {
    const tx = 2 + r() * (W - 4);
    const ty = 2 + r() * (H - 4);
    const x = tx * TILE;
    const y = ty * TILE;
    const t = tileAt(m, Math.floor(tx), Math.floor(ty));
    if (t !== T.GRASS && t !== T.AUTUMN && t !== T.DIRT) continue;
    // keep the village interior & roads clear
    if (tx > vx0 - 1.5 && tx < vx1 + 1.5 && ty > vy0 - 1.5 && ty < vy1 + 1.5) continue;
    const nearRoad = [0, 1, -1].some((o) => tileAt(m, Math.floor(tx) + o, Math.floor(ty)) === T.PATH || tileAt(m, Math.floor(tx), Math.floor(ty) + o) === T.PATH);
    if (nearRoad && r() < 0.85) continue;
    const autumn = t === T.AUTUMN;
    const nearRuin = ty < 15 && Math.abs(tx - gx) < 10;
    const roll = r();
    let kind: PropKind;
    let v = 0;
    const edgeDense = tx < 7 || tx > W - 7 || ty < 6 || ty > H - 6;
    if (nearRuin) {
      if (roll < 0.5) continue;
      kind = roll < 0.75 ? "grave" : roll < 0.9 ? "rock" : "pine";
      v = Math.floor(r() * 2);
    } else if (roll < (edgeDense ? 0.62 : 0.34)) {
      kind = "oak";
      v = autumn ? 1 + Math.floor(r() * 2) : r() < 0.15 ? 3 : 0;
    } else if (roll < 0.6) {
      kind = "pine";
      v = Math.floor(r() * 2);
    } else if (roll < 0.72) {
      kind = "rock";
      v = Math.floor(r() * 3);
    } else if (roll < 0.8) {
      kind = "bush";
      v = autumn ? 2 : 0;
    } else if (roll < 0.86) {
      kind = "log";
    } else if (roll < 0.9) {
      kind = "stump";
    } else continue;
    const b = propBody(kind, v);
    if (!clearFor(m, x, y, b.r + 22)) continue;
    addProp(m, kind, v, x, y);
  }

  m.zones = [
    { name: "ASHVALE", sub: "the walled village · sanctuary", x0: px(vx0), y0: px(vy0), x1: px(vx1 + 1), y1: px(vy1 + 1), safe: true },
    { name: "RUINS OF THE GATE", sub: "where the crypt breathes", x0: px(gx - 10), y0: 0, x1: px(gx + 12), y1: px(18), safe: false },
    { name: "EMBER GLADE", sub: "the autumn wood", x0: px(44), y0: 0, x1: px(W), y1: px(36), safe: false },
    { name: "THORNWOOD", sub: "the old forest", x0: 0, y0: 0, x1: px(W), y1: px(H), safe: false },
  ];
  m.spawn = { x: px(38.5), y: px(46.2) };
  return m;
}

/* ============================== DUNGEON ============================== */
export function makeDungeon(depth: number, seed: number): GameMap {
  const W = 62;
  const H = 62;
  const biome = biomeFor(depth);
  const B = BIOME_INFO[biome];
  const m = blank("dungeon", W, H, B.wall, depth);
  m.biome = biome;
  const r = mulberry(seed * 7919 + depth * 104729);
  m.ambient = B.ambient;
  const isBoss = depth % 3 === 0;
  const FLOOR = B.floor;
  const WALL = B.wall;

  // rooms
  const rooms: Room[] = [];
  const want = 7 + Math.min(4, Math.floor(depth / 2));
  let guard = 0;
  while (rooms.length < want && guard++ < 400) {
    const w = 7 + Math.floor(r() * 7);
    const h = 6 + Math.floor(r() * 6);
    const x = 2 + Math.floor(r() * (W - w - 4));
    const y = 2 + Math.floor(r() * (H - h - 4));
    if (rooms.some((o) => x < o.x + o.w + 3 && x + w + 3 > o.x && y < o.y + o.h + 3 && y + h + 3 > o.y)) continue;
    rooms.push({ id: rooms.length, x, y, w, h, kind: "combat", cleared: false, active: false, doors: [] });
  }
  // order rooms by distance from the first to make a path
  rooms.sort((a, b) => a.x + a.y - (b.x + b.y));
  rooms.forEach((rm, i) => (rm.id = i));
  rooms[0].kind = "entry";
  rooms[0].cleared = true;
  const last = rooms[rooms.length - 1];
  last.kind = isBoss ? "boss" : "stairs";
  if (isBoss) {
    // enlarge boss room
    last.w = Math.min(W - last.x - 2, Math.max(last.w, 15));
    last.h = Math.min(H - last.y - 2, Math.max(last.h, 12));
  } else last.cleared = true;
  const treasure = rooms[1 + Math.floor(r() * Math.max(1, rooms.length - 3))];
  if (treasure.kind === "combat") {
    treasure.kind = "treasure";
    treasure.cleared = true;
  }

  for (const rm of rooms) fillRect(m, rm.x, rm.y, rm.w, rm.h, FLOOR);

  // corridors (sequential + one loop)
  const carve = (a: Room, b: Room) => {
    const ax = Math.floor(a.x + a.w / 2);
    const ay = Math.floor(a.y + a.h / 2);
    const bx = Math.floor(b.x + b.w / 2);
    const by = Math.floor(b.y + b.h / 2);
    const horizFirst = r() < 0.5;
    const cells: [number, number][] = [];
    if (horizFirst) {
      for (let x = Math.min(ax, bx); x <= Math.max(ax, bx); x++) cells.push([x, ay], [x, ay + 1]);
      for (let y = Math.min(ay, by); y <= Math.max(ay, by); y++) cells.push([bx, y], [bx + 1, y]);
    } else {
      for (let y = Math.min(ay, by); y <= Math.max(ay, by); y++) cells.push([ax, y], [ax + 1, y]);
      for (let x = Math.min(ax, bx); x <= Math.max(ax, bx); x++) cells.push([x, by], [x, by + 1]);
    }
    for (const [x, y] of cells) if (tileAt(m, x, y) === WALL) setTile(m, x, y, FLOOR);
  };
  for (let i = 0; i < rooms.length - 1; i++) carve(rooms[i], rooms[i + 1]);
  if (rooms.length > 4) carve(rooms[1], rooms[Math.floor(rooms.length / 2) + 1]);

  // doors: floor cells on each room's boundary ring
  for (const rm of rooms) {
    for (let x = rm.x - 1; x <= rm.x + rm.w; x++) {
      if (tileAt(m, x, rm.y - 1) === FLOOR) rm.doors.push({ x, y: rm.y - 1 });
      if (tileAt(m, x, rm.y + rm.h) === FLOOR) rm.doors.push({ x, y: rm.y + rm.h });
    }
    for (let y = rm.y; y < rm.y + rm.h; y++) {
      if (tileAt(m, rm.x - 1, y) === FLOOR) rm.doors.push({ x: rm.x - 1, y });
      if (tileAt(m, rm.x + rm.w, y) === FLOOR) rm.doors.push({ x: rm.x + rm.w, y });
    }
  }

  const px = (tx: number) => tx * TILE + TILE / 2;

  /* ---------- biome dressing: floors & hazards inside rooms ---------- */
  const isFloorCell = (x: number, y: number) => tileAt(m, x, y) === FLOOR;
  if (biome === "barracks") {
    for (const rm of rooms) {
      // moss patches
      const patches = 1 + Math.floor(r() * 3);
      for (let i = 0; i < patches; i++) fillEllipseIf(m, rm.x + 1 + r() * (rm.w - 2), rm.y + 1 + r() * (rm.h - 2), 1 + r() * 2.2, 0.8 + r() * 1.6, T.MMOSS, FLOOR);
      // plank floor for some rooms (the mess hall / bunk rooms)
      if ((rm.kind === "combat" || rm.kind === "treasure") && r() < 0.45 && rm.w >= 7 && rm.h >= 6) {
        fillRect(m, rm.x + 1, rm.y + 1, rm.w - 2, rm.h - 2, T.MPLANK);
        rm.doors.forEach(() => void 0);
      }
    }
  } else if (biome === "sewer") {
    for (const rm of rooms) {
      if (rm.kind === "entry") continue;
      const roll = r();
      if (rm.kind === "treasure" || (rm.kind === "boss" && isBoss)) {
        // rune chamber
        for (let y = rm.y; y < rm.y + rm.h; y++) for (let x = rm.x; x < rm.x + rm.w; x++) setTile(m, x, y, T.RUNE);
      } else if (roll < 0.4 && rm.w >= 7 && rm.h >= 6) {
        // slime pool with a stone walkway around it
        fillRect(m, rm.x + 2, rm.y + 2, rm.w - 4, rm.h - 4, T.SLIME);
        // a walkway bridge through the middle
        const midY = rm.y + Math.floor(rm.h / 2);
        for (let x = rm.x; x < rm.x + rm.w; x++) setTile(m, x, midY, T.SFLOOR);
      } else if (roll < 0.62) {
        // slime channel along one edge
        const vertical = r() < 0.5;
        if (vertical) {
          const cxT = r() < 0.5 ? rm.x + 1 : rm.x + rm.w - 2;
          for (let y = rm.y; y < rm.y + rm.h; y++) if (isFloorCell(cxT, y)) setTile(m, cxT, y, T.SLIME);
        } else {
          const cyT = r() < 0.5 ? rm.y + 1 : rm.y + rm.h - 2;
          for (let x = rm.x; x < rm.x + rm.w; x++) if (isFloorCell(x, cyT)) setTile(m, x, cyT, T.SLIME);
        }
      } else if (roll < 0.78) {
        // blood scene
        for (let i = 0; i < 3; i++) {
          const bx = Math.floor(rm.x + 1 + r() * (rm.w - 2));
          const by = Math.floor(rm.y + 1 + r() * (rm.h - 2));
          if (isFloorCell(bx, by)) setTile(m, bx, by, T.BLOOD);
        }
      }
    }
  }

  // props per room
  let chestId = 100;
  for (const rm of rooms) {
    const cx = px(rm.x + rm.w / 2 - 0.5);
    const cy = px(rm.y + rm.h / 2 - 0.5);
    // wall lights on the top wall (biome-flavoured)
    const wallLight: PropKind = biome === "barracks" ? "torch" : "sconce";
    for (let x = rm.x + 1; x < rm.x + rm.w - 1; x += 3) {
      if (tileAt(m, x, rm.y - 1) === WALL) addProp(m, wallLight, 0, px(x), rm.y * TILE + 2, biome === "sewer" ? 130 : 150, biome === "sewer" ? "#ffa050" : B.light);
    }
    // biome clutter
    if (biome === "barracks") dressBarracks(m, rm, r, px);
    if (biome === "sewer") dressSewer(m, rm, r, px);

    if (rm.kind === "entry") {
      m.spawn = { x: cx, y: cy + 40 };
      m.portals.push({ kind: "exit", x: cx, y: rm.y * TILE + 50, label: "ASCEND TO ASHVALE", locked: false });
      addProp(m, "arch", 0, cx, rm.y * TILE + 60, 200);
      addProp(m, "barrel", 0, px(rm.x) + 10, px(rm.y + rm.h - 1));
      addProp(m, "crate", 0, px(rm.x + rm.w - 1) - 10, px(rm.y + rm.h - 1));
    } else if (rm.kind === "stairs") {
      m.portals.push({ kind: "stairs", x: cx, y: cy, label: `DESCEND · DEPTH ${depth + 1}`, locked: false });
      addProp(m, "stairs", 0, cx, cy + 20);
      addProp(m, "sconce", 0, cx - 70, rm.y * TILE + 2, 120);
    } else if (rm.kind === "boss") {
      m.portals.push({ kind: "stairs", x: cx, y: rm.y * TILE + 70, label: `DESCEND · DEPTH ${depth + 1}`, locked: true });
      addProp(m, "stairs", 0, cx, rm.y * TILE + 90);
      if (biome === "crypt") {
        for (const [ox, oy] of [
          [1.5, 1.5],
          [rm.w - 2.5, 1.5],
          [1.5, rm.h - 2.5],
          [rm.w - 2.5, rm.h - 2.5],
        ])
          addProp(m, "pillar", 1, px(rm.x + ox), px(rm.y + oy));
        addProp(m, "bones", 0, cx - 90, cy + 60);
        addProp(m, "bones", 0, cx + 110, cy - 30);
      }
    } else if (rm.kind === "treasure") {
      const n = 2 + Math.floor(r() * 2);
      for (let i = 0; i < n; i++) {
        m.chests.push({
          id: chestId++,
          x: cx + (i - (n - 1) / 2) * 70,
          y: cy,
          tier: i === Math.floor(n / 2) ? 2 : 1,
          opened: false,
        });
      }
      if (biome === "crypt") {
        addProp(m, "pillar", 0, px(rm.x + 0.5), px(rm.y + 0.5));
        addProp(m, "pillar", 0, px(rm.x + rm.w - 1.5), px(rm.y + 0.5));
      }
      addProp(m, biome === "barracks" ? "oillamp" : "lantern", 0, cx - 120, cy + 50, 180, biome === "sewer" ? "#5adcff" : B.light);
      addProp(m, biome === "barracks" ? "oillamp" : "lantern", 0, cx + 120, cy + 50, 180, biome === "sewer" ? "#5adcff" : B.light);
    } else {
      // combat: some clutter, occasional chest
      if (biome === "crypt") {
        if (rm.w >= 10 && rm.h >= 8) {
          addProp(m, "pillar", Math.floor(r() * 2), px(rm.x + 2), px(rm.y + 2));
          addProp(m, "pillar", Math.floor(r() * 2), px(rm.x + rm.w - 3), px(rm.y + rm.h - 3));
        }
        if (r() < 0.5) addProp(m, "bones", 0, px(rm.x + 1 + r() * (rm.w - 2)), px(rm.y + 1 + r() * (rm.h - 2)));
        if (r() < 0.4) addProp(m, r() < 0.5 ? "barrel" : "crate", 0, px(rm.x + rm.w - 1.5), px(rm.y + 0.5) + 10);
      }
      if (r() < 0.35) {
        const s = freeSpot(m, rm, r, px, 1, 46) ?? { x: px(rm.x + 1), y: px(rm.y + rm.h - 1.5) };
        m.chests.push({ id: chestId++, x: s.x, y: s.y, tier: r() < 0.7 ? 0 : 1, opened: false });
      }
    }
  }

  m.rooms = rooms;
  m.zones = [
    {
      name: `${B.name} · DEPTH ${depth}`,
      sub: isBoss ? "the warden's vault" : B.sub,
      x0: 0,
      y0: 0,
      x1: W * TILE,
      y1: H * TILE,
      safe: false,
    },
  ];
  return m;
}

/** random walkable point inside a room, away from a position */
export function roomPoint(m: GameMap, rm: Room, awayX: number, awayY: number, minD: number, rnd = Math.random) {
  for (let i = 0; i < 40; i++) {
    const x = (rm.x + 0.5 + rnd() * (rm.w - 1)) * TILE;
    const y = (rm.y + 0.5 + rnd() * (rm.h - 1)) * TILE;
    if (Math.hypot(x - awayX, y - awayY) < minD) continue;
    if (!walkableAt(m, x, y)) continue;
    if (tileAt(m, Math.floor(x / TILE), Math.floor(y / TILE)) === T.SLIME) continue;
    if (m.props.some((p) => p.solid && Math.hypot(p.x - x, p.y - y) < p.r + 24)) continue;
    return { x, y };
  }
  return { x: (rm.x + rm.w / 2) * TILE, y: (rm.y + rm.h / 2) * TILE };
}

export function sealRoom(m: GameMap, rm: Room, seal: boolean) {
  const floor = m.biome === "barracks" ? T.MFLOOR : m.biome === "sewer" ? T.SFLOOR : T.FLOOR;
  for (const d of rm.doors) setTile(m, d.x, d.y, seal ? T.SEAL : floor);
}

/** minimap: 1 tile → 2px, cached per map */
export function minimapOf(m: GameMap): HTMLCanvasElement {
  if (m.minimap) return m.minimap;
  const s = 2;
  const c = document.createElement("canvas");
  c.width = m.w * s;
  c.height = m.h * s;
  const g = c.getContext("2d")!;
  const col: Record<number, string> = {
    [T.VOID]: "#06040c",
    [T.GRASS]: "#5f8a34",
    [T.AUTUMN]: "#a07a34",
    [T.DIRT]: "#9a7c52",
    [T.PATH]: "#b3a284",
    [T.RUIN]: "#8a847b",
    [T.WATER]: "#3b6fb2",
    [T.WALL]: "#e8e2d6",
    [T.FLOOR]: "#6a6c7d",
    [T.DWALL]: "#1a1624",
    [T.SEAL]: "#b46cff",
    [T.MFLOOR]: "#7f7d64",
    [T.MMOSS]: "#6f8f3a",
    [T.MPLANK]: "#9a6a3c",
    [T.MWALL]: "#2a2620",
    [T.SFLOOR]: "#8b84a2",
    [T.SLIME]: "#7ab51a",
    [T.SWALL]: "#1e1a2a",
    [T.RUNE]: "#8e94b5",
    [T.BLOOD]: "#a83040",
  };
  for (let y = 0; y < m.h; y++)
    for (let x = 0; x < m.w; x++) {
      g.fillStyle = col[m.tiles[y * m.w + x]] ?? "#000";
      g.fillRect(x * s, y * s, s, s);
    }
  m.minimap = c;
  return c;
}

export function unitDir(a: number) {
  return { x: Math.cos(a), y: Math.sin(a) };
}
export const TWO_PI = TAU;
